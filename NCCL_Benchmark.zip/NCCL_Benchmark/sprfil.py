"""Homogeneous SPR-FIL for class-incremental streams (NeurIPS 2026, Eqs. 2–12)."""

from collections import defaultdict

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader, TensorDataset

from .survey.common import avoid_singleton_batch_norm, optimizer_for
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--sprfil_rank", type=int, default=8, help="Maximum protected feature dimensions")
    parser.add_argument("--sprfil_anchor_count", type=int, default=128,
                        help="Shared procedural IFS images for moment alignment")
    parser.add_argument("--sprfil_epsilon", type=float, default=1e-4, help="Covariance ridge")
    parser.add_argument("--sprfil_temperature", type=float, default=2.0)
    parser.add_argument("--sprfil_weight", type=float, default=1.0)


def validate_args(parser, args):
    if args.sprfil_rank < 1 or args.sprfil_anchor_count < 2:
        parser.error("SPR-FIL requires a positive subspace rank and at least two anchors")
    if min(args.sprfil_temperature, args.sprfil_epsilon) <= 0 or args.sprfil_weight < 0:
        parser.error("SPR-FIL temperature and ridge must be positive and weight nonnegative")


def _fractal_images(count, size, mean, std):
    """Fixed-seed iterated function systems with contractive affine maps."""
    rng = np.random.default_rng(1729)
    maps = 4
    angles = rng.uniform(-np.pi, np.pi, (count, maps))
    rotations = np.stack((np.cos(angles), -np.sin(angles), np.sin(angles), np.cos(angles)), -1)
    matrices = rotations.reshape(count, maps, 2, 2) * rng.uniform(0.25, 0.72, (count, maps, 1, 2))
    shifts = rng.uniform(-1, 1, (count, maps, 2))
    weights = np.abs(np.linalg.det(matrices))
    endpoints = np.cumsum(weights / weights.sum(axis=1, keepdims=True), axis=1)
    endpoints[:, -1] = 1
    rows = np.arange(count)
    state = np.zeros((count, 2))
    points = np.empty((count, max(512, 4 * size * size), 2), dtype=np.float32)
    for step in range(points.shape[1] + 24):
        choices = (rng.random((count, 1)) > endpoints).sum(axis=1)
        state = (matrices[rows, choices] @ state[:, :, None]).squeeze(2) + shifts[rows, choices]
        if step >= 24:
            points[:, step - 24] = state
    points -= points.min(axis=1, keepdims=True)
    pixels = np.rint(points / points.max(axis=1, keepdims=True).clip(1e-8) * (size - 1)).astype(int)
    densities = np.zeros((count, size, size), dtype=np.float32)
    np.add.at(densities, (rows[:, None], pixels[:, :, 1], pixels[:, :, 0]), 1)
    densities = np.log1p(densities)
    images = torch.from_numpy(densities / densities.max(axis=(1, 2), keepdims=True))[:, None]
    return (images - torch.tensor(mean)[None, :, None, None]) / torch.tensor(std)[None, :, None, None]


def _moments(features):
    mean = features.mean(0)
    centered = features - mean
    return len(features), mean, centered.T @ centered / len(features)


def _pool(reports):
    """Eq. 3 uses population covariances, including between-client mean shifts."""
    count = sum(n for n, _, _ in reports)
    mean = sum(n * mu for n, mu, _ in reports) / count
    cov = torch.zeros_like(reports[0][2])
    for n, mu, local in reports:
        delta = mu - mean
        cov.add_(local, alpha=n / count)
        cov.addr_(delta, delta, alpha=n / count)
    return count, mean, cov


def _symmetric(matrix):
    return (matrix + matrix.transpose(-1, -2)) * 0.5


def _covariance_power(cov, power, epsilon):
    values, vectors = torch.linalg.eigh(_symmetric(cov.double()))
    return (vectors * (values.clamp_min(0) + epsilon).pow(power)) @ vectors.T


def _align(repository, previous, current, epsilon):
    """Whiten using the preceding anchor, then recolor and translate to the current one."""
    _, old_center, old_cov = previous
    _, center, cov = current
    transform = _covariance_power(cov, 0.5, epsilon) @ _covariance_power(old_cov, -0.5, epsilon)
    offset = center.double() - transform @ old_center.double()
    return {label: (n, (transform @ mean.double() + offset).float(),
                    _symmetric(transform @ covariance.double() @ transform.T).float())
            for label, (n, mean, covariance) in repository.items()}


def _project(gradient, basis):
    return gradient - (gradient @ basis) @ basis.T


def _posterior(features, means, factors, temperature):
    # Solve triangular systems instead of materializing inverse covariances.
    residuals = (features.unsqueeze(0) - means.unsqueeze(1)).transpose(1, 2)
    white = torch.linalg.solve_triangular(factors, residuals, upper=False)
    distances = white.square().sum(1).T
    return F.softmax(-distances / temperature, dim=1)


class SPRFIL(LocalStrategy):
    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        if stream.protocol["scenario"] != "class-il":
            raise ValueError("SPR-FIL requires disjoint class-incremental tasks")
        self.repository, self.anchor = {}, None
        self.anchors = TensorDataset(_fractal_images(args.sprfil_anchor_count, stream.image_size,
                                                    stream.mean, stream.std))
        self.trace = []
        stream.protocol["sprfil"] = {
            "setting": "Homogeneous encoders with sample-weighted model aggregation",
            "anchors": "Fixed-seed procedural iterated function systems",
            "anchor_seed": 1729, "anchor_count": args.sprfil_anchor_count,
            "rank_cap": args.sprfil_rank, "ridge": args.sprfil_epsilon,
            "temperature": args.sprfil_temperature, "weight": args.sprfil_weight,
            "statistics": "Each participating client's latest report in this task",
            "tasks": self.trace,
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.latest = {}
        self.old = torch.tensor(sorted(self.repository), dtype=torch.long, device=self.device)
        self.seen = torch.tensor(seen_classes, dtype=torch.long, device=self.device)
        self.label_index = torch.full((self.stream.num_classes,), -1, dtype=torch.long, device=self.device)
        self.label_index[self.seen] = torch.arange(len(seen_classes), device=self.device)
        self.basis = None
        if not self.repository:
            return
        stats = [self.repository[label] for label in sorted(self.repository)]
        self.means = torch.stack([mean for _, mean, _ in stats]).to(self.device)
        covs = torch.stack([cov for _, _, cov in stats]).double()
        dimension = covs.shape[1]
        values, vectors = torch.linalg.eigh(_symmetric(covs.sum(0)))
        threshold = max(0., values[-1].item()) * dimension * torch.finfo(torch.float32).eps
        rank = min(self.args.sprfil_rank, int((values > threshold).sum()))
        if rank:
            self.basis = vectors[:, -rank:].float().to(self.device)
        regularized = _symmetric(covs) + self.args.sprfil_epsilon * torch.eye(dimension, dtype=covs.dtype)
        factors, info = torch.linalg.cholesky_ex(regularized)
        for index in torch.nonzero(info).flatten().tolist():
            eigenvalues, eigenvectors = torch.linalg.eigh(_symmetric(covs[index]))
            stable = (eigenvectors * (eigenvalues.clamp_min(0) + self.args.sprfil_epsilon)) @ eigenvectors.T
            factors[index] = torch.linalg.cholesky(stable)
        self.factors = factors.float().to(self.device)

    @torch.no_grad()
    def _statistics(self, dataset, collect_labels):
        self.model.eval()
        features, labels = [], []
        loader = DataLoader(dataset, batch_size=self.args.batch_size, num_workers=self.args.num_workers)
        for batch in loader:
            features.append(self.model.forward_features(batch[0].to(self.device)).cpu())
            if collect_labels:
                labels.append(batch[1])
        features = torch.cat(features)
        if not collect_labels:
            return _moments(features)
        labels = torch.cat(labels)
        return {int(label): _moments(features[labels == label]) for label in labels.unique()}

    def fit_client(self, client, loader, device):
        self.model.train()
        optimizer = optimizer_for(self.model.parameters(), self.args)
        for _ in range(self.args.epochs):
            for images, labels in loader:
                images, labels = images.to(device), labels.to(device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(images)):
                    features = self.model.forward_features(images)
                    if self.basis is not None:
                        features.register_hook(lambda gradient: _project(gradient, self.basis))
                    logits = self.model.fc(features)
                    loss = F.cross_entropy(logits.index_select(1, self.seen), self.label_index[labels])
                    if len(self.old) > 1 and self.args.sprfil_weight:
                        with torch.no_grad():
                            teacher = _posterior(features, self.means, self.factors, self.args.sprfil_temperature)
                        historical = F.log_softmax(logits.index_select(1, self.old), dim=1)
                        loss = loss + self.args.sprfil_weight * F.kl_div(historical, teacher, reduction="batchmean")
                loss.backward()
                optimizer.step()
        self.latest[client] = (self._statistics(loader.dataset, True),
                               self._statistics(self.anchors, False))

    def finish_task(self, task):
        class_reports = defaultdict(list)
        anchor_reports = []
        for local, anchor_stats in self.latest.values():
            for label, stats in local.items():
                class_reports[label].append(stats)
            anchor_reports.append(anchor_stats)
        anchor = _pool(anchor_reports)
        aligned_count = len(self.repository)
        if self.anchor is not None:
            self.repository = _align(self.repository, self.anchor, anchor, self.args.sprfil_epsilon)
        self.repository.update({label: _pool(reports) for label, reports in class_reports.items()})
        self.anchor = anchor
        self.trace.append({"task": task + 1, "contributing_clients": len(self.latest),
                           "aligned_classes": aligned_count, "observed_classes": sorted(class_reports),
                           "projection_rank": self.basis.shape[1] if self.basis is not None else 0,
                           "repository_classes": len(self.repository)})
        self.latest.clear()

    def checkpoint(self):
        return {"prototypes": self.repository, "anchor_statistics": self.anchor}
