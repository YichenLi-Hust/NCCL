"""Shared training utilities for synchronous and asynchronous streams."""

from contextlib import contextmanager
import random

import numpy as np
import torch
from torch import nn


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed % (2 ** 32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def state_copy(module):
    return {name: value.detach().cpu().clone() for name, value in module.state_dict().items()}


@contextmanager
def avoid_singleton_batch_norm(model, batch_size):
    """Use running statistics for a singleton from a small client partition."""
    if batch_size != 1:
        yield
        return
    batch_norms = [layer for layer in model.modules()
                   if isinstance(layer, nn.modules.batchnorm._BatchNorm)
                   and layer.training]
    for layer in batch_norms:
        layer.eval()
    try:
        yield
    finally:
        for layer in batch_norms:
            layer.train()
