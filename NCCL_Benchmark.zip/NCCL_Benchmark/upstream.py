"""Run author implementations from an explicitly supplied local checkout."""

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from typing import Tuple

from .catalog import find_work


@dataclass(frozen=True)
class Recipe:
    """A repository-relative entry point and its published experiment arguments."""

    script: str
    args: Tuple[str, ...] = ()
    cwd: str = "."
    shell: str = ""
    import_root: bool = False
    driver: str = ""


RECIPES = {
    "gfedcl": Recipe("CIFAR100/main.py"),
    "lorm": Recipe("main.py", (
        "--model=lorm", "--dataset=seq-cifar100", "--network=vit", "--batch_size=16",
        "--lr=0.003", "--distribution_alpha=0.5", "--num_epochs=5", "--num_comm_rounds=5",
        "--num_clients=10", "--wd_reg=0", "--lora_head=False", "--regmean_all=True",
        "--gram_dtype=32", "--reg_dtype_64=True", "--alpha_regmean_head=0.5",
        "--alpha_regmean_backbone=0", "--train_matrix=alt", "--lr_B=-1", "--lr_A=-1", "--r=1",
    )),
    "online-fcl": Recipe("main_OFCL.py", (
        "--update_strategy", "balanced", "--balanced_update", "uncertainty",
        "--uncertainty_score", "entropy", "--balanced_step", "step",
    )),
    "fed-duet": Recipe("main.py", (
        "--config-path=configs", "--config-name=CIFAR_100_FedDuet_Incremental_10_iid",
    ), cwd="cil"),
    "multifcl": Recipe("main.py"),
    "dcfcl": Recipe("main.py"),
    "c2prompt": Recipe("scripts/run_imagenetr.sh", shell="sh"),
    "fedccfa": Recipe("FedCCFA.py", cwd="methods", import_root=True),
    "cola": Recipe("main_bp_collaboration.py", (
        "--batch_size", "64", "--data", "data/imagenet", "--data_corruption", "data/imagenet-c",
        "--data_v2", "data/imagenet-v2", "--data_sketch", "data/imagenet-sketch",
        "--data_rendition", "data/imagenet-r", "--output", "./outputs/bp_collaboration",
        "--resume", "weights/original.pth", "--algorithm", "eta-cola", "--tag", "_test",
    )),
    "feroma": Recipe("feroma/server.py", driver="_feroma.py"),
    "tagfed": Recipe("main.py", cwd="src"),
    "lander": Recipe("main.py", (
        "--group=c100t5", "--exp_name=lander_b05", "--dataset", "cifar100", "--method=lander",
        "--tasks=5", "--num_users", "5", "--beta=0.5",
    )),
    "fedta": Recipe("main.py", (
        "cifar100_delay", "--model", "vit_base_patch16_224", "--batch-size", "4",
        "--data-path", "local_datasets/", "--output_dir", "./output", "--data_name", "cifar100",
    )),
    "motion": Recipe("main.py", (
        "--fed_algorithm", "MOTION", "--dataset", "cora", "--model", "GAT",
        "--num_clients", "2", "--num_rounds", "1", "--skew_type", "label_skew",
        "--num_classes_per_task", "1", "--num_classes", "7", "--device_id", "0",
        "--dirichlet_alpha", "1.0", "--seed", "0",
    )),
    "powder": Recipe("fl_main_hard.py", (
        "--device", "0", "--global_update_lr", "100", "--img_size", "224", "--numclass", "500",
        "--class_per_task", "20", "--dataset", "ImageNet_R", "--easy", "0", "--tasks_global", "3",
        "--num_clients", "5", "--epochs_global", "15", "--local_clients", "5",
        "--learning_rate", "0.005", "--prompt_flag", "codap_2d_v2", "--method", "cprompt_powder_v2",
        "--batch_size", "64", "--prompt_param", "25", "10", "10", "8", "0", "0", "6", "10", "8",
        "--epochs_local", "10", "--seed", "2021",
    ), cwd="src"),
}


def _git_revision(root):
    """Record an actual checkout's SHA, without inheriting a parent project's metadata."""
    if not (root / ".git").exists() or not shutil.which("git"):
        return None
    revision = subprocess.run(["git", "rev-parse", "--verify", "HEAD"], cwd=root,
                              capture_output=True, text=True)
    if revision.returncode:
        return None
    status = subprocess.run(["git", "status", "--porcelain"], cwd=root,
                            capture_output=True, text=True)
    return {"commit": revision.stdout.strip(),
            "dirty": bool(status.stdout) if status.returncode == 0 else None}


def _now():
    return datetime.now(timezone.utc)


def run_upstream(method_id, argv):
    recipe = RECIPES[method_id]
    work = find_work(method_id)
    parser = argparse.ArgumentParser(prog=f"python -m nccl_benchmark run {method_id}",
                                     description=f"Launch the author implementation from {work.code}",
                                     allow_abbrev=False)
    parser.add_argument("--source-dir", required=True, type=Path,
                        help="local checkout of the author repository")
    parser.add_argument("--python", default=sys.executable,
                        help="Python executable in the author's prepared environment")
    parser.add_argument("--output-dir", type=Path,
                        help="new or empty directory for the launch record and training log")
    parser.add_argument("--dry-run", action="store_true",
                        help="validate the entry point and print the command without executing")
    parser.epilog = "Pass author-specific arguments after a literal --."
    cut = argv.index("--") if "--" in argv else len(argv)
    args = parser.parse_args(argv[:cut])
    extra = argv[cut + 1:]
    root = args.source_dir.expanduser().resolve()
    cwd = root / recipe.cwd
    entry = cwd / recipe.script
    if not entry.is_file():
        raise ValueError(f"missing {entry}. Supply the checkout of {work.code}")
    chosen = shutil.which(os.path.expanduser(args.python))
    if chosen is None:
        raise ValueError(f"Python executable was not found: {args.python}")
    # Keep the venv executable path. Resolving its symlink can select the system environment.
    python = os.path.abspath(chosen)
    env = dict(os.environ)
    env["PATH"] = os.path.dirname(python) + os.pathsep + env.get("PATH", "")
    env["PYTHONUNBUFFERED"] = "1"
    if recipe.import_root:
        env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(root), env.get("PYTHONPATH"))))
    command = [python, recipe.script, *recipe.args, *extra]
    if recipe.driver:
        command[1] = str(Path(__file__).with_name(recipe.driver))
    if recipe.shell:
        if extra:
            raise ValueError("the published shell recipe has fixed arguments; edit its settings in the checkout")
        shell = shutil.which(recipe.shell)
        if shell is None:
            raise ValueError(f"the published recipe requires {recipe.shell!r} on PATH")
        command = [shell, recipe.script, *recipe.args]

    print(f"Working directory: {cwd}\nCommand: {shlex.join(command)}", flush=True)
    if args.dry_run:
        return

    started = _now()
    default_output = Path("results", method_id, "upstream", started.strftime("%Y%m%dT%H%M%S%fZ"))
    output = (args.output_dir or default_output).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise ValueError(f"{output} already contains files. Choose an empty output directory")

    record = {"method": method_id, "backend": "upstream", "paper": work.paper, "source": work.code,
              "source_dir": str(root), "revision": _git_revision(root), "cwd": str(cwd),
              "entry_sha256": hashlib.sha256(entry.read_bytes()).hexdigest(),
              "python": python, "command": command, "started_at": started.isoformat(),
              "status": "running", "training_log": "upstream.log"}
    manifest = output / "run.json"
    try:
        with manifest.open("x", encoding="utf-8") as file:
            json.dump(record, file, indent=2)
            file.write("\n")
    except FileExistsError as error:
        raise ValueError(f"another run reserved {output}") from error

    log = output / "upstream.log"
    print(f"Training log: {log}\nUpstream artifacts follow the author's configuration.", flush=True)
    try:
        with log.open("wb") as stream, TemporaryDirectory(prefix="nccl-command-") as shims:
            if recipe.shell:
                # Published scripts invoke python by name. Preserve the user's exact
                # venv or versioned interpreter, including on hosts with no 'python'.
                for name in ("python", "python3"):
                    wrapper = Path(shims, name)
                    wrapper.write_text(f'#!/bin/sh\nexec {shlex.quote(python)} "$@"\n', encoding="utf-8")
                    wrapper.chmod(0o700)
                env["PATH"] = shims + os.pathsep + env["PATH"]
            result = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record["exit_code"] = result.returncode
        record["status"] = "completed" if result.returncode == 0 else "failed"
        if result.returncode:
            print(f"Upstream process exited with {result.returncode}. See {log}", file=sys.stderr)
            raise SystemExit(result.returncode if result.returncode > 0 else 128 - result.returncode)
    except KeyboardInterrupt:
        record["status"] = "interrupted"
        raise
    except OSError as error:
        record.update(status="failed", error=str(error))
        raise ValueError(f"could not run {method_id}: {error}") from error
    finally:
        record["finished_at"] = _now().isoformat()
        pending = output / "run.json.tmp"
        pending.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        pending.replace(manifest)
