"""Export final measurements, preserving their protocol and original definition."""

import csv
import json
from pathlib import Path
import sys


def summarize(root, stream=None):
    root = Path(root)
    if not root.is_dir():
        raise ValueError(f"Results directory does not exist: {root}")
    writer = csv.writer(stream or sys.stdout, lineterminator="\n")
    writer.writerow(("run", "method", "protocol", "dataset", "profile", "seed", "metric", "value", "unit"))
    manifests = sorted(root.rglob("run.json"))
    if not manifests:
        raise ValueError(f"No benchmark run.json files under {root}")
    for manifest in manifests:
        run = json.loads(manifest.read_text(encoding="utf-8"))
        if "method" not in run:
            continue
        run_dir = manifest.parent
        if run.get("backend") == "upstream":
            writer.writerow((str(run_dir.relative_to(root)), run["method"], "upstream", "", "", "",
                             "launch_status", run["status"], "status"))
            continue
        cfg = run["config"]
        key = (str(run_dir.relative_to(root)), run["method"], run["protocol"],
               cfg["dataset"], run["profile"], cfg["seed"])
        if run["protocol"] == "survey":
            scores = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
            for metric in ("final_accuracy", "average_accuracy", "final_task_macro_accuracy", "final_average_forgetting"):
                if scores.get(metric) is not None:
                    writer.writerow((*key, metric, scores[metric], "fraction"))
        else:
            with (run_dir / "metrics.csv").open(encoding="utf-8", newline="") as handle:
                last = None
                for last in csv.DictReader(handle):
                    pass
            if last is None:
                raise ValueError(f"Empty metrics file in {run_dir}")
            for metric, value in last.items():
                if value and (metric in ("AC", "FS", "FS_old") or "accuracy" in metric):
                    unit = "percent" if metric == "AC" else "percentage_points" if metric.startswith("FS") else "fraction"
                    writer.writerow((*key, metric, value, unit))
