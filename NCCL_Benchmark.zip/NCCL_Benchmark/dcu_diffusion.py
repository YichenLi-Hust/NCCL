"""Frozen conditional denoisers used by DCU's prototype inversion and replay."""

from pathlib import Path

import torch
from torch.nn import functional as F


class SyntheticDiffusion:
    """Closed-form Gaussian denoiser for the benchmark's RGB synthetic fixture."""

    def __init__(self, stream, device, steps):
        self.size = stream.image_size
        self.dim = stream.channels
        self.device = device
        self.steps = steps
        self.alpha = torch.linspace(0.999, 0.01, 100, device=device)

    def _predict(self, x, alpha, prototypes):
        # Exact expected noise under a Gaussian with a prototype-dependent mean.
        mean = prototypes.tanh()[:, :, None, None]
        variance = 0.03
        return (1 - alpha).sqrt() * (x - alpha.sqrt() * mean) / (1 - alpha + alpha * variance)

    def loss(self, pixels, prototypes):
        noise = torch.randn_like(pixels)
        a = self.alpha[torch.randint(len(self.alpha), (len(pixels),), device=self.device)].view(-1, 1, 1, 1)
        noisy = a.sqrt() * pixels + (1 - a).sqrt() * noise
        return F.mse_loss(self._predict(noisy, a, prototypes), noise)

    @torch.no_grad()
    def generate(self, prototypes):
        shape = (len(prototypes), self.dim, self.size, self.size)
        x = torch.randn(shape, device=self.device)
        grid = torch.linspace(len(self.alpha) - 1, 0, self.steps, device=self.device).long()
        for i, t in enumerate(grid):
            predicted = self._predict(x, self.alpha[t], prototypes)
            clean = (x - (1 - self.alpha[t]).sqrt() * predicted) / self.alpha[t].sqrt()
            next_a = self.alpha[grid[i + 1]] if i + 1 < len(grid) else self.alpha.new_tensor(1.0)
            x = next_a.sqrt() * clean + (1 - next_a).sqrt() * predicted
        return x.clamp(-1, 1)


class LatentDiffusion:
    """Use an offline SD 1.x Diffusers layout; invert a class token directly."""

    def __init__(self, path, stream, device, steps, resolution):
        root = Path(path)
        if not all((root / name).is_dir() for name in ("vae", "unet", "scheduler")):
            raise ValueError("DCU needs a local SD 1.x Diffusers directory with vae/, unet/ and scheduler/")
        try:
            from diffusers import AutoencoderKL, DDIMScheduler, DDPMScheduler, UNet2DConditionModel
        except ImportError as exc:
            raise ValueError("DCU real-image runs require diffusers and safetensors") from exc
        local = {"local_files_only": True}
        self.vae = AutoencoderKL.from_pretrained(root, subfolder="vae", **local).eval().requires_grad_(False).to(device)
        self.unet = UNet2DConditionModel.from_pretrained(root, subfolder="unet", **local).eval().requires_grad_(False).to(device)
        self.train_schedule = DDPMScheduler.from_pretrained(root, subfolder="scheduler", **local)
        self.sample_schedule = DDIMScheduler.from_config(self.train_schedule.config)
        if self.train_schedule.config.prediction_type != "epsilon":
            raise ValueError("DCU requires an epsilon-prediction denoiser")
        if steps > self.train_schedule.config.num_train_timesteps:
            raise ValueError("dcu_diffusion_steps exceeds the checkpoint's diffusion schedule")
        self.sample_schedule.set_timesteps(steps, device=device)
        self.device, self.resolution, self.size = device, resolution, stream.image_size
        self.dim = self.unet.config.cross_attention_dim
        self.latent_channels = self.unet.config.in_channels
        self.downsample = 2 ** (len(self.vae.config.block_out_channels) - 1)

    def loss(self, pixels, prototypes):
        with torch.no_grad():
            resized = F.interpolate(pixels, (self.resolution, self.resolution), mode="bilinear", align_corners=False)
            latent = self.vae.encode(resized).latent_dist.sample() * self.vae.config.scaling_factor
            noise = torch.randn_like(latent)
            times = torch.randint(self.train_schedule.config.num_train_timesteps, (len(latent),), device=self.device)
            noisy = self.train_schedule.add_noise(latent, noise, times)
        prediction = self.unet(noisy, times, encoder_hidden_states=prototypes[:, None]).sample
        return F.mse_loss(prediction, noise)

    @torch.no_grad()
    def generate(self, prototypes):
        side = self.resolution // self.downsample
        latent = torch.randn(len(prototypes), self.latent_channels, side, side, device=self.device)
        latent = latent * self.sample_schedule.init_noise_sigma
        for t in self.sample_schedule.timesteps:
            denoiser_input = self.sample_schedule.scale_model_input(latent, t)
            prediction = self.unet(denoiser_input, t, encoder_hidden_states=prototypes[:, None]).sample
            latent = self.sample_schedule.step(prediction, t, latent).prev_sample
        pixels = self.vae.decode(latent / self.vae.config.scaling_factor).sample
        return F.interpolate(pixels, (self.size, self.size), mode="bilinear", align_corners=False).clamp(-1, 1)
