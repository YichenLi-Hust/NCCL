"""Federated Orthogonal Training with layer-wise activation sketches."""

import math

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Subset

from .survey.strategies import LocalStrategy


class FOT(LocalStrategy):
    """Project aggregated convolution updates off previous task input subspaces."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.layers = {f"{name}.weight": layer for name, layer in model.named_modules()
                       if isinstance(layer, nn.Conv2d) and layer.groups == 1}
        if not self.layers:
            raise ValueError("FOT requires convolutional layers with groups=1")
        self.bases = {}

    def project_update(self, previous_state, averaged_state):
        projected = dict(averaged_state)
        for name, basis in self.bases.items():
            delta = averaged_state[name] - previous_state[name]
            matrix = delta.flatten(1).to(self.device)
            basis = basis.to(matrix)
            orthogonal = matrix - (matrix @ basis) @ basis.T
            projected[name] = previous_state[name] + orthogonal.reshape_as(delta).to(delta)
        return projected

    def finish_task(self, task):
        rng = torch.Generator().manual_seed(self.args.seed + 104729 * (task + 1))
        sketches, original_energy, residual_energy = {}, {}, {}
        self.model.to(self.device).eval()

        def collect(name):
            def hook(layer, inputs):
                values = inputs[0].float()
                patches = F.unfold(values, layer.kernel_size, layer.dilation,
                                   layer.padding, layer.stride)
                patches = patches.transpose(0, 1).reshape(patches.shape[1], -1)
                if patches.shape[1] > 4096:
                    indices = torch.randperm(patches.shape[1], generator=rng)[:4096]
                    patches = patches.index_select(1, indices.to(self.device))
                residual = patches
                if name in self.bases:
                    basis = self.bases[name].to(patches)
                    residual = patches - basis @ (basis.T @ patches)
                width = min(self.args.fot_sketch_size, patches.shape[0] * 5)
                random = torch.randn(patches.shape[1], width, generator=rng).to(self.device)
                projection = (residual @ random).cpu()
                if name in sketches:
                    sketches[name].add_(projection)
                else:
                    sketches[name] = projection
                original_energy[name] = original_energy.get(name, 0.0) + patches.square().sum().item()
                residual_energy[name] = residual_energy.get(name, 0.0) + residual.square().sum().item()
            return hook

        handles = [layer.register_forward_pre_hook(collect(name)) for name, layer in self.layers.items()]
        try:
            with torch.no_grad():
                for dataset in self.stream.train[task]:
                    limit = self.args.fot_samples_per_client
                    if limit and len(dataset) > limit:
                        dataset = Subset(dataset, torch.randperm(len(dataset), generator=rng)[:limit].tolist())
                    loader = DataLoader(dataset, batch_size=min(8, self.args.batch_size))
                    for inputs, _ in loader:
                        self.model(inputs.to(self.device))
        finally:
            for handle in handles:
                handle.remove()

        target = min(0.999, self.args.fot_energy + task * self.args.fot_energy_increment)
        for name, sketch in sketches.items():
            total = original_energy[name]
            remaining = residual_energy[name]
            if total <= 0 or remaining <= (1 - target) * total:
                continue
            prior = self.bases.get(name)
            if prior is not None and prior.shape[1] == prior.shape[0]:
                continue
            sketch = sketch.to(self.device)
            if prior is not None:
                prior = prior.to(sketch)
                sketch -= prior @ (prior.T @ sketch)
            vectors, singular, _ = torch.linalg.svd(sketch, full_matrices=False)
            tolerance = singular[0] * max(sketch.shape) * torch.finfo(sketch.dtype).eps
            nonzero = int((singular > tolerance).sum())
            if nonzero == 0:
                continue
            energy = singular[:nonzero].square().cumsum(0)
            share = 1 - (1 - target) * total / remaining
            count = min(nonzero, int(torch.searchsorted(energy, share * energy[-1])) + 1)
            if prior is not None:
                count = min(count, prior.shape[0] - prior.shape[1])
                vectors = torch.cat((prior, vectors[:, :count]), dim=1)
            else:
                vectors = vectors[:, :count]
            self.bases[name] = torch.linalg.qr(vectors, mode="reduced").Q.cpu()

    def checkpoint(self):
        return {"activation_bases": self.bases}


def add_args(parser):
    parser.add_argument("--fot_energy", type=float, default=0.94)
    parser.add_argument("--fot_energy_increment", type=float, default=0.005)
    parser.add_argument("--fot_sketch_size", type=int, default=128)
    parser.add_argument("--fot_samples_per_client", type=int, default=64,
                        help="activation images per client and task (0 means all images)")


def validate_args(parser, args):
    if not 0 < args.fot_energy < 1 or not math.isfinite(args.fot_energy_increment):
        parser.error("FOT energy must be in (0, 1) and its increment must be finite")
    if args.fot_energy_increment < 0 or args.fot_sketch_size < 1 or args.fot_samples_per_client < 0:
        parser.error("FOT needs a positive sketch width and nonnegative increment and sample limit")
