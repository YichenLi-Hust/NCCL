"""Server-proximal aggregation for federated domain-incremental learning."""

import torch
from torch.nn import functional as F

from .survey.common import avoid_singleton_batch_norm, optimizer_for
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.set_defaults(client_optimizer="sgd", wd=0.0)
    parser.add_argument("--special_lambda", type=float, default=0.25,
                        help="proximal weight for the previous task's final global parameters")
    parser.add_argument("--special_lr_decay", type=float, default=0.96,
                        help="local learning rate multiplier every five epochs within a task")


def validate_args(parser, args):
    if args.special_lambda < 0:
        parser.error("special_lambda must be nonnegative")
    if not 0 < args.special_lr_decay <= 1:
        parser.error("special_lr_decay must be in (0, 1]")


class Special(LocalStrategy):
    """Uniform FedAvg updates followed by the paper's server proximal step."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        if stream.protocol["scenario"] != "domain-il" and args.dataset != "synthetic":
            raise ValueError("SPECIAL requires a domain-incremental stream with shared labels")
        stream.protocol["special"] = {
            "anchor_weight": args.special_lambda,
            "anchor": "previous task's final global parameters after the first task",
            "server_step": "inverse one-based task index",
            "client_aggregation": "uniform over participating clients",
            "local_lr_decay": args.special_lr_decay,
            "local_lr_decay_epochs": 5,
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.server_step = 1.0 / (task + 1)
        self.parameters = dict(self.model.named_parameters())
        # The anchor stays fixed through all rounds of the new task.
        self.anchor = {name: value.detach().cpu().clone()
                       for name, value in self.parameters.items()} if task else {}

    def begin_round(self, task, round_in_task, selected):
        self.elapsed_epochs = (round_in_task - 1) * self.args.epochs

    def fit_client(self, client, loader, device):
        optimizer = optimizer_for(self.model.parameters(), self.args)
        self.model.train()
        for epoch in range(self.args.epochs):
            decay_steps = (self.elapsed_epochs + epoch) // 5
            rate = self.args.lr * self.args.special_lr_decay ** decay_steps
            for group in optimizer.param_groups:
                group["lr"] = rate
            for inputs, labels in loader:
                inputs, labels = inputs.to(device), labels.to(device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    loss = F.cross_entropy(self.model(inputs), labels)
                loss.backward()
                optimizer.step()

    def aggregation_weight(self, client, loader):
        return 1.0

    def project_update(self, previous_state, averaged_state):
        result = dict(averaged_state)
        anchor_share = self.args.special_lambda / (1.0 + self.args.special_lambda)
        for name in self.parameters:
            update = torch.lerp(previous_state[name], averaged_state[name], self.server_step)
            if self.anchor:
                update = torch.lerp(update, self.anchor[name], anchor_share)
            result[name] = update
        return result
