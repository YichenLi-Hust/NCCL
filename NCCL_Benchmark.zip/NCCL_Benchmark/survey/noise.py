"""Class-conditional noisy observations for shared federated Class-IL comparisons."""

import numpy as np
from torch.utils.data import Dataset

from ..data import _labels


class _ObservedShard(Dataset):
    def __init__(self, dataset, indices, targets):
        self.dataset = dataset
        self.indices = indices
        self.targets = targets

    def __len__(self):
        return len(self.targets)

    def __getitem__(self, index):
        image, _ = self.dataset[int(self.indices[index])]
        return image, int(self.targets[index])


def _corrupt_shard(shard, rate, rng):
    """Hide entire classes locally, then downsample hidden-class examples to the target rate."""
    labels = _labels(shard)
    classes = np.unique(labels)
    if len(classes) < 2:
        return _ObservedShard(shard, np.arange(len(shard)), labels), 0
    shuffled = rng.permutation(classes)
    n_hidden = min(len(classes) - 1, max(1, int(np.ceil(len(classes) * rate))))
    visible = shuffled[n_hidden:]
    is_visible = np.isin(labels, visible)
    visible_rows = np.flatnonzero(is_visible)
    hidden_rows = np.flatnonzero(~is_visible)
    retained = min(len(hidden_rows), round(len(visible_rows) * rate / (1 - rate)))
    selected = rng.choice(hidden_rows, size=retained, replace=False)
    indices = np.concatenate((visible_rows, selected))
    targets = np.concatenate((labels[visible_rows], rng.choice(visible, size=retained)))
    return _ObservedShard(shard, indices, targets), retained


def apply_class_noise(stream, rate, seed):
    """Corrupt only training shards, reproducibly and before the strategy can access labels."""
    if not 0 <= rate < 1:
        raise ValueError("--class_noise_rate must be in [0, 1)")
    if rate == 0:
        return stream
    if stream.protocol["scenario"] != "class-il":
        raise ValueError("--class_noise_rate requires a class-incremental stream")
    tasks, audit = [], []
    for task, current in enumerate(stream.train):
        shards, corrupted = [], []
        for client, shard in enumerate(current):
            rng = np.random.default_rng([seed, task, client, 431])
            observed, count = _corrupt_shard(shard, rate, rng)
            shards.append(observed)
            corrupted.append(count)
        tasks.append(tuple(shards))
        audit.append({"task": task + 1, "input_samples": [len(shard) for shard in current],
                      "observed": [len(shard) for shard in shards], "injected": corrupted})
    stream.train = tuple(tasks)
    stream.protocol["train_client_sample_counts"] = [row["observed"] for row in audit]
    stream.protocol["class_noise"] = {"target_rate": rate, "tasks": audit,
                                      "type": "Client-local hidden classes relabeled to visible classes"}
    return stream
