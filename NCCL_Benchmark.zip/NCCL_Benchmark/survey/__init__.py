"""Data streams, training strategies, and utilities for synchronized vision tasks."""
