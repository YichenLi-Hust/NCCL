"""Optimization and distillation utilities for synchronous strategies."""

import torch
from torch.nn import functional as F

from ..training import avoid_singleton_batch_norm, state_copy


def optimizer_for(parameters, args, lr=None, wd=None):
    optimizer = torch.optim.SGD if args.client_optimizer == "sgd" else torch.optim.Adam
    return optimizer(parameters, lr=args.lr if lr is None else lr,
                     weight_decay=args.wd if wd is None else wd)


def distillation(logits, teacher_logits, temperature):
    return F.kl_div(F.log_softmax(logits / temperature, dim=1),
                    F.softmax(teacher_logits / temperature, dim=1),
                    reduction="batchmean") * temperature ** 2
