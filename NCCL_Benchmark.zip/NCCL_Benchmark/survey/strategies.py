"""Client algorithms recovered from the Survey's NCCL benchmark."""

import copy
import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import ConcatDataset, DataLoader, Subset

from .common import avoid_singleton_batch_norm, optimizer_for, state_copy


def supervised_update(model, loader, device, args):
    optimizer = optimizer_for(model.parameters(), args)
    model.train()
    for _ in range(args.epochs):
        for inputs, labels in loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            with avoid_singleton_batch_norm(model, len(inputs)):
                loss = F.cross_entropy(model(inputs), labels)
            loss.backward()
            optimizer.step()


class LocalStrategy:
    uses_local_replay = False

    def __init__(self, model, args, stream, device):
        self.model, self.args, self.stream, self.device = model, args, stream, device
        self.auxiliary_modules = {}

    def begin_task(self, task, old_classes, seen_classes):
        pass

    def build_client_data(self, client, current, replay):
        return current if replay is None else ConcatDataset((current, replay))

    def fit_client(self, client, loader, device):
        supervised_update(self.model, loader, device, self.args)

    def sample_clients(self, eligible, count, rng):
        return rng.choice(eligible, size=count, replace=False).tolist()

    def begin_round(self, task, round_in_task, selected):
        pass

    def aggregation_weight(self, client, loader):
        return len(loader.dataset)

    def project_update(self, previous_state, averaged_state):
        return averaged_state

    def post_round(self):
        pass

    def predict(self, inputs):
        return self.model(inputs)

    def finish_task(self, task):
        pass

    def checkpoint(self):
        return {}


class FedAvg(LocalStrategy):
    uses_local_replay = True


class ReFed(FedAvg):
    """Use personalized gradient norms to retain informative replay samples."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.personal_states = {}

    def select_replay(self, client, candidates, capacity):
        if len(candidates) <= capacity or capacity == 0:
            return Subset(candidates, range(min(capacity, len(candidates))))
        model = copy.deepcopy(self.model).to(self.device)
        if client in self.personal_states:
            model.load_state_dict(self.personal_states[client])
        model.train()
        optimizer = optimizer_for(model.parameters(), self.args, lr=self.args.survey_refed_lr)
        params = tuple(model.parameters())
        reference = tuple(param.detach() for param in self.model.parameters())
        prox_weight = (1 - self.args.survey_refed_mix) / (2 * self.args.survey_refed_mix)
        scores = np.zeros(len(candidates))
        loader = DataLoader(candidates, batch_size=self.args.batch_size,
                            num_workers=self.args.num_workers)
        for epoch in range(self.args.survey_refed_epochs):
            offset = 0
            for inputs, labels in loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(model, len(inputs)):
                    losses = F.cross_entropy(model(inputs), labels, reduction="none")
                for index, sample_loss in enumerate(losses):
                    gradients = torch.autograd.grad(sample_loss, params, retain_graph=True)
                    squared_norm = sum(gradient.detach().square().sum() for gradient in gradients)
                    scores[offset + index] += (epoch + 1) * squared_norm.sqrt().item()
                proximal = sum((param - anchor).norm() for param, anchor in zip(params, reference))
                (losses.mean() + prox_weight * proximal).backward()
                optimizer.step()
                offset += len(inputs)
        self.personal_states[client] = state_copy(model)
        indices = np.argsort(-scores, kind="stable")[:capacity].tolist()
        return Subset(candidates, indices)

    def checkpoint(self):
        return {"replay_scorers": self.personal_states}


class _FlowCoupling(nn.Module):
    def __init__(self, feature_dim, classes, hidden, permutation):
        super().__init__()
        self.split = feature_dim // 2
        self.register_buffer("permutation", permutation)
        self.register_buffer("inverse", permutation.argsort())
        self.input = nn.Linear(self.split + classes, hidden)
        self.blocks = nn.ModuleList([
            nn.Sequential(nn.Linear(hidden, hidden), nn.LeakyReLU(), nn.Linear(hidden, hidden))
            for _ in range(2)
        ])
        self.output = nn.Linear(hidden, 2 * (feature_dim - self.split))
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def _terms(self, first, labels):
        hidden = F.leaky_relu(self.input(torch.cat((first, labels), dim=1)))
        for block in self.blocks:
            hidden = hidden + block(hidden)
        log_scale, shift = self.output(hidden).chunk(2, dim=1)
        return log_scale.tanh(), shift

    def forward(self, values, labels):
        first, rest = values[:, self.permutation].split((self.split, values.shape[1] - self.split), dim=1)
        log_scale, shift = self._terms(first, labels)
        return torch.cat((first, rest * log_scale.exp() + shift), dim=1), log_scale.sum(1)

    def invert(self, values, labels):
        first, rest = values.split((self.split, values.shape[1] - self.split), dim=1)
        log_scale, shift = self._terms(first, labels)
        return torch.cat((first, (rest - shift) * (-log_scale).exp()), dim=1)[:, self.inverse]


class _ConditionalFlow(nn.Module):
    def __init__(self, features, classes, hidden, layers):
        super().__init__()
        self.features, self.classes = features, classes
        self.transforms = nn.ModuleList([
            _FlowCoupling(features, classes, hidden, torch.arange(features - 1, -1, -1)
                          if layer < layers // 2 else torch.randperm(features))
            for layer in range(layers)
        ])

    def log_prob_and_noise(self, values, labels):
        context = F.one_hot(labels, self.classes).to(values.dtype)
        log_det = values.new_zeros(len(values))
        for layer in self.transforms:
            values, correction = layer(values, context)
            log_det = log_det + correction
        return log_det - 0.5 * (values.square() + math.log(2 * math.pi)).sum(1), values

    def sample(self, labels):
        values = torch.randn(len(labels), self.features, device=labels.device)
        context = F.one_hot(labels, self.classes).to(values.dtype)
        for layer in reversed(self.transforms):
            values = layer.invert(values, context)
        return values


def _soft_target_loss(logits, teacher):
    return -(F.log_softmax(logits / 2, dim=1) * F.softmax(teacher / 2, dim=1)).sum(1).mean()


class AFFCL(LocalStrategy):
    """Conditional feature-flow replay with density weighting and two teachers."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        feature_dim = model.fc.in_features
        if args.model == "resnet18":
            # The original AF-FCL classifier uses a stride-one 3x3 input stem.
            model.conv1 = nn.Conv2d(stream.channels, 64, 3, padding=1, bias=False)
            nn.init.kaiming_normal_(model.conv1.weight, mode="fan_out", nonlinearity="relu")
            model.maxpool = nn.Identity()
        model.fc = nn.Sequential(nn.Linear(feature_dim, feature_dim), nn.LeakyReLU(),
                                 nn.Linear(feature_dim, feature_dim), nn.LeakyReLU(),
                                 nn.Linear(feature_dim, stream.num_classes))
        model.to(device)
        self.flow = _ConditionalFlow(feature_dim, stream.num_classes,
                                     args.survey_flow_width or feature_dim, args.survey_flow_layers).to(device)
        self.auxiliary_modules = {"flow": self.flow}
        self.old_model = None
        self.old_flow = None

    def begin_task(self, task, old_classes, seen_classes):
        self.old_classes = torch.as_tensor(old_classes, device=self.device, dtype=torch.long)
        self.seen_classes = torch.as_tensor(seen_classes, device=self.device, dtype=torch.long)
        if old_classes:
            self.old_model = copy.deepcopy(self.model).eval().requires_grad_(False)
            self.old_flow = copy.deepcopy(self.flow).eval().requires_grad_(False)

    def _sample_labels(self, classes, count):
        return classes[torch.randint(len(classes), (count,), device=classes.device)]

    def _replay_weight(self, features, labels, generated, targets):
        log_likelihood, noise = self.flow.log_prob_and_noise(features, labels)
        _, generated_noise = self.flow.log_prob_and_noise(generated, targets)
        mean_density = (log_likelihood / features.shape[1]).exp().mean()
        weights = mean_density.expand(len(generated)).clone()
        for label in labels.unique():
            same_class = targets == label
            local_noise = noise[labels == label]
            variance = local_noise.var(dim=0, unbiased=False).clamp_min(1e-3)
            difference = generated_noise[same_class] - local_noise.mean(0)
            density = (-0.5 * (difference.square() / variance)).exp() / (2 * math.pi * variance).sqrt()
            weights[same_class] = density.mean(dim=1)
        return weights * (0.8 * mean_density + 0.2)

    def fit_client(self, client, loader, device):
        round_model = copy.deepcopy(self.model).eval().requires_grad_(False) if self.old_model else None
        self.model.train()
        self.flow.train()
        flow_optimizer = torch.optim.Adam(self.flow.parameters(), lr=self.args.lr, weight_decay=self.args.wd)
        model_optimizer = torch.optim.Adam(self.model.parameters(), lr=self.args.lr, weight_decay=self.args.wd)
        replay_optimizer = torch.optim.Adam(self.model.fc[2].parameters(), lr=self.args.lr,
                                            weight_decay=self.args.wd)
        flow_epochs = self.args.epochs if self.old_flow is None else max(1, self.args.epochs // 2)
        for _ in range(flow_epochs):
            for inputs, labels in loader:
                inputs, labels = inputs.to(device), labels.to(device)
                with torch.no_grad(), avoid_singleton_batch_norm(self.model, len(inputs)):
                    features = self.model.forward_features(inputs)
                    if self.old_flow is not None:
                        past_labels = self._sample_labels(self.old_classes, len(labels))
                        past_features = self.old_flow.sample(past_labels)
                log_prob, _ = self.flow.log_prob_and_noise(features, labels)
                loss = -log_prob.mean()
                if self.old_flow is not None:
                    previous_prob, _ = self.flow.log_prob_and_noise(past_features, past_labels)
                    loss = loss - 0.4 * previous_prob.mean()
                flow_optimizer.zero_grad(set_to_none=True)
                loss.backward()
                flow_optimizer.step()

        for _ in range(self.args.epochs):
            for inputs, labels in loader:
                inputs, labels = inputs.to(device), labels.to(device)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    features = self.model.forward_features(inputs)
                if round_model is not None:
                    with torch.no_grad():
                        replay_labels = self._sample_labels(self.seen_classes, len(labels))
                        replay_features = self.flow.sample(replay_labels)
                        weights = self._replay_weight(features, labels, replay_features, replay_labels)
                        teacher_replay = [teacher.fc(replay_features) for teacher in (self.old_model, round_model)]
                    replay_logits = self.model.fc(replay_features)
                    replay_loss = (F.cross_entropy(replay_logits, replay_labels, reduction="none") * weights).mean()
                    replay_loss = 0.1 * replay_loss + 0.002 * sum(
                        _soft_target_loss(replay_logits, teacher) for teacher in teacher_replay
                    )
                    replay_optimizer.zero_grad(set_to_none=True)
                    replay_loss.backward()
                    replay_optimizer.step()

                logits = self.model.fc(features)
                loss = F.cross_entropy(logits, labels)
                if round_model is not None:
                    with torch.no_grad():
                        teacher_features = [teacher.forward_features(inputs) for teacher in (self.old_model, round_model)]
                        teacher_logits = [teacher.fc(rep) for teacher, rep in
                                          zip((self.old_model, round_model), teacher_features)]
                    loss = loss + 0.1 * sum(F.mse_loss(features, rep) for rep in teacher_features)
                    loss = loss + 0.02 * sum(_soft_target_loss(logits, teacher) for teacher in teacher_logits)
                model_optimizer.zero_grad(set_to_none=True)
                loss.backward()
                model_optimizer.step()
