"""Section VII class- and domain-incremental data streams."""

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from torch.utils.data import Dataset, Subset

from ..data import _labels, _synthetic, non_iid_partition_with_dirichlet_distribution


CLASS_TASK_COUNTS = {"cifar10": 5, "cifar100": 10, "tinyimagenet": 10, "synthetic": 3}
DOMAINS = {
    "digit10": ("MNIST", "EMNIST", "USPS", "SVHN"),
    "office31": ("Amazon", "Webcam", "DSLR"),
    "officecaltech10": ("Amazon", "Caltech", "Webcam", "DSLR"),
}
DATASETS = tuple(name for name in CLASS_TASK_COUNTS if name != "synthetic") + tuple(DOMAINS) + ("synthetic",)
_CIFAR_MEAN = (0.49139968, 0.48215827, 0.44653124)
_CIFAR_STD = (0.24703233, 0.24348505, 0.26158768)
_IMAGENET_MEAN = (0.485, 0.456, 0.406)
_IMAGENET_STD = (0.229, 0.224, 0.225)
_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp", ".ppm"}


@dataclass
class TaskStream:
    train: tuple
    test: tuple
    task_classes: tuple
    task_names: tuple
    num_classes: int
    image_size: int
    channels: int
    mean: tuple
    std: tuple
    protocol: dict

    @property
    def num_tasks(self):
        return len(self.task_names)


class FolderImages(Dataset):
    def __init__(self, samples, transform):
        self.samples = samples
        self.targets = [label for _, label in samples]
        self.transform = transform

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        from PIL import Image

        path, label = self.samples[index]
        with Image.open(path) as image:
            return self.transform(image.convert("RGB")), label


def _seed(seed, task):
    return int(np.random.SeedSequence([seed, task]).generate_state(1)[0])


def _normalize_name(name):
    return "".join(char for char in name.casefold() if char.isalnum())


def _named_child(root, *names):
    expected = {_normalize_name(name) for name in names}
    if root.is_dir():
        return next(
            (child for child in sorted(root.iterdir())
             if child.is_dir() and _normalize_name(child.name) in expected),
            None,
        )
    return None


def _image_classes(root):
    if not root.is_dir():
        raise FileNotFoundError(f"Dataset directory not found: {root}")
    classes = {}
    for directory in sorted(root.iterdir()):
        if not directory.is_dir() or directory.name.startswith("."):
            continue
        paths = sorted(
            path for path in directory.rglob("*")
            if path.is_file() and path.suffix.lower() in _IMAGE_SUFFIXES
            and all(not part.startswith(".") for part in path.relative_to(directory).parts)
        )
        if paths:
            name = directory.name.casefold()
            if name in classes:
                raise ValueError(f"Duplicate class directory for {name} in {root}")
            classes[name] = paths
    return classes


def _folder_samples(root, label_names):
    images = _image_classes(root)
    if set(images) != set(label_names):
        missing = sorted(set(label_names) - set(images))
        extra = sorted(set(images) - set(label_names))
        raise ValueError(f"Class directories in {root} do not match the label map (missing={missing}, extra={extra})")
    return _labeled_samples(images, label_names)


def _labeled_samples(images, label_names):
    return [(path, label) for label, name in enumerate(label_names) for path in images[name]]


def _tiny_imagenet(root):
    from torchvision import transforms

    if not (root / "train").is_dir():
        root = _named_child(root, "tiny-imagenet-200", "tiny-imagenet", "tinyimagenet200") or root
    images = _image_classes(root / "train")
    label_names = sorted(images)
    if len(label_names) != 200:
        raise ValueError(f"Expected 200 Tiny-ImageNet classes in {root / 'train'}; found {len(label_names)}")

    normalize = transforms.Normalize(_CIFAR_MEAN, _CIFAR_STD)
    train_transform = transforms.Compose([
        transforms.Resize((64, 64)), transforms.RandomHorizontalFlip(), transforms.ToTensor(), normalize,
    ])
    test_transform = transforms.Compose([transforms.Resize((64, 64)), transforms.ToTensor(), normalize])
    train = FolderImages(_labeled_samples(images, label_names), train_transform)

    annotations = root / "val" / "val_annotations.txt"
    if (root / "test").is_dir() and any((root / "test" / name).is_dir() for name in label_names):
        samples = _folder_samples(root / "test", label_names)
        split = "User-provided labeled test folders"
    elif annotations.is_file():
        label_ids = {name: index for index, name in enumerate(label_names)}
        samples = []
        filenames = set()
        for line in annotations.read_text(encoding="utf-8").splitlines():
            fields = line.split()
            if not fields:
                continue
            if len(fields) < 2:
                raise ValueError(f"Incomplete Tiny-ImageNet validation annotation: {line}")
            filename, name = fields[:2]
            if Path(filename).name != filename or filename in filenames or name.casefold() not in label_ids:
                raise ValueError(f"Invalid Tiny-ImageNet validation annotation: {line}")
            path = root / "val" / "images" / filename
            if not path.is_file():
                raise FileNotFoundError(f"Tiny-ImageNet annotated image not found: {path}")
            samples.append((path, label_ids[name.casefold()]))
            filenames.add(filename)
        if len({label for _, label in samples}) != len(label_names):
            raise ValueError("Tiny-ImageNet validation annotations must cover all training classes")
        split = "Official labeled validation split"
    else:
        samples = _folder_samples(root / "val", label_names)
        split = "Labeled validation folders"
    return train, FolderImages(samples, test_transform), 200, 64, {
        "split": split,
        "train_augmentation": "horizontal flip",
        "eval_transform": "deterministic resize",
    }


def _class_incremental(args, dataset, root):
    mean, std = _CIFAR_MEAN, _CIFAR_STD
    if dataset == "synthetic":
        count = getattr(args, "synthetic_samples_per_class", 12)
        train = _synthetic(count, args.seed)
        test = _synthetic(max(4, count // 3), _seed(args.seed, 10000))
        num_classes, image_size, mean, std = 6, 32, (0.0,) * 3, (1.0,) * 3
        metadata = {"split": "Independently generated train and test images"}
    elif dataset == "tinyimagenet":
        train, test, num_classes, image_size, metadata = _tiny_imagenet(root)
    else:
        from torchvision import datasets, transforms

        constructors = {"cifar10": (datasets.CIFAR10, 10), "cifar100": (datasets.CIFAR100, 100)}
        constructor, num_classes = constructors[dataset]
        image_size = 32
        transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean, std)])
        download = getattr(args, "download", False)
        train = constructor(str(root), train=True, transform=transform, download=download)
        test = constructor(str(root), train=False, transform=transform, download=download)
        metadata = {"split": "Official train/test split", "train_augmentation": "none"}

    requested_tasks = getattr(args, "num_tasks", None)
    if getattr(args, "baseline", "").casefold() == "uopp":
        from ..uopp import class_groups
        classes = class_groups(num_classes, requested_tasks, args)
    else:
        num_tasks = CLASS_TASK_COUNTS[dataset] if requested_tasks is None else requested_tasks
        if num_tasks < 1 or num_classes % num_tasks:
            raise ValueError(f"num_tasks={num_tasks} must be a positive divisor of the class count {num_classes}")
        classes = tuple(tuple(group.tolist()) for group in np.split(np.arange(num_classes), num_tasks))
    train_labels, test_labels = _labels(train), _labels(test)
    train_tasks = tuple(Subset(train, np.flatnonzero(np.isin(train_labels, labels)).tolist()) for labels in classes)
    test_tasks = tuple(Subset(test, np.flatnonzero(np.isin(test_labels, labels)).tolist()) for labels in classes)
    names = tuple(f"classes_{labels[0]}_{labels[-1]}" for labels in classes)
    return train_tasks, test_tasks, classes, names, num_classes, image_size, mean, std, metadata


def _digit_domains(args, root):
    from PIL import Image
    from torchvision import datasets, transforms

    train_tasks, test_tasks = [], []
    for name in DOMAINS["digit10"]:
        constructor = getattr(datasets, name)
        steps = [transforms.Resize((32, 32))]
        options = {"root": str(root / name.lower()), "download": getattr(args, "download", False)}
        if name != "SVHN":
            steps.append(transforms.Grayscale(num_output_channels=3))
        if name == "EMNIST":
            options["split"] = "digits"
            operation = Image.Transpose.TRANSPOSE if hasattr(Image, "Transpose") else Image.TRANSPOSE
            steps.insert(0, _TransposeEMNIST(operation))
        steps.extend([transforms.ToTensor(), transforms.Normalize((0.5,) * 3, (0.5,) * 3)])
        options["transform"] = transforms.Compose(steps)
        if name == "SVHN":
            train = constructor(split="train", **options)
            test = constructor(split="test", **options)
            # Match the target interface used by MNIST, EMNIST, USPS and CIFAR.
            train.targets, test.targets = train.labels, test.labels
        else:
            train = constructor(train=True, **options)
            test = constructor(train=False, **options)
        train_tasks.append(train)
        test_tasks.append(test)
    return train_tasks, test_tasks, 10, 32, (0.5,) * 3, (0.5,) * 3, {
        "split": "Official train/test split of each digit domain",
        "digit_preprocessing": "Resize to 32x32, replicate grayscale to three channels, transpose EMNIST digits and preserve SVHN color",
        "train_augmentation": "none",
    }


@dataclass
class _TransposeEMNIST:
    operation: int

    def __call__(self, image):
        return image.transpose(self.operation)


def _office_domains(args, dataset, root):
    from torchvision import transforms

    num_classes = 31 if dataset == "office31" else 10
    domain_names = DOMAINS[dataset]
    aliases = ("office-31", "Office31") if num_classes == 31 else (
        "office-caltech-10", "OfficeCaltech", "Office-Caltech",
    )
    if not _named_child(root, domain_names[0]):
        root = _named_child(root, *aliases) or root
    fraction = getattr(args, "survey_train_fraction", 0.8)
    if not 0 < fraction < 1:
        raise ValueError("survey_train_fraction must be between 0 and 1")
    normalization = transforms.Normalize(_IMAGENET_MEAN, _IMAGENET_STD)
    train_transform = transforms.Compose([
        transforms.Resize((256, 256)), transforms.RandomCrop(224), transforms.ToTensor(), normalization,
    ])
    test_transform = transforms.Compose([
        transforms.Resize((256, 256)), transforms.CenterCrop(224), transforms.ToTensor(), normalization,
    ])
    train_tasks, test_tasks = [], []
    label_names = None
    for index, domain in enumerate(domain_names):
        aliases = (domain, "Caltech10") if domain == "Caltech" else (domain,)
        domain_root = _named_child(root, *aliases)
        if domain_root is None:
            raise FileNotFoundError(f"Domain {domain} not found under {root}")
        domain_root = _named_child(domain_root, "images") or domain_root
        images = _image_classes(domain_root)
        if label_names is None:
            label_names = sorted(images)
        if len(label_names) != num_classes or set(images) != set(label_names):
            raise ValueError(f"Expected the same {num_classes} class folders in each domain; found {len(images)} in {domain_root}")
        rng = np.random.default_rng(_seed(args.seed, index))
        training, evaluation = [], []
        for label, name in enumerate(label_names):
            paths = images[name]
            shuffled = [(paths[item], label) for item in rng.permutation(len(paths))]
            size = min(len(paths) - 1, max(1, round(fraction * len(paths)))) if len(paths) > 1 else 1
            training.extend(shuffled[:size])
            evaluation.extend(shuffled[size:])
        train_tasks.append(FolderImages(training, train_transform))
        test_tasks.append(FolderImages(evaluation, test_transform))
    return train_tasks, test_tasks, num_classes, 224, _IMAGENET_MEAN, _IMAGENET_STD, {
        "split": "Seeded stratified train/test split of each domain",
        "office_train_fraction": fraction,
        "label_names": label_names,
        "train_augmentation": "random crop",
        "eval_transform": "deterministic center crop",
    }


def _domain_incremental(args, dataset, root):
    names = DOMAINS[dataset]
    requested_tasks = getattr(args, "num_tasks", None)
    if requested_tasks not in (None, len(names)):
        raise ValueError(f"{dataset} has {len(names)} domains and requires one task per domain")
    domain_order = getattr(args, "survey_domain_order", None)
    if domain_order is not None:
        domain_indices = {name.casefold(): index for index, name in enumerate(names)}
        requested = [name.strip().casefold() for name in domain_order.split(",")]
        if len(requested) != len(names) or set(requested) != set(domain_indices):
            raise ValueError(f"survey_domain_order must list each domain once ({', '.join(names)})")
        order = [domain_indices[name] for name in requested]
    else:
        order = list(range(len(names)))
    if dataset == "digit10":
        train, test, num_classes, image_size, mean, std, metadata = _digit_domains(args, root)
    else:
        train, test, num_classes, image_size, mean, std, metadata = _office_domains(args, dataset, root)
    classes = (tuple(range(num_classes)),) * len(names)
    return ([train[index] for index in order], [test[index] for index in order], classes,
            tuple(names[index] for index in order), num_classes, image_size, mean, std, metadata)


def load_survey_data(args):
    """Build a reproducible client split for each task without preloading image files."""
    dataset = _normalize_name(args.dataset)
    root = Path(args.data_dir)
    if dataset in CLASS_TASK_COUNTS:
        if getattr(args, "survey_domain_order", None) is not None:
            raise ValueError("survey_domain_order requires a domain-incremental dataset")
        scenario = "class-il"
        task_data = _class_incremental(args, dataset, root)
    elif dataset in DOMAINS:
        scenario = "domain-il"
        task_data = _domain_incremental(args, dataset, root)
    else:
        raise ValueError(f"Unsupported Survey dataset {args.dataset!r}; choose from {', '.join(DATASETS)}")
    train_tasks, test_tasks, classes, names, num_classes, image_size, mean, std, metadata = task_data
    if any(len(task) == 0 for task in (*train_tasks, *test_tasks)):
        raise ValueError("Each Survey task requires nonempty train and test splits")

    by_client = []
    for task, training in enumerate(train_tasks):
        partition = non_iid_partition_with_dirichlet_distribution(
            _labels(training), args.client_num_in_total, num_classes, args.alpha, seed=_seed(args.seed, task),
        )
        by_client.append(tuple(Subset(training, indices) for indices in partition.values()))
    protocol = {
        "dataset": dataset,
        "scenario": scenario,
        "task_names": names,
        "task_classes": classes,
        "dirichlet_alpha": args.alpha,
        "client_partition": "Independent per-class Dirichlet proportions within each task using benchmark seed",
        "train_client_sample_counts": [[len(client) for client in clients] for clients in by_client],
        "test_sample_counts": [len(test) for test in test_tasks],
        "preprocessing": {"image_size": image_size, "channels": 3, "mean": mean, "std": std},
        **metadata,
    }
    return TaskStream(tuple(by_client), tuple(test_tasks), classes, names, num_classes, image_size, 3, mean, std, protocol)
