"""Generative replay methods reconstructed from the NCCL Survey archive.

FedCIL: Qi et al., ICLR 2023 (https://openreview.net/forum?id=cRxYWKiTan).
TARGET: Zhang et al., ICCV 2023 (https://arxiv.org/abs/2303.06937).
"""

import copy
import math
from contextlib import contextmanager

import torch
from torch import nn
from torch.nn import functional as F

from ..models.cgan import ConditionalGenerator

from .common import avoid_singleton_batch_norm, distillation, optimizer_for, state_copy
from .strategies import LocalStrategy


def _balanced_labels(classes, count):
    labels = classes[torch.randperm(classes.numel(), device=classes.device)]
    return labels.repeat(math.ceil(count / labels.numel()))[:count]


def _freeze(module):
    return copy.deepcopy(module).eval().requires_grad_(False)


def _sample(pool, count):
    images, labels = pool
    indices = torch.randint(len(images), (count,), device=images.device)
    return images[indices], labels[indices]


class _ImageGenerator(nn.Module):
    """TARGET's unconditional generator, adapted to the input image resolution."""

    def __init__(self, latent_dim, width, channels, image_size):
        super().__init__()
        self.size = min(math.ceil(image_size / 4), 16)
        self.image_size = image_size
        self.projection = nn.Linear(latent_dim, width * 2 * self.size ** 2)
        self.blocks = nn.Sequential(
            nn.BatchNorm2d(width * 2),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(width * 2, width * 2, 3, padding=1, bias=False),
            nn.BatchNorm2d(width * 2),
            nn.LeakyReLU(0.2),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(width * 2, width, 3, padding=1, bias=False),
            nn.BatchNorm2d(width),
            nn.LeakyReLU(0.2),
            nn.Conv2d(width, channels, 3, padding=1),
        )

    def forward(self, noise):
        features = self.projection(noise).reshape(len(noise), -1, self.size, self.size)
        images = self.blocks(features)
        if images.shape[-1] != self.image_size:
            images = F.interpolate(
                images, size=(self.image_size, self.image_size), mode="bilinear", align_corners=False
            )
        return images.sigmoid()


@contextmanager
def _batch_norm_matching(teacher):
    losses = []

    def measure(layer, inputs):
        value = inputs[0]
        dims = (0, *range(2, value.ndim))
        mean = value.mean(dim=dims)
        variance = value.var(dim=dims, unbiased=False)
        losses.append((mean - layer.running_mean).norm() + (variance - layer.running_var).norm())

    handles = [
        layer.register_forward_pre_hook(measure)
        for layer in teacher.modules()
        if isinstance(layer, nn.BatchNorm2d) and layer.track_running_stats
    ]
    try:
        yield losses
    finally:
        for handle in handles:
            handle.remove()


class _GeneratorMethod(LocalStrategy):
    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.latent_dim = args.survey_latent_dim
        self.mean = torch.tensor(getattr(stream, "mean", None) or (0.0,) * stream.channels,
                                 device=device).view(1, -1, 1, 1)
        self.std = torch.tensor(getattr(stream, "std", None) or (1.0,) * stream.channels,
                                device=device).view(1, -1, 1, 1)

    def _normalize(self, pixels):
        return (pixels - self.mean) / self.std

    def _noise(self, count):
        return torch.randn(count, self.latent_dim, device=self.device)


class Target(_GeneratorMethod):
    """Frozen-teacher inversion on the server and soft-label replay on clients."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.image_size, self.channels = stream.image_size, stream.channels
        self.replay = None

    def begin_task(self, task, old_classes, seen_classes):
        self.replay = None
        if not len(old_classes) or self.args.survey_replay_samples == 0:
            return

        args = self.args
        classes = torch.as_tensor(old_classes, dtype=torch.long, device=self.device)
        teacher = _freeze(self.model)
        student = copy.deepcopy(self.model).train()
        for layer in student.modules():
            if callable(getattr(layer, "reset_parameters", None)):
                layer.reset_parameters()
        generator = _ImageGenerator(
            self.latent_dim, args.survey_gan_width, self.channels, self.image_size
        ).to(self.device)
        g_optimizer = torch.optim.Adam(generator.parameters(), lr=args.lr, betas=(0.5, 0.99))
        s_optimizer = torch.optim.Adam(student.parameters(), lr=args.lr)
        batch_size = max(2, args.batch_size)

        for _ in range(args.survey_generator_steps):
            labels = _balanced_labels(classes, batch_size)
            images = self._normalize(generator(self._noise(batch_size)))
            with _batch_norm_matching(teacher) as bn_losses:
                teacher_output = teacher(images)
            student.eval().requires_grad_(False)
            student_output = student(images)
            teacher_seen, student_seen = teacher_output[:, classes], student_output[:, classes]
            disagreement = teacher_seen.argmax(1) != student_seen.argmax(1)
            boundary = F.kl_div(
                F.log_softmax(student_seen, dim=1),
                F.softmax(teacher_seen, dim=1),
                reduction="none",
            ).sum(dim=1)
            loss = F.cross_entropy(teacher_output, labels) - (disagreement * boundary).mean()
            if bn_losses:
                loss = loss + 0.1 * torch.stack(bn_losses).sum()
            g_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            g_optimizer.step()

            student.train().requires_grad_(True)
            s_optimizer.zero_grad(set_to_none=True)
            distillation(student(images.detach()), teacher_output.detach(), temperature=20).backward()
            s_optimizer.step()

        generator.eval()
        replay_images, replay_scores = [], []
        with torch.no_grad():
            for offset in range(0, args.survey_replay_samples, batch_size):
                count = min(batch_size, args.survey_replay_samples - offset)
                images = self._normalize(generator(self._noise(count)))
                replay_images.append(images.cpu())
                replay_scores.append(teacher(images).cpu())
        self.replay = torch.cat(replay_images), torch.cat(replay_scores)

    def fit_client(self, client, loader, device):
        args = self.args
        self.model.train()
        optimizer = optimizer_for(self.model.parameters(), args)
        for _ in range(args.epochs):
            for images, labels in loader:
                images, labels = images.to(device), labels.to(device)
                optimizer.zero_grad(set_to_none=True)
                if self.replay is None:
                    with avoid_singleton_batch_norm(self.model, len(labels)):
                        loss = F.cross_entropy(self.model(images), labels)
                else:
                    replay_images, teacher_scores = _sample(self.replay, len(labels))
                    output = self.model(torch.cat((images, replay_images.to(device))))
                    loss = F.cross_entropy(output[:len(labels)], labels)
                    loss = loss + 20 * distillation(
                        output[len(labels):], teacher_scores.to(device), temperature=20
                    )
                loss.backward()
                optimizer.step()


class FedCIL(_GeneratorMethod):
    """Auxiliary classifier GAN, old-generator replay and model consolidation."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.image_size = stream.image_size
        self.generator = ConditionalGenerator(
            stream.num_classes, stream.channels, min(self.image_size, 64),
            args.survey_latent_dim, args.survey_gan_width,
        ).to(device)
        self.real_fake = nn.Linear(model.fc.in_features, 1).to(device)
        self.auxiliary_modules = {"generator": self.generator, "real_fake": self.real_fake}
        self.previous_generator = None
        self.uploads = []

    def begin_task(self, task, old_classes, seen_classes):
        self.old_classes = torch.as_tensor(old_classes, dtype=torch.long, device=self.device)
        self.seen_classes = torch.as_tensor(seen_classes, dtype=torch.long, device=self.device)
        self.previous_generator = _freeze(self.generator) if self.old_classes.numel() else None
        self.steps_used = {}

    def _generate(self, generator, labels):
        images = generator(self._noise(len(labels)), labels)
        if images.shape[-1] != self.image_size:
            images = F.interpolate(
                images, size=(self.image_size, self.image_size), mode="bilinear", align_corners=False
            )
        return self._normalize(images)

    @torch.no_grad()
    def _replay_pool(self, generator, count):
        labels = _balanced_labels(self.old_classes, count)
        images = [self._generate(generator, batch).cpu() for batch in labels.split(self.args.batch_size)]
        return torch.cat(images), labels.cpu()

    def _discriminate(self, images):
        features = self.model.forward_features(images)
        return self.model.fc(features), self.real_fake(features).flatten()

    def _optimizers(self):
        classifier_parameters = [*self.model.parameters(), *self.real_fake.parameters()]
        discriminator = optimizer_for(classifier_parameters, self.args)
        generator = torch.optim.Adam(
            self.generator.parameters(), lr=self.args.lr, betas=(0.5, 0.99), amsgrad=True
        )
        return discriminator, generator

    def _discriminator_step(self, images, labels, optimizer, consistency):
        self.model.train()
        fake_labels = _balanced_labels(self.seen_classes, len(labels))
        self.generator.eval()
        with torch.no_grad():
            fake_images = self._generate(self.generator, fake_labels)

        extras = [] if consistency is None else [consistency[0]]
        scores, real_fake = self._discriminate(torch.cat([images, fake_images, *extras]))
        n = len(labels)
        real_scores, fake_scores = scores[:n], scores[n:2 * n]
        loss = F.cross_entropy(real_scores, labels) + F.cross_entropy(fake_scores, fake_labels)
        loss = loss + F.binary_cross_entropy_with_logits(
            real_fake[:2 * n],
            torch.cat((torch.ones_like(real_fake[:n]), torch.zeros_like(real_fake[n:2 * n]))),
        )
        if consistency is not None:
            _, old_size = consistency
            global_scores = scores[2 * n:]
            loss = loss + distillation(
                global_scores[:old_size], real_scores[:old_size].detach(), temperature=20
            )
            loss = loss + distillation(
                global_scores[old_size:], real_scores[old_size:].detach(), temperature=20
            )
            loss = loss + F.cross_entropy(global_scores, labels)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

    def _generator_step(self, count, optimizer):
        self.generator.train()
        self.model.eval()
        labels = _balanced_labels(self.seen_classes, count)
        scores, real_fake = self._discriminate(self._generate(self.generator, labels))
        loss = F.cross_entropy(scores, labels)
        loss = loss + F.binary_cross_entropy_with_logits(real_fake, torch.ones_like(real_fake))
        optimizer.zero_grad(set_to_none=True)
        loss.backward(inputs=tuple(self.generator.parameters()))
        optimizer.step()

    def fit_client(self, client, loader, device):
        args = self.args
        budget = args.survey_fedcil_budget
        steps = self.steps_used.get(client, 0)
        if budget and steps >= budget:
            return
        discriminator, generator = self._optimizers()
        replay = None
        if self.previous_generator is not None and args.survey_replay_samples:
            round_generator = _freeze(self.generator)
            replay = self._replay_pool(self.previous_generator, args.survey_replay_samples)
        for _ in range(args.epochs):
            for images, labels in loader:
                if budget and steps >= budget:
                    break
                images, labels = images.to(device), labels.to(device)
                consistency = None
                if replay is not None:
                    with torch.no_grad():
                        old_count = min(len(labels), args.survey_replay_samples)
                        old_images, old_labels = _sample(replay, old_count)
                        images = torch.cat((old_images.to(device), images))
                        labels = torch.cat((old_labels.to(device), labels))
                        consistency = self._generate(round_generator, labels), old_count

                self._discriminator_step(images, labels, discriminator, consistency)
                steps += 1
                if not budget or steps < budget:
                    self._generator_step(max(2, len(labels)), generator)
                    steps += 1
            if budget and steps >= budget:
                break
        self.steps_used[client] = steps

        if args.survey_replay_samples:
            self.uploads.append(state_copy(self.generator))

    @torch.no_grad()
    def _consolidation_pool(self):
        generator = _freeze(self.generator)
        count = max(1, math.ceil(self.args.survey_replay_samples / len(self.uploads)))
        labels = _balanced_labels(self.seen_classes, count * len(self.uploads))
        images = []
        for state, assigned in zip(self.uploads, labels.split(count)):
            generator.load_state_dict(state)
            images.extend(
                self._generate(generator, batch).cpu() for batch in assigned.split(self.args.batch_size)
            )
        limit = self.args.survey_replay_samples
        return torch.cat(images)[:limit], labels[:limit].cpu()

    def post_round(self):
        if not self.uploads:
            return
        pool = self._consolidation_pool()
        self.uploads.clear()
        discriminator, generator = self._optimizers()
        for _ in range(self.args.survey_generator_steps):
            count = min(len(pool[0]), self.args.batch_size)
            images, labels = _sample(pool, count)
            self._discriminator_step(images.to(self.device), labels.to(self.device), discriminator, None)
            self._generator_step(max(2, count), generator)
