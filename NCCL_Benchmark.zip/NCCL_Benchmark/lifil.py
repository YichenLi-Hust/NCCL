"""Li-FIL feature replay with conditional generation and decoupled updates.

Wang et al., ICML 2026, https://proceedings.mlr.press/v306/wang26du.html
"""

import math

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader

from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.strategies import LocalStrategy


class _FeatureCVAE(nn.Module):
    def __init__(self, feature_dim, classes, latent_dim, width):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(feature_dim + classes, width), nn.SiLU(),
                                     nn.Linear(width, 2 * latent_dim))
        self.decoder = nn.Sequential(nn.Linear(latent_dim + classes, width), nn.SiLU(),
                                     nn.Linear(width, feature_dim))

    def loss(self, features, labels, beta):
        mean, log_variance = self.encoder(torch.cat((features, labels), dim=1)).chunk(2, dim=1)
        log_variance = log_variance.clamp(-10, 10)
        latent = mean + torch.randn_like(mean) * (0.5 * log_variance).exp()
        predictions = self.decode(latent, labels)
        kl = 0.5 * (mean.square() + log_variance.exp() - 1 - log_variance).mean()
        return F.mse_loss(predictions, features) + beta * kl

    def decode(self, noise, labels):
        return self.decoder(torch.cat((noise, labels), dim=1))


def _mmd(current, replay):
    def kernel(left, right):
        return (-torch.cdist(left, right).square() / left.shape[1]).exp()

    return kernel(current, current).mean() + kernel(replay, replay).mean() - 2 * kernel(current, replay).mean()


def _contrastive(current, replay, neighbors, temperature):
    similarities = F.normalize(current, dim=1) @ F.normalize(replay, dim=1).T / temperature
    positive_scores = similarities.topk(min(neighbors, len(replay)), dim=1).values
    return (similarities.logsumexp(dim=1) - positive_scores.logsumexp(dim=1)).mean()


class LiFIL(LocalStrategy):
    """Conditional feature replay for the classifier and alignment for the encoder."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        if stream.protocol['scenario'] != 'class-il':
            raise ValueError('Li-FIL requires a class-incremental stream with disjoint task classes')
        feature_dim = model.fc.in_features
        self.num_classes = stream.num_classes
        self.generator = _FeatureCVAE(feature_dim, stream.num_classes,
                                      args.lifil_latent_dim, args.lifil_generator_width).to(device)
        self.generator_optimizer = torch.optim.Adam(self.generator.parameters(), lr=args.lifil_generator_lr)
        self.clip = args.lifil_clip * math.sqrt(feature_dim)
        self.noise_scale = 2 * self.clip / args.lifil_epsilon
        self.feature_scale = max(1.0, self.noise_scale)
        self.uploads = []
        self.generator_labels = torch.empty(0, dtype=torch.long, device=device)
        self.replay = None
        self.task_uploads = []
        self.task_generated = []
        stream.protocol['lifil'] = {
            'feature_collection': 'final global encoder evaluated on each current client task shard',
            'feature_upload_rows_per_task': self.task_uploads,
            'synthetic_rows_per_task': self.task_generated,
            'upload_noise': {'mechanism': 'clipped features with Laplace noise',
                             'l1_clip': self.clip, 'scale': self.noise_scale},
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.seen_classes = torch.tensor(seen_classes, device=self.device)
        self.class_index = torch.full((self.num_classes,), -1, dtype=torch.long, device=self.device)
        self.class_index[self.seen_classes] = torch.arange(len(seen_classes), device=self.device)
        self.task_generated.append(0)

    @torch.no_grad()
    def begin_round(self, task, round_in_task, selected):
        self.replay = None
        count = min(self.args.survey_replay_samples,
                    max(len(self.stream.train[task][client]) for client in selected))
        if count == 0 or self.generator_labels.numel() == 0:
            return
        order = torch.randperm(self.generator_labels.numel(), device=self.device)
        indices = torch.arange(count, device=self.device) % len(order)
        labels = self.generator_labels[order[indices]]
        conditions = F.one_hot(labels, self.num_classes).float()
        noise = torch.randn(count, self.args.lifil_latent_dim, device=self.device)
        self.generator.eval()
        features = self.generator.decode(noise, conditions) * self.feature_scale
        self.replay = features, labels
        self.task_generated[task] += len(labels)

    def fit_client(self, client, loader, device):
        optimizer = optimizer_for(self.model.parameters(), self.args)
        self.model.train()
        for _ in range(self.args.epochs):
            for inputs, labels in loader:
                inputs, labels = inputs.to(device), labels.to(device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    features = self.model.forward_features(inputs)
                logits = self.model.fc(features).index_select(1, self.seen_classes)
                loss = F.cross_entropy(logits, self.class_index[labels])
                if self.replay is not None:
                    pool, pool_labels = self.replay
                    positions = torch.randperm(len(pool), device=device)[:len(labels)]
                    generated, generated_labels = pool[positions], pool_labels[positions]
                    replay_logits = self.model.fc(generated).index_select(1, self.seen_classes)
                    replay_loss = F.cross_entropy(replay_logits, self.class_index[generated_labels])
                    global_align = _mmd(features, generated)
                    local_align = _contrastive(features, generated, self.args.lifil_neighbors, self.args.lifil_temperature)
                    mix = self.args.lifil_alignment_mix
                    alignment_loss = mix * global_align + (1 - mix) * local_align
                    loss = loss + self.args.lifil_replay_weight * replay_loss + self.args.lifil_alignment_weight * alignment_loss
                if not torch.isfinite(loss):
                    raise FloatingPointError('Li-FIL local training loss became nonfinite')
                loss.backward()
                optimizer.step()

    @torch.no_grad()
    def _collect(self, dataset):
        if len(dataset) < 2:
            return None
        loader = DataLoader(dataset, batch_size=self.args.batch_size, num_workers=self.args.num_workers)
        limit = self.args.lifil_upload_limit
        candidates = None
        for inputs, labels in loader:
            feature = self.model.forward_features(inputs.to(self.device))
            logits = self.model.fc(feature).index_select(1, self.seen_classes)
            confidence = logits.softmax(dim=1).amax(dim=1)
            keep = confidence >= self.args.lifil_confidence
            if not keep.any():
                continue
            batch = feature[keep], labels.to(self.device)[keep], confidence[keep]
            if candidates is not None:
                batch = tuple(torch.cat((left, right)) for left, right in zip(candidates, batch))
            best = batch[-1].topk(min(len(batch[-1]), limit), sorted=False).indices
            candidates = tuple(tensor[best] for tensor in batch)
        if candidates is None or len(candidates[0]) < 2:
            return None
        features, labels, _ = candidates
        pair_count = len(labels) // 2
        pairs = torch.randperm(len(labels), device=self.device)[:2 * pair_count].reshape(-1, 2)
        coefficient = features.new_full((pair_count, 1), self.args.lifil_mixup_alpha)
        mix = torch.distributions.Beta(coefficient, coefficient).sample()
        left, right = pairs.unbind(1)
        features = features[left] * mix + features[right] * (1 - mix)
        labels = F.one_hot(labels, self.num_classes).float()
        labels = labels[left] * mix + labels[right] * (1 - mix)
        features = features * (self.clip / features.abs().sum(dim=1, keepdim=True).clamp_min(self.clip))
        noise = torch.distributions.Laplace(features.new_zeros(()), features.new_tensor(self.noise_scale)).sample(features.shape)
        return ((features + noise) / self.feature_scale).cpu(), labels.cpu()

    def finish_task(self, task):
        self.model.eval()
        available = [result for dataset in self.stream.train[task] if (result := self._collect(dataset)) is not None]
        self.task_uploads.append(0)
        if not available:
            return
        features, labels = (torch.cat(values) for values in zip(*available))
        self.task_uploads[task] = len(features)
        self.uploads.append((features, labels))
        features, labels = (torch.cat(values) for values in zip(*self.uploads))
        self.generator_labels = labels.any(dim=0).nonzero(as_tuple=True)[0].to(self.device)
        self.generator.train()
        for _ in range(self.args.survey_generator_steps):
            batch = torch.randperm(len(features))[:self.args.batch_size]
            loss = self.generator.loss(features[batch].to(self.device), labels[batch].to(self.device),
                                       self.args.lifil_beta)
            if not torch.isfinite(loss):
                raise FloatingPointError('Li-FIL generator loss became nonfinite')
            self.generator_optimizer.zero_grad(set_to_none=True)
            loss.backward()
            self.generator_optimizer.step()

    def checkpoint(self):
        return {'lifil_generator': state_copy(self.generator), 'lifil_class_labels': self.generator_labels.cpu(),
                'lifil_feature_scale': self.feature_scale}


def add_args(parser):
    parser.add_argument('--lifil_confidence', type=float, default=None,
                        help='minimum confidence for feature curation (real runs default to 0.9)')
    parser.add_argument('--lifil_upload_limit', type=int, default=128,
                        help='maximum number of candidate features per client and task, before pairwise mixup')
    parser.add_argument('--lifil_latent_dim', type=int, default=64)
    parser.add_argument('--lifil_generator_width', type=int, default=128)
    parser.add_argument('--lifil_generator_lr', type=float, default=1e-4)
    parser.add_argument('--lifil_beta', type=float, default=1.0)
    parser.add_argument('--lifil_mixup_alpha', type=float, default=2.0)
    parser.add_argument('--lifil_clip', type=float, default=1.5, help='L1 clipping coefficient times sqrt(feature dimension)')
    parser.add_argument('--lifil_epsilon', type=float, default=1.0, help='Laplace mechanism feature-noise scale parameter')
    parser.add_argument('--lifil_replay_weight', type=float, default=1.0)
    parser.add_argument('--lifil_alignment_weight', type=float, default=1.0)
    parser.add_argument('--lifil_alignment_mix', type=float, default=0.5, help='weight of MMD relative to contrastive alignment')
    parser.add_argument('--lifil_neighbors', type=int, default=5)
    parser.add_argument('--lifil_temperature', type=float, default=0.1)


def validate_args(parser, args):
    if args.lifil_confidence is None:
        args.lifil_confidence = 0.0 if args.smoke else 0.9
    if not 0 <= args.lifil_confidence <= 1 or not 0 <= args.lifil_alignment_mix <= 1:
        parser.error('Li-FIL confidence and alignment mixture must be in [0, 1]')
    for name in ('lifil_latent_dim', 'lifil_generator_width', 'lifil_generator_lr', 'lifil_mixup_alpha',
                 'lifil_clip', 'lifil_epsilon', 'lifil_neighbors', 'lifil_temperature'):
        if getattr(args, name) <= 0:
            parser.error(f'{name} must be positive')
    for name in ('lifil_beta', 'lifil_replay_weight', 'lifil_alignment_weight'):
        if getattr(args, name) < 0:
            parser.error(f'{name} must be nonnegative')
    if args.lifil_upload_limit < 2:
        parser.error('lifil_upload_limit must be at least 2 for pairwise mixup')
