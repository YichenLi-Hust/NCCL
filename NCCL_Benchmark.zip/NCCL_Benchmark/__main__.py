"""Command-line interface for the federated continual learning benchmark."""

import argparse
from datetime import datetime, timezone
from importlib import import_module
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys

from .catalog import WORKS, find_work
from .presets import reference_settings
from .registry import METHODS, dataset_id, get_method
from .upstream import RECIPES, run_upstream


def _load_backend(method):
    module, function = method.backend.split(":", 1)
    return getattr(import_module(module), function)


def _default_output(method, dataset, seed):
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return Path("results", method.id, dataset, f"seed{seed}-{stamp}")


def _run(method, args, overrides):
    backend = _load_backend(method)
    if "--help" in overrides or "-h" in overrides:
        return backend(["--baseline", method.baseline, "--help"])

    smoke = args.profile == "smoke"
    if smoke and args.dataset not in (None, "synthetic"):
        raise ValueError("the smoke profile uses synthetic data; omit --dataset or use synthetic")
    default_dataset = "cifar100" if "cifar100" in method.datasets else method.datasets[0]
    dataset = "synthetic" if smoke else (args.dataset or default_dataset)
    if dataset not in (*method.datasets, "synthetic"):
        raise ValueError(f"{method.id} supports {', '.join(method.datasets)} and synthetic")
    settings = reference_settings(method, dataset) if args.profile == "reference" else {}
    options = ["--baseline", method.baseline, "--dataset", dataset, "--seed", str(args.seed)]
    if args.data_dir is not None:
        options.extend(("--data_dir", args.data_dir))
    if smoke:
        options.append("--smoke")
    for name, value in settings.items():
        options.extend((f"--{name}", str(value)))
    options.extend(overrides)
    output = Path(args.output_dir) if args.output_dir else _default_output(method, dataset, args.seed)
    options.extend(("--output_dir", str(output)))
    output.mkdir(parents=True, exist_ok=True)
    lock = output / ".nccl-running"
    try:
        with lock.open("x", encoding="utf-8"):
            pass
    except FileExistsError as error:
        raise ValueError(f"{output} is reserved by another run; choose a new output directory") from error
    try:
        if any(path != lock for path in output.iterdir()):
            raise ValueError(f"{output} already contains files; choose a new output directory")
        result = backend(options)
        for filename in ("model.pt", "metrics.csv"):
            if not (output / filename).is_file():
                raise RuntimeError(f"{method.id} finished without producing {output / filename}")
        record = {
            "method": method.id,
            "protocol": method.protocol,
            "profile": args.profile,
            "source": method.source,
            "config": vars(result.args),
            "environment": {"python": platform.python_version(), "torch": version("torch"),
                            "torchvision": version("torchvision"), "numpy": version("numpy")},
            "files": sorted(path.name for path in output.iterdir() if path != lock),
        }
        (output / "run.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n",
                                         encoding="utf-8")
    finally:
        lock.unlink()


def _show_catalog(work_id):
    native_ids = {method.id for method in METHODS}
    if work_id is None:
        for work in WORKS:
            venue = f"{work.venue} accepted" if work.accepted_only else work.venue
            print(f"{work.id:<16} {venue:<22} {work.status(native_ids):<12} {work.label}")
        return
    work = find_work(work_id)
    if work is None:
        method = get_method(work_id)
        if method.id == "fedavg-static":
            print(f"{method.label} · fixed-data supervised learning")
            print(f"Protocol  {method.protocol}")
            print(f"Datasets  {', '.join(method.datasets)}")
            print(f"Paper  {method.source}")
            print("NCCL  python -m nccl_benchmark run fedavg-static --profile smoke --gpu -1")
            return
        work = find_work(method.id)
    print(work.title)
    venue = f"{work.venue} accepted" if work.accepted_only else work.venue
    print(f"{venue} · {work.setting}")
    print(f"Paper  {work.paper}")
    if work.code:
        print(f"Upstream code  {work.code}")
    if work.id in native_ids:
        method = get_method(work.id)
        print(f"Protocol  {method.protocol}")
        print(f"Datasets  {', '.join(method.datasets)}")
        print(f"NCCL  python -m nccl_benchmark run {work.id} --profile smoke --gpu -1")
    elif work.id in RECIPES:
        print(f"NCCL  python -m nccl_benchmark run {work.id} --source-dir PATH --dry-run")
    else:
        print(f"NCCL status  {work.status(native_ids)}")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(prog="python -m nccl_benchmark", allow_abbrev=False)
    if len(argv) >= 2 and argv[0] == "run":
        method_id = argv[1].lower().replace("_", "-")
        if method_id in RECIPES:
            try:
                return run_upstream(method_id, argv[2:])
            except ValueError as error:
                parser.error(str(error))
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="list native methods and upstream launchers")
    catalog = commands.add_parser("catalog", help="show research methods, papers, and integration status")
    catalog.add_argument("work_id", nargs="?", help="show paper and code details for one method")
    report = commands.add_parser("summarize", help="export final metrics and upstream launch status as CSV")
    report.add_argument("results", type=Path, help="one run directory or a tree of results")
    run = commands.add_parser("run", help="train and evaluate a method", allow_abbrev=False, add_help=False)
    run.add_argument("method", nargs="?", help="method ID from the list command")
    run.add_argument("-h", "--help", action="store_true", help="show run options and method flags")
    run.add_argument("--profile", choices=("default", "smoke", "reference"), default="default")
    run.add_argument("--dataset", type=dataset_id, help="dataset ID supported by the selected method")
    run.add_argument("--data-dir", "--data_dir", dest="data_dir", help="local dataset directory")
    run.add_argument("--output-dir", "--output_dir", dest="output_dir", help="empty run directory")
    run.add_argument("--seed", type=int, default=0)
    args, overrides = parser.parse_known_args(argv)
    if args.command == "summarize":
        from .results import summarize
        if overrides:
            report.error(f"unrecognized arguments: {' '.join(overrides)}")
        try:
            return summarize(args.results)
        except (ValueError, KeyError, OSError) as error:
            report.error(str(error))
    if args.command in ("list", "catalog"):
        if overrides:
            parser.error(f"unrecognized arguments: {' '.join(overrides)}")
        if args.command == "catalog":
            try:
                _show_catalog(args.work_id)
            except ValueError as error:
                catalog.error(str(error))
        else:
            for method in METHODS:
                print(f"{method.id:<15} {method.protocol:<28} {method.label}")
            for work in WORKS:
                if work.id in RECIPES:
                    print(f"{work.id:<15} {'upstream':<28} {work.label}")
        return
    if args.help:
        run.print_help()
        if args.method:
            overrides.append("--help")
        else:
            return
    if args.method is None:
        run.error("a method ID is required")
    if any(value.split("=", 1)[0] in ("--baseline", "--smoke") for value in overrides):
        run.error("select the method by ID and use --profile smoke for a synthetic smoke run")
    try:
        method = get_method(args.method)
    except ValueError as error:
        work = find_work(args.method)
        if work is not None:
            run.error(f"{work.label} has no configured launcher. See `python -m nccl_benchmark catalog {work.id}`.")
        run.error(str(error))
    try:
        _run(method, args, overrides)
    except ValueError as error:
        run.error(str(error))


if __name__ == "__main__":
    main()
