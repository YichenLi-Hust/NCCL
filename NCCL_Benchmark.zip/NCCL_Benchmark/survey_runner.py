"""Synchronous benchmark for Section VII of the NCCL Survey."""

import argparse
import csv
from importlib import import_module
import json
import logging
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import ConcatDataset, DataLoader, Subset

from .models import CLASSIFIERS
from .training import seed_everything

from .registry import get_method
from .survey.common import state_copy
from .survey.data import DATASETS, load_survey_data
from .survey.noise import apply_class_noise


def _parse(argv):
    selector = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    selector.add_argument("--baseline", default="FedAvg")
    selected, _ = selector.parse_known_args(argv)
    parser = argparse.ArgumentParser(parents=[selector], allow_abbrev=False,
                                     description="Synchronized federated class- or domain-incremental learning")
    try:
        method = get_method(selected.baseline)
    except ValueError as error:
        parser.error(str(error))
    if not method.strategy:
        parser.error(f"{selected.baseline} uses a different protocol")
    module, class_name = method.strategy.split(":")
    strategy_module = import_module(f".{module}", __package__)
    strategy = getattr(strategy_module, class_name)
    parser.add_argument("--dataset", choices=DATASETS, default="cifar100", type=str.lower)
    parser.add_argument("--data_dir", default="./data")
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--model", choices=CLASSIFIERS, default="resnet18")
    parser.add_argument("--client_num_in_total", type=int, default=20)
    parser.add_argument("--client_num_per_round", type=int, default=8)
    parser.add_argument("--comm_round", type=int, default=10, help="communication rounds per task")
    parser.add_argument("--num_tasks", type=int, default=None)
    parser.add_argument("--epochs", type=int, default=1, help="local training epochs per round")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--memory_size", type=int, default=None, help="local real-sample replay capacity")
    parser.add_argument("--client_optimizer", choices=("sgd", "adam"), default="adam")
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--class_noise_rate", type=float, default=0.0,
                        help="Target fraction of hidden-class samples relabeled locally in Class-IL")
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--wd", type=float, default=0.0005)
    parser.add_argument("--eval_every", type=int, default=1)
    parser.add_argument("--top_k", type=int, default=1)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--gpu", type=int, default=0, help="CUDA device index, or -1 for CPU")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--output_dir", default="./results/survey")
    parser.add_argument("--smoke", action="store_true", help="small synthetic run without downloads")
    parser.add_argument("--survey_train_fraction", type=float, default=0.8, help="Office training split fraction")
    parser.add_argument("--survey_domain_order", help="comma-separated permutation of the dataset's domains")
    parser.add_argument("--synthetic_samples_per_class", type=int, default=12)
    parser.add_argument("--survey_refed_lr", type=float, default=0.0001)
    parser.add_argument("--survey_refed_mix", type=float, default=0.5)
    parser.add_argument("--survey_refed_epochs", type=int, default=5)
    parser.add_argument("--survey_flow_width", type=int, default=0, help="0 uses classifier feature dimension")
    parser.add_argument("--survey_flow_layers", type=int, default=4)
    parser.add_argument("--survey_gan_width", type=int, default=64)
    parser.add_argument("--survey_latent_dim", type=int, default=100)
    parser.add_argument("--survey_replay_samples", type=int, default=300)
    parser.add_argument("--survey_generator_steps", type=int, default=20)
    parser.add_argument("--survey_fedcil_budget", type=int, default=0,
                        help="GAN optimizer steps per client and task (0 is unlimited)")
    if hasattr(strategy_module, "add_args"):
        strategy_module.add_args(parser)
    args = parser.parse_args(argv)
    if args.smoke:
        args.dataset, args.model, args.num_tasks = "synthetic", "small_cnn", 3
        args.client_num_in_total, args.client_num_per_round = 4, 2
        args.comm_round, args.epochs, args.eval_every, args.top_k = 2, 1, 1, 1
        args.batch_size, args.survey_refed_epochs = 8, 1
        args.survey_gan_width, args.survey_latent_dim = 8, 16
        args.survey_replay_samples, args.survey_generator_steps = 16, 2
        args.survey_flow_width = 16
    if args.memory_size is None:
        args.memory_size = 8 if args.smoke else 300

    for name, value in vars(args).items():
        if isinstance(value, float) and not math.isfinite(value):
            parser.error(f"{name} must be finite")
    for name in ("client_num_in_total", "client_num_per_round", "comm_round", "epochs",
                 "batch_size", "eval_every", "top_k", "threads", "synthetic_samples_per_class",
                 "survey_refed_epochs", "survey_flow_layers", "survey_gan_width", "survey_latent_dim",
                 "survey_replay_samples", "survey_generator_steps"):
        if getattr(args, name) < 1:
            parser.error(f"{name} must be positive")
    for name in ("memory_size", "num_workers", "survey_flow_width", "survey_fedcil_budget", "wd"):
        if getattr(args, name) < 0:
            parser.error(f"{name} must be nonnegative")
    if args.num_tasks is not None and args.num_tasks < 1:
        parser.error("num_tasks must be positive")
    if args.client_num_per_round > args.client_num_in_total:
        parser.error("client_num_per_round cannot exceed client_num_in_total")
    if min(args.alpha, args.lr, args.survey_refed_lr) <= 0 or not 0 < args.survey_refed_mix <= 1:
        parser.error("alpha and learning rates must be positive and survey_refed_mix must be in (0, 1]")
    if not 0 < args.survey_train_fraction < 1:
        parser.error("survey_train_fraction must be in (0, 1)")
    if not 0 <= args.seed < 2 ** 32:
        parser.error("seed must be in [0, 2**32)")
    if args.gpu < -1 or (args.gpu > 0 and args.gpu >= torch.cuda.device_count()):
        parser.error("gpu must be an available CUDA device index or -1 for CPU")
    validate_args = getattr(strategy_module, "validate_args", None)
    if validate_args is not None:
        validate_args(parser, args)
    return args, strategy


def _loader(dataset, args, seed=None):
    rng = torch.Generator().manual_seed(args.seed if seed is None else seed)
    return DataLoader(dataset, batch_size=args.batch_size, shuffle=seed is not None,
                      num_workers=args.num_workers, generator=rng)


class _WeightedStates:
    """Accumulate one client at a time to avoid storing a model per participant."""

    def __init__(self):
        self.floating = {}
        self.discrete = {}
        self.weight = 0
        self.largest_weight = 0

    def add(self, state, weight):
        if not math.isfinite(weight) or weight <= 0:
            raise ValueError(f"Client aggregation weights must be positive and finite, got {weight}")
        for name, value in state.items():
            tensor = value.detach().cpu()
            if tensor.is_floating_point() or tensor.is_complex():
                if name not in self.floating:
                    self.floating[name] = tensor * weight
                else:
                    self.floating[name].add_(tensor, alpha=weight)
            elif weight > self.largest_weight:
                self.discrete[name] = tensor.clone()
        self.weight += weight
        self.largest_weight = max(self.largest_weight, weight)

    def average(self):
        return {**{name: value.div_(self.weight) for name, value in self.floating.items()}, **self.discrete}


class _Replay:
    def __init__(self, capacity, client_count, rng):
        self.capacity = capacity
        self.datasets = [None] * client_count
        self.priorities = [np.empty(0) for _ in range(client_count)]
        self.rng = rng

    def training_data(self, datasets, strategy):
        return [strategy.build_client_data(client, new, old)
                for client, (new, old) in enumerate(zip(datasets, self.datasets))]

    def remember(self, datasets, strategy):
        custom_selector = getattr(strategy, "select_replay", None)
        for client, (new, old) in enumerate(zip(datasets, self.datasets)):
            if not len(new):
                continue
            candidates = new if old is None else ConcatDataset((new, old))
            if custom_selector is not None:
                self.datasets[client] = custom_selector(client, candidates, self.capacity)
                continue
            priorities = np.concatenate((self.rng.random(len(new)), self.priorities[client]))
            selected_count = min(self.capacity, len(candidates))
            indices = np.argpartition(priorities, len(priorities) - selected_count)[-selected_count:]
            self.priorities[client] = priorities[indices]
            self.datasets[client] = Subset(candidates, indices.tolist())


@torch.no_grad()
def _evaluate(strategy, tests, seen_classes, args, device):
    strategy.model.eval()
    seen = torch.as_tensor(seen_classes, dtype=torch.long, device=device)
    label_map = torch.full((strategy.stream.num_classes,), -1, dtype=torch.long, device=device)
    label_map[seen] = torch.arange(seen.numel(), device=device)
    task_results = []
    for loader in tests:
        correct, total, loss = 0, 0, 0.0
        for inputs, labels in loader:
            labels = label_map[labels.to(device)]
            scores = strategy.predict(inputs.to(device)).index_select(1, seen)
            best = scores.topk(min(args.top_k, seen.numel()), dim=1).indices
            correct += (best == labels[:, None]).any(1).sum().item()
            loss += F.cross_entropy(scores, labels, reduction="sum").item()
            total += len(labels)
        if not total:
            raise ValueError("Each Survey task needs test samples")
        task_results.append((correct, total, loss))
    return task_results


def _write_csv(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_json(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _summary(history, task_history, number_of_tasks):
    tasks = []
    for task in range(1, number_of_tasks + 1):
        rows = [row for row in history if row["task"] == task]
        last = [row["test_accuracy"] for row in rows[-10:]]
        best = max(rows, key=lambda row: row["test_accuracy"])
        tasks.append({"task": task, "last_round_accuracy": last[-1],
                      "last_evaluations": len(last), "last_evaluations_mean": float(np.mean(last)),
                      "last_evaluations_std": float(np.std(last)),
                      "first_best_round_in_task": best["round_in_task"],
                      "best_minus_first_eval": best["test_accuracy"] - rows[0]["test_accuracy"]})
    # Successive evaluations overwrite the same cell, leaving each stage's final result.
    matrix = [[None] * number_of_tasks for _ in range(number_of_tasks)]
    for row in task_history:
        matrix[row["task"] - 1][row["test_task"] - 1] = row["test_accuracy"]
    final = matrix[-1]
    drops = [max(matrix[i][j] for i in range(j, number_of_tasks - 1)) - final[j]
             for j in range(number_of_tasks - 1)]
    return {"task_end_accuracy_matrix": matrix,
            "final_task_macro_accuracy": sum(final) / number_of_tasks,
            "final_average_forgetting": sum(drops) / len(drops) if drops else None,
            "final_accuracy": tasks[-1]["last_evaluations_mean"],
            "average_accuracy": sum(task["last_evaluations_mean"] for task in tasks) / number_of_tasks,
            "rounds_to_best_sum": sum(task["first_best_round_in_task"] for task in tasks),
            "tasks": tasks}


def run_survey(argv=None):
    args, strategy_class = _parse(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    output = Path(args.output_dir)
    files = ("metrics.csv", "task_metrics.csv", "summary.json", "protocol.json", "model.pt")
    if any((output / name).exists() for name in files):
        raise ValueError(f"Choose a new output directory because {output} already contains Survey results")
    output.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    torch.set_num_threads(args.threads)
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() and args.gpu >= 0 else "cpu")
    stream = apply_class_noise(load_survey_data(args), args.class_noise_rate, args.seed)
    args.num_tasks = stream.num_tasks
    if args.top_k > stream.num_classes:
        raise ValueError(f"top_k={args.top_k} exceeds the {stream.num_classes} dataset classes")
    if hasattr(strategy_class, "build_model"):
        model = strategy_class.build_model(args, stream).to(device)
    else:
        model = CLASSIFIERS[args.model](stream.channels, stream.num_classes).to(device)
    strategy = strategy_class(model, args, stream, device)
    client_rng, replay_rng = [np.random.default_rng(seed) for seed in np.random.SeedSequence(args.seed).spawn(2)]
    replay = _Replay(args.memory_size, args.client_num_in_total, replay_rng)
    tests = [_loader(data, args) for data in stream.test]
    history, task_history = [], []
    seen_classes = ()

    logging.info("Method=%s  Dataset=%s  Device=%s", args.baseline, args.dataset, device)
    for task, (task_data, classes) in enumerate(zip(stream.train, stream.task_classes)):
        old_classes = seen_classes
        seen_classes = tuple(sorted(set(old_classes).union(classes)))
        strategy.begin_task(task, old_classes, seen_classes)
        use_replay = strategy.uses_local_replay and args.memory_size > 0
        training = replay.training_data(task_data, strategy)
        eligible = [client for client, data in enumerate(training) if len(data)]
        if not eligible:
            raise ValueError(f"No client has data for Survey task {task + 1}")
        for round_in_task in range(1, args.comm_round + 1):
            server_round = task * args.comm_round + round_in_task
            participants = min(args.client_num_per_round, len(eligible))
            selected = [int(client) for client in strategy.sample_clients(eligible, participants, client_rng)]
            if len(selected) != participants or len(set(selected)) != participants or set(selected) - set(eligible):
                raise ValueError("Method returned an invalid collection of training clients")
            strategy.begin_round(task, round_in_task, selected)
            modules = {"classifier": strategy.model, **strategy.auxiliary_modules}
            starting = {name: state_copy(module) for name, module in modules.items()}
            sums = {name: _WeightedStates() for name in modules}
            for client in selected:
                for name, module in modules.items():
                    module.load_state_dict(starting[name])
                seed = int(client_rng.integers(2 ** 32))
                loader = _loader(training[client], args, seed)
                classifier_state = strategy.fit_client(client, loader, device)
                weight = strategy.aggregation_weight(client, loader)
                for name, module in modules.items():
                    state = classifier_state if name == "classifier" and classifier_state is not None else module.state_dict()
                    sums[name].add(state, weight)
            for name, module in modules.items():
                average = sums[name].average()
                if name == "classifier":
                    average = strategy.project_update(starting[name], average)
                module.load_state_dict(average)
            strategy.post_round()
            if round_in_task % args.eval_every == 0 or round_in_task == args.comm_round:
                scores = _evaluate(strategy, tests[:task + 1], seen_classes, args, device)
                correct, total, loss = (sum(values) for values in zip(*scores))
                row = {"round": server_round, "task": task + 1, "round_in_task": round_in_task,
                       "clients": len(selected), "top_k": min(args.top_k, len(seen_classes)),
                       "test_accuracy": correct / total, "test_loss": loss / total, "test_count": total}
                history.append(row)
                for evaluated_task, (hits, count, errors) in enumerate(scores, 1):
                    task_history.append({"round": server_round, "task": task + 1, "test_task": evaluated_task,
                                         "test_accuracy": hits / count, "test_loss": errors / count,
                                         "test_count": count})
                logging.info("Task %d/%d  Round %d/%d  Top-%d accuracy %.2f%%",
                             task + 1, stream.num_tasks, round_in_task, args.comm_round,
                             row["top_k"], 100 * row["test_accuracy"])
        strategy.finish_task(task)
        if use_replay and task + 1 < stream.num_tasks:
            replay.remember(task_data, strategy)

    for rows in (history, task_history):
        if any(not math.isfinite(row["test_loss"]) for row in rows):
            raise FloatingPointError("Non-finite Survey evaluation loss")
    summary = _summary(history, task_history, stream.num_tasks)
    _write_csv(output / "metrics.csv", history[0], history)
    _write_csv(output / "task_metrics.csv", task_history[0], task_history)
    _write_json(output / "summary.json", summary)
    _write_json(output / "protocol.json", stream.protocol)
    torch.save({"state_dict": state_copy(strategy.model),
                "auxiliary_state": {name: state_copy(module) for name, module in strategy.auxiliary_modules.items()},
                "strategy_state": strategy.checkpoint(), "args": vars(args)}, output / "model.pt")
    logging.info("Results saved to %s", output.resolve())
    return SimpleNamespace(args=args, model=strategy.model, stream=stream, history=history)
