"""Rehearsal-free FedSSI from Li et al., ICML 2025.

The implementation follows Equations (2), (3), (5), and (6) in
https://proceedings.mlr.press/v267/li25cq.html on the shared NCCL task stream.
"""

from copy import deepcopy

import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

from .survey.common import avoid_singleton_batch_norm, optimizer_for
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--fedssi_lambda", type=float, default=0.5,
                        help="Local information balance in the personalized surrogate (0 < λ < 1)")
    parser.add_argument("--fedssi_strength", type=float, default=0.001,
                        help="Weight on accumulated synaptic importance in the target loss")
    parser.add_argument("--fedssi_epsilon", type=float, default=0.1,
                        help="Positive stabilizer for synaptic importance normalization")
    parser.add_argument("--fedssi_psm_epochs", type=int, default=1,
                        help="Local surrogate epochs at each task boundary")
    parser.add_argument("--fedssi_psm_lr", type=float, default=None,
                        help="Surrogate SGD learning rate (defaults to --lr)")


def validate_args(parser, args):
    if not 0 < args.fedssi_lambda < 1:
        parser.error("fedssi_lambda must be in (0, 1)")
    if args.fedssi_strength < 0 or args.fedssi_epsilon <= 0:
        parser.error("fedssi_strength must be nonnegative and fedssi_epsilon must be positive")
    if args.fedssi_psm_epochs < 1 or (args.fedssi_psm_lr is not None and args.fedssi_psm_lr <= 0):
        parser.error("fedssi_psm_epochs and fedssi_psm_lr must be positive")


class FedSSI(LocalStrategy):
    """Estimate parameter importance from a local surrogate and retain only its scores."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.trainable = {name: value for name, value in model.named_parameters() if value.requires_grad}
        self.anchor = {}
        self.importance = {}
        self.proximal_weight = (1 - args.fedssi_lambda) / (2 * args.fedssi_lambda)
        self.surrogate_lr = args.lr if args.fedssi_psm_lr is None else args.fedssi_psm_lr
        stream.protocol["fedssi"] = {
            "surrogate_initialization": "last global model of completed task",
            "surrogate_sampling": "all clients with nonempty data in the completed task",
            "surrogate_optimizer": "sgd",
            "surrogate_epochs": args.fedssi_psm_epochs,
            "surrogate_learning_rate": self.surrogate_lr,
            "negative_contributions": "clipped after per-task path integration",
            "uses_local_replay": False,
        }

    def fit_client(self, client, loader, device):
        if client not in self.importance or not self.args.fedssi_strength:
            return super().fit_client(client, loader, device)

        importance = {name: scores.to(device) for name, scores in self.importance[client].items()}
        optimizer = optimizer_for(self.trainable.values(), self.args)
        self.model.train()
        for _ in range(self.args.epochs):
            for inputs, labels in loader:
                inputs, labels = inputs.to(device), labels.to(device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    loss = F.cross_entropy(self.model(inputs), labels)
                penalty = sum((importance[name] * (value - self.anchor[name]).square()).sum()
                              for name, value in self.trainable.items())
                (loss + self.args.fedssi_strength * penalty).backward()
                optimizer.step()

    def finish_task(self, task):
        self.anchor = {name: value.detach().clone() for name, value in self.trainable.items()}
        surrogate = deepcopy(self.model)
        parameters = {name: value for name, value in surrogate.named_parameters() if value.requires_grad}
        for client, dataset in enumerate(self.stream.train[task]):
            if not len(dataset):
                continue
            seed = self.args.seed + task * self.args.client_num_in_total + client
            loader = DataLoader(dataset, batch_size=self.args.batch_size, shuffle=True,
                                num_workers=self.args.num_workers,
                                generator=torch.Generator().manual_seed(seed))
            surrogate.load_state_dict(self.model.state_dict())
            task_importance = self._estimate_importance(surrogate, parameters, loader)
            if client in self.importance:
                for name, scores in task_importance.items():
                    self.importance[client][name].add_(scores)
            else:
                self.importance[client] = task_importance

    def _estimate_importance(self, surrogate, parameters, loader):
        surrogate.train()
        optimizer = torch.optim.SGD(parameters.values(), lr=self.surrogate_lr)
        contribution = {name: torch.zeros_like(value) for name, value in parameters.items()}
        for _ in range(self.args.fedssi_psm_epochs):
            for inputs, labels in loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(surrogate, len(inputs)):
                    F.cross_entropy(surrogate(inputs), labels).backward()
                with torch.no_grad():
                    # Use the data gradient for Equation (6) and the proximal gradient for Equation (5).
                    data_gradients = {name: p.grad.clone() for name, p in parameters.items() if p.grad is not None}
                    before = {name: parameters[name].clone() for name in data_gradients}
                    for name in data_gradients:
                        parameter = parameters[name]
                        parameter.grad.add_(parameter - self.anchor[name], alpha=self.proximal_weight)
                    optimizer.step()
                    for name, gradient in data_gradients.items():
                        contribution[name].addcmul_(gradient, parameters[name] - before[name], value=-1)

        with torch.no_grad():
            return {name: (contribution[name].clamp_min_(0) /
                           ((value - self.anchor[name]).square() + self.args.fedssi_epsilon)).cpu()
                    for name, value in parameters.items()}

    def checkpoint(self):
        return {"anchor": {name: value.cpu() for name, value in self.anchor.items()},
                "client_importance": self.importance}
