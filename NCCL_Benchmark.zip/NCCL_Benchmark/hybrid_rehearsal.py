"""Hybrid Rehearsal (ICLR 2025), Algorithms 1–2, on synchronized class streams."""

import copy

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import ConcatDataset, DataLoader, Subset, TensorDataset

from .data import _labels
from .survey.common import avoid_singleton_batch_norm, optimizer_for
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--hr_latent_dim", type=int, default=32)
    parser.add_argument("--hr_alignment_steps", type=int, default=30)
    parser.add_argument("--hr_sigma", type=float, default=1.0, help="Lennard-Jones distance scale")
    parser.add_argument("--hr_centroid_weight", type=float, default=1.0)
    parser.add_argument("--hr_replay_std", type=float, default=0.1, help="Noise for locally absent classes")


def validate_args(parser, args):
    if min(args.hr_latent_dim, args.hr_alignment_steps) < 1 or args.hr_sigma <= 0:
        parser.error("HR latent dimension, alignment steps, and sigma must be positive")
    if min(args.hr_centroid_weight, args.hr_replay_std) < 0:
        parser.error("HR centroid weight and replay noise must be nonnegative")


class _Autoencoder(nn.Module):
    def __init__(self, encoder, dim, stream):
        super().__init__()
        self.encoder = encoder
        self.posterior = nn.Linear(encoder.fc.in_features, 2 * dim)
        encoder.fc = nn.Identity()
        self.image_size = stream.image_size
        self.decoder_input = nn.Linear(dim, 32 * 4 * 4)
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(32, 32, 4, stride=2, padding=1), nn.ReLU(),
            nn.ConvTranspose2d(32, 16, 4, stride=2, padding=1), nn.ReLU(),
            nn.ConvTranspose2d(16, 16, 4, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(16, stream.channels, 3, padding=1),
        )
        self.register_buffer("centroids", torch.zeros(stream.num_classes, dim))

    def encode(self, x):
        mean, log_var = self.posterior(self.encoder.forward_features(x)).chunk(2, dim=1)
        return mean, log_var.clamp(-12, 8)

    def decode(self, z):
        x = self.decoder(self.decoder_input(z).reshape(-1, 32, 4, 4))
        if x.shape[-1] != self.image_size:
            x = F.interpolate(x, size=(self.image_size, self.image_size), mode="bilinear", align_corners=False)
        return x

    def forward(self, inputs):
        means, _ = self.encode(inputs)
        return -torch.cdist(means, self.centroids)


def _align(new_centers, old_centers, args):
    """Minimize the pair potential of Eq. 8, keeping old targets fixed."""
    # Resolve coincident empirical means before evaluating the singular potential.
    new = new_centers.double() + 1e-5 * args.hr_sigma * torch.randn_like(new_centers).double()
    if len(new) + len(old_centers) > 1:
        old = old_centers.to(new)
        for _ in range(args.hr_alignment_steps):
            new.requires_grad_(True)
            distances = torch.pdist(torch.cat((old, new)))
            # Old-old pairs are constant; clamping also protects coincident old pairs.
            ratios = (args.hr_sigma / distances.clamp_min(1e-10)).pow(6)
            energy = 4 * (ratios.square() - ratios).sum()
            gradient, = torch.autograd.grad(energy, new)
            step = gradient / gradient.norm(dim=1, keepdim=True).clamp_min(1)
            new = new.detach() - (0.025 * args.hr_sigma) * step
    return new.to(new_centers)


def _collate_replay(batch):
    images, labels = zip(*batch)
    return torch.stack(images), torch.as_tensor(labels, dtype=torch.long)


class HybridRehearsal(LocalStrategy):
    """Federated VAE with fixed class anchors, local latent replay and centroid replay."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        if stream.protocol["scenario"] != "class-il":
            raise ValueError("HR requires a class-incremental stream")
        self.model = _Autoencoder(model, args.hr_latent_dim, stream).to(device)
        self.memories = [{} for _ in stream.train[0]]
        self.previous = None
        self.trace = []
        stream.protocol["hybrid_rehearsal"] = {
            "centroids": "One sample-count-weighted centroid per class from client sums, aligned at task arrival",
            "latent_budget_per_client": args.memory_size,
            "memory_counts_by_client": self.trace,
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.old = tuple(old_classes)
        self.previous = copy.deepcopy(self.model).eval().requires_grad_(False) if task else None
        self.model.eval()
        new_labels = list(self.stream.task_classes[task])
        counts = torch.zeros(self.stream.num_classes, device=self.device)
        sums = torch.zeros_like(self.model.centroids)
        with torch.no_grad():
            for data in self.stream.train[task]:
                local_sums = torch.zeros_like(sums)
                local_counts = torch.zeros_like(counts)
                for x, y in self._batches(data):
                    z, _ = self.model.encode(x.to(self.device))
                    labels = y.to(self.device)
                    local_sums.index_add_(0, labels, z)
                    local_counts.index_add_(0, labels, torch.ones_like(labels, dtype=counts.dtype))
                sums += local_sums
                counts += local_counts
        if (counts[new_labels] == 0).any():
            raise ValueError("HR needs a training example for each introduced class to initialize its centroid")
        means = sums[new_labels] / counts[new_labels, None]
        self.model.centroids[new_labels] = _align(means, self.model.centroids[list(self.old)], self.args)

    def _batches(self, data):
        return DataLoader(data, batch_size=self.args.batch_size, num_workers=self.args.num_workers)

    @torch.no_grad()
    def _replay_data(self, client):
        images, labels = [], []
        fallback_count = max(1, self.args.memory_size // len(self.old))
        for label in self.old:
            stored = self.memories[client].get(label)
            if stored is None:
                noise = torch.randn(fallback_count, self.args.hr_latent_dim, device=self.device)
                z = self.previous.centroids[label] + self.args.hr_replay_std * noise
            else:
                z = stored.to(self.device)
            for batch in z.split(self.args.batch_size):
                images.append(self.previous.decode(batch).cpu())
            labels.append(torch.full((len(z),), label, dtype=torch.long))
        return TensorDataset(torch.cat(images), torch.cat(labels))

    def fit_client(self, client, loader, device):
        if self.previous is not None:
            data = ConcatDataset((loader.dataset, self._replay_data(client)))
            loader = DataLoader(data, shuffle=True, generator=loader.generator, batch_size=self.args.batch_size,
                                num_workers=self.args.num_workers, collate_fn=_collate_replay)
        self.model.train()
        optimizer = optimizer_for(self.model.parameters(), self.args)
        for _ in range(self.args.epochs):
            for inputs, labels in loader:
                x, y = inputs.to(device), labels.to(device)
                with avoid_singleton_batch_norm(self.model, len(x)):
                    mean, log_var = self.model.encode(x)
                z = mean + torch.randn_like(mean) * (0.5 * log_var).exp()
                reconstruction = self.model.decode(z)
                kl = 0.5 * (mean.square() + log_var.exp() - log_var - 1).mean()
                loss = (F.mse_loss(reconstruction, x) + kl
                        + self.args.hr_centroid_weight * F.mse_loss(z, self.model.centroids[y]))
                if self.previous is not None:
                    with torch.no_grad():
                        old_z, _ = self.previous.encode(x)
                        old_x = self.previous.decode(old_z)
                    loss = loss + F.mse_loss(mean, old_z) + F.mse_loss(self.model.decode(mean), old_x)
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()

    def aggregation_weight(self, client, loader):
        return 1

    @torch.no_grad()
    def finish_task(self, task):
        self.model.eval()
        for client, dataset in enumerate(self.stream.train[task]):
            rng = np.random.default_rng(np.random.SeedSequence([self.args.seed, task, client, 510]))
            memory = self.memories[client]
            labels = _labels(dataset)
            indices = {int(label): np.flatnonzero(labels == label) for label in np.unique(labels)}
            available = {label: len(array) for label, array in {**memory, **indices}.items()}
            quotas = dict.fromkeys(available, 0)
            remaining = self.args.memory_size
            while remaining:
                active = [label for label in quotas if quotas[label] < available[label]]
                if not active:
                    break
                for label in rng.permutation(active)[:remaining]:
                    quotas[label] += 1
                    remaining -= 1
            refreshed = {}
            for label, count in quotas.items():
                if not count:
                    continue
                selected = rng.choice(available[label], size=count, replace=False)
                if label in indices:
                    batches = (x for x, _ in self._batches(Subset(dataset, indices[label][selected].tolist())))
                else:
                    codes = memory[label][selected.tolist()]
                    batches = (self.previous.decode(z.to(self.device)) for z in codes.split(self.args.batch_size))
                refreshed[label] = torch.cat([self.model.encode(x.to(self.device))[0].cpu() for x in batches])
            self.memories[client] = refreshed
        self.trace.append([sum(map(len, memory.values())) for memory in self.memories])

    def checkpoint(self):
        return {"client_latent_memories": self.memories}
