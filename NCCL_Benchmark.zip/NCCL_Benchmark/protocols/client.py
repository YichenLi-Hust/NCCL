class Client:
    def __init__(self, client_idx, local_training_data, local_test_data,
                 local_sample_number, args, device, model_trainer):
        self.args = args
        self.device = device
        self.model_trainer = model_trainer
        self.update_local_dataset(client_idx, local_training_data,
                                  local_test_data, local_sample_number)

    def update_local_dataset(self, client_idx, local_training_data,
                             local_test_data, local_sample_number):
        self.client_idx = client_idx
        self.local_training_data = local_training_data
        self.local_test_data = local_test_data
        self.local_sample_number = local_sample_number

    def get_sample_number(self):
        return self.local_sample_number

    def train(self, w_global):
        self.model_trainer.id = self.client_idx
        self.model_trainer.set_model_params(w_global)
        if self.local_sample_number > 0:
            self.model_trainer.train(self.local_training_data, self.device, self.args)
        return self.model_trainer.get_model_params()

    def local_test(self, b_use_test_dataset, allowed_classes=None):
        data = self.local_test_data if b_use_test_dataset else self.local_training_data
        return self.model_trainer.test(data, self.device, self.args,
                                       allowed_classes=allowed_classes)
