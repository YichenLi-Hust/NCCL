"""BPFedCTTA classification benchmark (CVPR 2026).

Train a labeled source federation, then visit each unlabeled target client once.
BPA anchors its entropy update to the incoming global model. UGSA uses reported
post-adaptation entropy and a softmax normalizer containing arrivals so far.
"""

import argparse
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import Dataset, Subset

from ..data import _labels, _synthetic, non_iid_partition_with_dirichlet_distribution
from ..models import CLASSIFIERS
from ..registry import dataset_id
from ..survey.data import DOMAINS, FolderImages, _domain_incremental
from ..survey.strategies import supervised_update
from ..survey_runner import _WeightedStates, _loader, _write_csv, _write_json
from ..training import seed_everything, state_copy


CORRUPTIONS = (
    "gaussian_noise", "shot_noise", "impulse_noise", "defocus_blur", "glass_blur",
    "motion_blur", "zoom_blur", "snow", "frost", "fog", "brightness", "contrast",
    "elastic_transform", "pixelate", "jpeg_compression",
)


class _Corruption(Dataset):
    """Load one severity block lazily. Spawned loader workers open their own mmap."""

    def __init__(self, path, labels, severity, transform):
        self.path, self.targets = path, labels
        self.offset = (severity - 1) * len(labels)
        self.transform = transform
        self._images = None

    def __getstate__(self):
        return {**vars(self), "_images": None}

    def __len__(self):
        return len(self.targets)

    def __getitem__(self, index):
        if self._images is None:
            self._images = np.load(self.path, mmap_mode="r", allow_pickle=False)
            expected = (5 * len(self), 32, 32, 3)
            if self._images.shape != expected or self._images.dtype != np.uint8:
                raise ValueError(f"Expected {expected} uint8 image array in {self.path}")
        image = np.array(self._images[self.offset + index], copy=True)
        return self.transform(image), int(self.targets[index])


class _ImagesOnly(Dataset):
    def __init__(self, dataset):
        self.dataset = dataset

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        return self.dataset[index][0]


def _cifar_domains(args):
    from torchvision import datasets, transforms

    root = Path(args.data_dir)
    is_cifar10 = args.dataset == "cifar10c"
    name, classes = ("CIFAR-10-C", 10) if is_cifar10 else ("CIFAR-100-C", 100)
    constructor = datasets.CIFAR10 if is_cifar10 else datasets.CIFAR100
    mean, std = ((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)) if is_cifar10 else (
        (0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761))
    transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean, std)])
    source = constructor(root=str(root), transform=transform, train=True, download=args.download)
    clean = constructor(root=str(root), transform=transform, train=False, download=args.download)
    folder = root / name
    labels = np.load(folder / "labels.npy", allow_pickle=False)
    if labels.shape == (5 * len(clean),):
        labels = labels.reshape(5, len(clean))[args.severity - 1]
    if labels.shape != (len(clean),) or not np.array_equal(labels, clean.targets):
        raise ValueError(f"{folder}/labels.npy must match the clean CIFAR test image order")
    # Corruptions reuse the same underlying images. Hold out the same image
    # identities across clean and corrupted evaluation, independent of labels.
    order = np.random.default_rng(args.seed).permutation(len(clean))
    split = max(1, min(len(order) - 1, int(args.adapt_fraction * len(order))))
    adaptation, test = order[:split].tolist(), order[split:].tolist()
    domains = [_Corruption(folder / f"{kind}.npy", labels, args.severity, transform)
               for kind in CORRUPTIONS]
    for domain in domains:
        if not domain.path.is_file():
            raise FileNotFoundError(domain.path)
    return ([source, *(Subset(domain, adaptation) for domain in domains)],
            [Subset(clean, test), *(Subset(domain, test) for domain in domains)],
            ("clean", *CORRUPTIONS), classes)


def _domains(args):
    if args.dataset in ("cifar10c", "cifar100c"):
        return _cifar_domains(args)
    if args.dataset == "synthetic":
        train, test = [], []
        for domain, contrast in enumerate((1, 0.8, 0.6)):
            for count, dest, offset in ((12, train, 0), (4, test, 1)):
                data = _synthetic(count, args.seed + 2 * domain + offset)
                data.data.mul_(contrast).add_(0.25 * (1 - contrast))
                dest.append(data)
        return train, test, ("source", "low_contrast", "lower_contrast"), 6
    train, test, _, names, classes, *_ = _domain_incremental(args, args.dataset, Path(args.data_dir))
    if args.dataset != "digit10":
        # Use a deterministic center crop on the target stream each time a
        # client computes its incoming uncertainty, gradient and report.
        train[1:] = [FolderImages(domain.samples, holdout.transform)
                     for domain, holdout in zip(train[1:], test[1:])]
    return train, test, names, classes


def _entropy(logits):
    log_probs = logits.log_softmax(dim=1)
    return -(log_probs.exp() * log_probs).sum(dim=1)


@torch.no_grad()
def _mean_entropy(model, loader, device):
    model.eval()
    total = sum(_entropy(model(images.to(device))).sum().item() for images in loader)
    result = total / len(loader.dataset)
    if not math.isfinite(result):
        raise FloatingPointError("Client prediction entropy is nonfinite")
    return result


def _adapt(model, images, device, args):
    # Only trainable parameters change at test time. Frozen BatchNorm running
    # statistics cannot bypass the subsequent server gate.
    model.eval()
    incoming = _mean_entropy(model, images, device)
    precision = incoming / args.prior_variance
    anchors = [p.detach().clone() for p in model.parameters()]
    optimizer = torch.optim.SGD(model.parameters(), lr=args.adapt_lr)
    for _ in range(args.adapt_epochs):
        for batch in images:
            optimizer.zero_grad(set_to_none=True)
            entropy = _entropy(model(batch.to(device))).mean()
            distance = sum((p - old).square().sum() for p, old in zip(model.parameters(), anchors))
            loss = entropy + 0.5 * precision * distance
            if not torch.isfinite(loss):
                raise FloatingPointError("Nonfinite client MAP loss")
            loss.backward()
            optimizer.step()
    return incoming, precision, _mean_entropy(model, images, device), anchors


@torch.no_grad()
def _record(model, tests, domain, names, args, device):
    model.eval()
    rows = []
    for name, data in zip(names[:domain + 1], tests[:domain + 1]):
        correct, loss_sum = 0, 0.0
        for images, labels in _loader(data, args):
            labels = labels.to(device)
            outputs = model(images.to(device))
            loss_sum += F.cross_entropy(outputs, labels, reduction="sum").item()
            correct += int(outputs.argmax(dim=1).eq(labels).sum())
        if not math.isfinite(loss_sum):
            raise FloatingPointError("Nonfinite held-out test loss")
        rows.append(dict(task=domain + 1, domain=names[domain], test_domain=name,
                         test_count=len(data), test_accuracy=correct / len(data),
                         test_loss=loss_sum / len(data)))
    return rows


def _stage_metrics(scores):
    count = sum(row["test_count"] for row in scores)
    return {
        "task": scores[-1]["task"], "domain": scores[-1]["domain"],
        "test_count": count,
        "test_accuracy": sum(row["test_accuracy"] * row["test_count"] for row in scores) / count,
        "test_loss": sum(row["test_loss"] * row["test_count"] for row in scores) / count,
        "source_accuracy": scores[0]["test_accuracy"],
        "current_domain_accuracy": scores[-1]["test_accuracy"],
    }


def _fit_source(model, data, classes, args, device, rng):
    shards = non_iid_partition_with_dirichlet_distribution(
        _labels(data), args.client_num_in_total, classes, args.alpha, seed=args.seed)
    eligible = [client for client, indices in shards.items() if len(indices)]
    for _ in range(args.comm_round):
        starting = state_copy(model)
        updates = _WeightedStates()
        participating = rng.choice(eligible, size=min(len(eligible), args.client_num_per_round), replace=False)
        for client in participating:
            model.load_state_dict(starting)
            samples = Subset(data, shards[client])
            loader = _loader(samples, args, int(rng.integers(2**32)))
            supervised_update(model, loader, device, args)
            updates.add(model.state_dict(), len(samples))
        model.load_state_dict(updates.average())


def _arguments(argv):
    parser = argparse.ArgumentParser(prog="python -m nccl_benchmark run bpfedctta", allow_abbrev=False)
    parser.add_argument("--baseline", default="BPFedCTTA", choices=("BPFedCTTA",), help=argparse.SUPPRESS)
    parser.add_argument("--dataset", type=dataset_id, choices=("synthetic", "cifar10c", "cifar100c", *DOMAINS))
    parser.add_argument("--model", choices=CLASSIFIERS, default="resnet18")
    parser.add_argument("--data_dir", default="./data")
    parser.add_argument("--download", action="store_true", help="allow torchvision downloads for clean datasets")
    parser.add_argument("--comm_round", type=int, default=10, help="source FedAvg rounds")
    parser.add_argument("--client_num_in_total", type=int, default=10, help="labeled source clients")
    parser.add_argument("--client_num_per_round", type=int, default=5, help="participating source clients")
    parser.add_argument("--epochs", type=int, default=1, help="source local epochs")
    parser.add_argument("--lr", type=float, default=0.01, help="source learning rate")
    parser.add_argument("--client_optimizer", choices=("sgd", "adam"), default="sgd")
    parser.add_argument("--wd", type=float, default=0.0)
    parser.add_argument("--alpha", type=float, default=0.5, help="source Dirichlet concentration")
    parser.add_argument("--adapt_lr", type=float, default=0.001, help="unlabeled target SGD learning rate")
    parser.add_argument("--adapt_epochs", type=int, default=1)
    parser.add_argument("--prior_variance", type=float, default=1.0, help="base variance of the isotropic prior")
    parser.add_argument("--gate_beta", type=float, default=1.0, help="inverse temperature of the entropy gate")
    parser.add_argument("--server_lr", type=float, default=1.0, help="server interpolation multiplier in [0, 1]")
    parser.add_argument("--target_clients_per_domain", type=int, default=1)
    parser.add_argument("--severity", type=int, choices=range(1, 6), default=5, help="CIFAR-C corruption severity")
    parser.add_argument("--adapt_fraction", type=float, default=0.5, help="CIFAR-C adaptation fraction")
    parser.add_argument("--survey_domain_order", help="ordered comma-separated Office or Digit10 domains")
    parser.add_argument("--survey_train_fraction", type=float, default=0.8, help="Office training fraction")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--gpu", type=int, default=0, help="CUDA device index, or -1 for CPU")
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--smoke", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    if args.smoke:
        args.dataset, args.model = "synthetic", "small_cnn"
        args.comm_round, args.epochs, args.client_num_in_total, args.client_num_per_round = 2, 1, 4, 2
        args.batch_size = 8
    if any(isinstance(value, float) and not math.isfinite(value) for value in vars(args).values()):
        parser.error("floating-point settings must be finite")
    if min(args.lr, args.adapt_lr, args.prior_variance, args.alpha) <= 0 or min(args.gate_beta, args.wd) < 0:
        parser.error("learning rates, prior variance and alpha must be positive. beta and wd must be nonnegative")
    if min(args.comm_round, args.epochs, args.adapt_epochs, args.batch_size, args.threads,
           args.client_num_per_round, args.target_clients_per_domain) < 1 or args.num_workers < 0:
        parser.error("counts must be positive and num_workers nonnegative")
    if not 0 <= args.server_lr <= 1 or not 0 < args.adapt_fraction < 1 or not 0 < args.survey_train_fraction < 1:
        parser.error("server_lr must be in [0,1] and split fractions in (0,1)")
    if args.client_num_per_round > args.client_num_in_total or not 0 <= args.seed < 2**32:
        parser.error("source participation exceeds the client count or seed is outside [0,2**32)")
    if args.gpu < -1 or (args.gpu > 0 and args.gpu >= torch.cuda.device_count()):
        parser.error("gpu must be an available CUDA device index or -1 for CPU")
    if args.survey_domain_order and args.dataset not in DOMAINS:
        parser.error("survey_domain_order is available for Office and Digit10")
    return args


def run(argv):
    args = _arguments(argv)
    seed_everything(args.seed)
    torch.set_num_threads(args.threads)
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() and args.gpu >= 0 else "cpu")
    train, test, names, classes = _domains(args)
    if any(len(data) == 0 for data in (*train, *test)):
        raise ValueError("Each domain needs nonempty training and held-out data")
    if any(len(data) < args.target_clients_per_domain for data in train[1:]):
        raise ValueError("Each target client must have at least one adaptation image")
    rng = np.random.default_rng(args.seed)
    model = CLASSIFIERS[args.model](3, classes).to(device)
    _fit_source(model, train[0], classes, args, device, rng)
    details = _record(model, test, 0, names, args, device)
    metrics = [_stage_metrics(details)]
    events, log_normalizer = [], -math.inf
    for domain, data in enumerate(train[1:], start=1):
        # Domain shifts define client arrivals. Partition target images without accessing labels.
        clients = np.array_split(rng.permutation(len(data)), args.target_clients_per_domain)
        for client, indices in enumerate(clients):
            loader = _loader(_ImagesOnly(Subset(data, indices.tolist())), args)
            incoming, precision, reported, anchors = _adapt(model, loader, device, args)
            log_score = -args.gate_beta * reported
            if not math.isfinite(log_score):
                raise ValueError("gate_beta times the reported entropy must be finite")
            log_normalizer = float(np.logaddexp(log_normalizer, log_score))
            gate = math.exp(log_score - log_normalizer)
            with torch.no_grad():
                for parameter, previous in zip(model.parameters(), anchors):
                    parameter.copy_(torch.lerp(previous, parameter, args.server_lr * gate))
            events.append(dict(arrival=len(events) + 1, domain=names[domain], client=client,
                               adaptation_count=len(indices), incoming_entropy=incoming,
                               prior_precision=precision, reported_entropy=reported, gate=gate))
        scores = _record(model, test, domain, names, args, device)
        details.extend(scores)
        metrics.append(_stage_metrics(scores))
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "metrics.csv", metrics[0], metrics)
    _write_csv(output / "task_metrics.csv", details[0], details)
    _write_csv(output / "arrivals.csv", events[0], events)
    _write_json(output / "protocol.json", {
        "dataset": args.dataset, "domains": names, "classes": classes, "source": names[0],
        "source_partition": "classwise Dirichlet", "target_partition": "label-independent random shards",
        "adaptation": "target inputs only; incoming entropy / prior_variance; SGD with frozen BN statistics",
        "aggregation": "one arrival at a time; entropy softmax over the prefix including the current client",
        "evaluation": "global top-1 on disjoint labeled splits of source and all target domains seen so far",
        "train_counts": [len(data) for data in train], "test_counts": [len(data) for data in test],
    })
    torch.save({"state_dict": state_copy(model), "args": vars(args)}, output / "model.pt")
    return SimpleNamespace(args=args)
