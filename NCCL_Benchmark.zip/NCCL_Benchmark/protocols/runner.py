"""Train an asynchronous method or a static control through the benchmark registry."""

import argparse
import logging
import math
from pathlib import Path

import torch

from ..data import load_data
from ..models import CLASSIFIERS
from ..registry import dataset_id, get_method
from ..training import seed_everything
from .c2afcl import C2AFCLAPI
from .c2afcl_data import OFFICE_DOMAINS, load_c2afcl_data
from .classifier import ClassificationTrainer
from .rc_fcl import RCFCLAPI
from .rcfcl_data import load_rcfcl_data
from .static import FedAvgAPI


def _arguments(argv):
    selector = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    selector.add_argument('--baseline', required=True, choices=('FedAvg', 'C2AFCL', 'RCFCL'),
                          help=argparse.SUPPRESS)
    selection, _ = selector.parse_known_args(argv)
    method = get_method('fedavg-static' if selection.baseline == 'FedAvg' else selection.baseline)
    parser = argparse.ArgumentParser(prog=f'python -m nccl_benchmark run {method.id}',
                                     parents=[selector], allow_abbrev=False,
                                     description=f'{method.label} benchmark settings')
    parser.add_argument('--model', default='resnet18', choices=CLASSIFIERS)
    parser.add_argument('--dataset', type=dataset_id, default='cifar100',
                        choices=(*method.datasets, 'synthetic'))
    parser.add_argument('--data_dir', default='./data')
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--client_optimizer', default='adam', choices=['sgd', 'adam'])
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--wd', type=float, default=0.0001)
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--client_num_in_total', type=int, default=20)
    parser.add_argument('--client_num_per_round', type=int, default=8)
    parser.add_argument('--comm_round', type=int, default=100,
                        help='Total rounds for FedAvg; rounds per task for continual methods')
    parser.add_argument('--alpha', type=float, default=None, help='Dirichlet alpha: RCFCL 0.5, others 1.0')
    parser.add_argument('--gpu', type=int, default=0, help='NVIDIA GPU index, or -1 to force CPU')

    parser.add_argument('--num_tasks', type=int, default=None,
                        help='Defaults to 5 for 10-class data, 10 for CIFAR100/Tiny-ImageNet, one per Office domain')
    if selection.baseline == 'C2AFCL':
        _calibration_arguments(parser)
    elif selection.baseline == 'RCFCL':
        _drift_arguments(parser)
    parser.add_argument('--gpus', default='', help='Comma-separated GPUs for client processes, e.g. 0,1,2,3')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--download', action='store_true', help='Allow torchvision dataset downloads')
    parser.add_argument('--num_workers', type=int, default=0)
    parser.add_argument('--threads', type=int, default=1)
    parser.add_argument('--eval_every', type=int, default=5)
    parser.add_argument('--output_dir', default=None)
    parser.add_argument('--smoke', action='store_true', help=argparse.SUPPRESS)
    return parser, parser.parse_args(argv)


def _calibration_arguments(parser):
    parser.add_argument('--office_test_fraction', type=float, default=0.2,
                        help='Per-domain, per-class holdout fraction for C2AFCL Office datasets')
    parser.add_argument('--office_image_size', type=int, default=224,
                        help='Square resize for C2AFCL Office datasets')
    parser.add_argument('--task_delay', type=int, default=25, help='Maximum client task-arrival offset (C2AFCL)')
    parser.add_argument('--max_delay', type=int, default=5, help='Upload delay sampled from 1..max_delay (C2AFCL)')
    parser.add_argument('--max_staleness', type=int, default=25, help='Maximum stale server versions (C2AFCL)')
    parser.add_argument('--availability', type=float, default=0.8)
    parser.add_argument('--server_lr', type=float, default=1.0)
    parser.add_argument('--buffer_size', type=int, default=1, help='Updates per task-specific buffer (C2AFCL)')
    parser.add_argument('--subspace_dim', type=int, default=0, help='SVD rank cap; 0 retains all nonzero directions')
    parser.add_argument('--memory_size', type=int, default=300, help='Real replay samples per client (C2AFCL)')
    parser.add_argument('--lr_end_factor', type=float, default=0.01)
    parser.add_argument('--no_intra', action='store_true', help='Disable intra-client calibration (C2AFCL)')
    parser.add_argument('--no_inter', action='store_true', help='Disable inter-task projection (C2AFCL)')


def _drift_arguments(parser):
    parser.add_argument('--rc_tau', type=float, default=0.4)
    parser.add_argument('--rc_epsilon', type=float, default=0.05)
    parser.add_argument('--rc_epsilon0', type=float, default=1e-8)
    parser.add_argument('--rc_sinkhorn_iters', type=int, default=1000,
                        help='Maximum iterations per epsilon-scaling temperature')
    parser.add_argument('--rc_sinkhorn_tol', type=float, default=1e-5)
    parser.add_argument('--rc_detection_samples', type=int, default=64, help='Maximum real/reference samples per class')
    parser.add_argument('--rc_reference_samples', type=int, default=64, help='Generated samples per old class')
    parser.add_argument('--rc_feature_normalize', action='store_true', help='L2-normalize detector features; optional deviation')
    parser.add_argument('--rc_latent_dim', type=int, default=100)
    parser.add_argument('--rc_gan_width', type=int, default=64)
    parser.add_argument('--rc_gan_lr', type=float, default=0.001)
    parser.add_argument('--rc_gan_steps', type=int, default=1)
    parser.add_argument('--rc_gan_loss', choices=['minimax', 'non_saturating'], default='minimax')
    parser.add_argument('--rc_unconditional_discriminator', action='store_true',
                        help='Use the literal D(x) notation instead of conditional D(x,y)')
    parser.add_argument('--rc_drift_type', choices=['mixed', 'gaussian', 'global_rotation',
                        'local_rotation', 'random_erasing'], default='mixed')
    parser.add_argument('--rc_drift_fraction', type=float, default=0.5)
    parser.add_argument('--rc_drift_delay', type=int, default=None, help='Maximum drift-onset round; default comm_round // 2')
    parser.add_argument('--rc_iid', action='store_true', help='Use class-stratified IID partitioning in the RC-FCL stream')
    parser.add_argument('--rc_samples_per_class', type=int, default=60, help='Synthetic training samples per class')


def run(argv):
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    parser, args = _arguments(argv)
    if args.alpha is None:
        args.alpha = 0.5 if args.baseline == 'RCFCL' else 1.0
    if args.num_tasks is None:
        default_tasks = {'mnist': 5, 'cifar10': 5, 'digit10': 5, 'synthetic': 3,
                         **{name: len(domains) for name, domains in OFFICE_DOMAINS.items()}}
        args.num_tasks = default_tasks.get(args.dataset, 10)
    if args.output_dir is None:
        args.output_dir = f'./results/{args.baseline.lower()}'
    if args.smoke:
        args.dataset, args.model = 'synthetic', 'small_cnn'
        args.client_num_in_total, args.client_num_per_round = 4, 2
        args.num_tasks, args.comm_round, args.epochs = 3, 4, 1
        args.batch_size, args.eval_every = 8, 1
        if args.baseline == 'C2AFCL':
            args.task_delay, args.max_delay, args.memory_size = 1, 2, 12
        elif args.baseline == 'RCFCL':
            args.rc_gan_width, args.rc_latent_dim = 8, 16
            args.rc_reference_samples, args.rc_detection_samples = 8, 8
            args.rc_samples_per_class = 24
    if args.baseline == 'RCFCL' and args.rc_drift_delay is None:
        args.rc_drift_delay = args.comm_round // 2
    for name, value in vars(args).items():
        if isinstance(value, float) and not math.isfinite(value):
            parser.error(f'{name} must be finite')
    for name in ('batch_size', 'epochs', 'comm_round', 'client_num_in_total',
                 'client_num_per_round', 'eval_every', 'threads'):
        if getattr(args, name) < 1:
            parser.error(f'{name} must be positive')
    if args.client_num_per_round > args.client_num_in_total:
        parser.error('client_num_per_round cannot exceed client_num_in_total')
    if args.lr <= 0 or args.wd < 0 or args.alpha <= 0 or args.num_workers < 0:
        parser.error('lr and alpha must be positive; wd and num_workers must be nonnegative')
    if args.seed < 0 or args.seed >= 2 ** 32:
        parser.error('seed must be in [0, 2**32)')
    if args.baseline == 'C2AFCL':
        if args.num_tasks < 1 or not 0 <= args.task_delay < args.comm_round:
            parser.error('num_tasks must be positive; task_delay must be in [0, comm_round)')
        if args.max_delay < 1 or args.max_staleness < 0 or args.buffer_size < 1:
            parser.error('max_delay and buffer_size must be positive; max_staleness must be nonnegative')
        if not 0 < args.availability <= 1 or not 0 <= args.lr_end_factor <= 1:
            parser.error('availability must be in (0, 1]; lr_end_factor must be in [0, 1]')
        if args.server_lr <= 0 or args.subspace_dim < 0 or args.memory_size < 0:
            parser.error('server_lr must be positive; subspace_dim and memory_size must be nonnegative')
        if args.dataset in OFFICE_DOMAINS:
            if args.num_tasks != len(OFFICE_DOMAINS[args.dataset]):
                parser.error(f'{args.dataset} has exactly {len(OFFICE_DOMAINS[args.dataset])} domain tasks')
            if not 0 < args.office_test_fraction < 1 or args.office_image_size < 1:
                parser.error('office_test_fraction must be in (0, 1); office_image_size must be positive')
    if args.baseline == 'RCFCL':
        for name in ('num_tasks', 'rc_reference_samples', 'rc_detection_samples', 'rc_latent_dim',
                     'rc_gan_width', 'rc_gan_steps', 'rc_sinkhorn_iters', 'rc_samples_per_class'):
            if getattr(args, name) < 1:
                parser.error(f'{name} must be positive')
        if min(args.rc_epsilon, args.rc_epsilon0, args.rc_sinkhorn_tol, args.rc_gan_lr) <= 0 or args.rc_tau < 0:
            parser.error('RC-FCL epsilon, epsilon0, tolerance and GAN lr must be positive; tau must be nonnegative')
        if not 0 <= args.rc_drift_fraction <= 1 or not 0 <= args.rc_drift_delay < args.comm_round:
            parser.error('rc_drift_fraction must be in [0, 1]; rc_drift_delay must be in [0, comm_round)')
        if args.rc_gan_width < 2:
            parser.error('rc_gan_width must be at least 2')
    if args.gpu < -1:
        parser.error('--gpu must be -1 for CPU or a nonnegative NVIDIA GPU index')
    if args.gpus:
        if args.gpu == -1:
            parser.error('--gpu -1 cannot be used with --gpus')
        try:
            gpu_ids = [int(value.strip()) for value in args.gpus.split(',')]
        except ValueError:
            parser.error('--gpus requires comma-separated integers, e.g. 0,1')
        if not torch.cuda.is_available() or any(i < 0 or i >= torch.cuda.device_count() for i in gpu_ids):
            parser.error('--gpus contains an unavailable NVIDIA GPU')
        if len(gpu_ids) != len(set(gpu_ids)):
            parser.error('--gpus cannot contain duplicates')
        if args.baseline == 'FedAvg':
            parser.error('--gpus supports C2AFCL and RCFCL client processes; use --gpu for FedAvg')
        device = torch.device(f'cuda:{gpu_ids[0]}')
    elif args.gpu == -1:
        device = torch.device('cpu')
    elif torch.cuda.is_available():
        if args.gpu >= torch.cuda.device_count():
            parser.error('--gpu specifies an unavailable NVIDIA GPU')
        device = torch.device(f'cuda:{args.gpu}')
    elif args.gpu > 0:
        parser.error('--gpu specifies an unavailable NVIDIA GPU')
    else:
        device = torch.device('cpu')
    output = Path(args.output_dir)
    if any((output / name).exists() for name in ('model.pt', 'metrics.csv', 'metrics.json', 'events.jsonl')):
        parser.error(f'{output} already contains results; choose a new --output_dir')
    output.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    torch.set_num_threads(args.threads)
    logging.info('Method=%s  Dataset=%s  Device=%s', args.baseline, args.dataset, device)
    if args.baseline == 'RCFCL':
        dataset = load_rcfcl_data(args)
        args.rc_channels, args.rc_image_size = dataset.channels, dataset.image_size
        args.rc_mean, args.rc_std = dataset.mean, dataset.std
        class_num = dataset.num_classes
    else:
        dataset = load_c2afcl_data(args) if args.baseline == 'C2AFCL' else load_data(args)
        class_num = dataset[7]
    channels = getattr(args, 'rc_channels', 1 if args.dataset == 'mnist' else 3)
    model = CLASSIFIERS[args.model](channels, class_num)
    model_trainer = ClassificationTrainer(model, args)
    api_class = {'FedAvg': FedAvgAPI, 'C2AFCL': C2AFCLAPI, 'RCFCL': RCFCLAPI}[args.baseline]
    api = api_class(dataset, device, args, model_trainer)
    api.train()
    logging.info('Results saved to %s', output.resolve())
    return api
