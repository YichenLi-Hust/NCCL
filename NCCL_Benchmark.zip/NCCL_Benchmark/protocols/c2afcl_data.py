from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset, Subset

from ..data import (_loader, _partition, load_data,
                   non_iid_partition_with_dirichlet_distribution, split_into_tasks)
from .rcfcl_data import ImageFiles, _image_paths, _tiny_imagenet


OFFICE_DOMAINS = {
    'office31': ('amazon', 'webcam', 'dslr'),
    'officecaltech10': ('amazon', 'webcam', 'dslr', 'caltech'),
}
OFFICE_CLASSES = {'office31': 31, 'officecaltech10': 10}


class NormalizedImages(Dataset):
    def __init__(self, dataset, domains=None):
        self.dataset = dataset
        self.targets = dataset.targets
        self.domains = domains
        self.mean = torch.tensor((0.485, 0.456, 0.406)).view(3, 1, 1)
        self.std = torch.tensor((0.229, 0.224, 0.225)).view(3, 1, 1)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        image, label = self.dataset[index]
        return (image - self.mean) / self.std, label


def _office_datasets(args):
    expected = OFFICE_DOMAINS[args.dataset]
    root = Path(args.data_dir)
    if not root.is_dir():
        raise FileNotFoundError(f'Office dataset directory not found: {root}')
    children = {entry.name.casefold(): entry for entry in root.iterdir() if entry.is_dir()}
    if not set(expected) <= children.keys():
        for name, path in children.items():
            if name.replace('-', '').replace('_', '') == args.dataset:
                root = path
                children = {entry.name.casefold(): entry for entry in root.iterdir() if entry.is_dir()}
                break
    missing = [name for name in expected if name not in children]
    if missing:
        raise FileNotFoundError(f'Missing Office domains in {root}: {", ".join(missing)}')

    records = {domain: {} for domain in expected}
    for domain in expected:
        folder = children[domain]
        if (folder / 'images').is_dir():
            folder = folder / 'images'
        for path in folder.iterdir():
            if path.is_dir() and not path.name.startswith('.'):
                images = _image_paths(path)
                if images:
                    records[domain][path.name] = images
    classes = sorted(records[expected[0]])
    class_count = OFFICE_CLASSES[args.dataset]
    for domain, paths in records.items():
        if len(classes) != class_count or set(paths) != set(classes):
            raise ValueError(f'Expected the same {class_count} class directories in every domain; check {children[domain]}')

    samples = {'train': [], 'test': []}
    domains = {'train': [], 'test': []}
    rng = np.random.default_rng(args.seed)
    for domain_id, domain in enumerate(expected):
        for label, name in enumerate(classes):
            paths = records[domain][name]
            if len(paths) < 2:
                raise ValueError(f'Need at least two images for class {name} in domain {domain} to split train and test')
            shuffled = rng.permutation(len(paths))
            test_count = max(1, min(len(paths) - 1, round(len(paths) * args.office_test_fraction)))
            for split, indices in (('test', shuffled[:test_count]), ('train', shuffled[test_count:])):
                samples[split].extend((str(paths[index]), label) for index in indices)
                domains[split].extend([domain_id] * len(indices))
    train, test = (NormalizedImages(ImageFiles(samples[split], classes, args.office_image_size),
                                    np.asarray(domains[split], dtype=np.int64))
                   for split in ('train', 'test'))
    return train, test, class_count


def load_c2afcl_data(args):
    if args.dataset in OFFICE_DOMAINS:
        return _partition(*_office_datasets(args), args)
    if args.dataset == 'tinyimagenet':
        train, test = _tiny_imagenet(Path(args.data_dir))
        return _partition(NormalizedImages(train), NormalizedImages(test), 200, args)
    return load_data(args)


def split_c2afcl_tasks(dataset, args):
    task_domains = OFFICE_DOMAINS.get(args.dataset)
    if task_domains is None:
        client_tasks, task_tests, task_classes = split_into_tasks(dataset, args)
        return client_tasks, task_tests, task_classes, None
    if args.num_tasks != len(task_domains):
        raise ValueError(f'{args.dataset} has exactly {len(task_domains)} domain tasks')
    train, test, num_classes = dataset[2].dataset, dataset[3].dataset, dataset[7]
    client_tasks = {client: {} for client in range(args.client_num_in_total)}
    task_tests = []
    task_classes = [list(range(num_classes)) for _ in task_domains]
    for task, domain in enumerate(task_domains):
        indices = np.flatnonzero(train.domains == task)
        if len(indices) < args.client_num_in_total:
            raise ValueError(f'Domain {domain} has {len(indices)} training samples for {args.client_num_in_total} clients')
        partitions = non_iid_partition_with_dirichlet_distribution(
            train.targets[indices], args.client_num_in_total, num_classes, args.alpha,
            seed=args.seed + 1000 + task,
        )
        for client, local_indices in partitions.items():
            subset = Subset(train, indices[local_indices].tolist())
            client_tasks[client][task] = _loader(subset, args.batch_size, True,
                                               args.seed + 1000 + task * args.client_num_in_total + client,
                                               args.num_workers)
        test_indices = np.flatnonzero(test.domains == task).tolist()
        task_tests.append(_loader(Subset(test, test_indices), args.batch_size, num_workers=args.num_workers))
    return client_tasks, task_tests, task_classes, list(task_domains)
