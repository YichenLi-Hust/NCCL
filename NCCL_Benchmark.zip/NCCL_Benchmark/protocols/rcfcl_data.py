import math
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from ..data import _labels, _synthetic, non_iid_partition_with_dirichlet_distribution


DRIFT_TYPES = ("gaussian", "global_rotation", "local_rotation", "random_erasing")
_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".ppm", ".tif", ".tiff", ".webp"}


def _seed(seed, *parts):
    return int(np.random.SeedSequence([int(seed), *map(int, parts)]).generate_state(1)[0])


def _iid_indices(indices, labels, client_count, seed):
    rng = np.random.default_rng(seed)
    parts = {client: [] for client in range(client_count)}
    stage_labels = labels[indices]
    for label in np.unique(stage_labels):
        class_indices = rng.permutation(indices[stage_labels == label])
        # Randomize ties while assigning extra samples to the smallest client shards.
        ordered = sorted(rng.permutation(client_count), key=lambda client: len(parts[client]))
        for client, chunk in zip(ordered, np.array_split(class_indices, client_count)):
            parts[client].extend(chunk.tolist())
    for local in parts.values():
        rng.shuffle(local)
    return parts


def sample_drift(kind, rng):
    if kind == "mixed":
        kind = DRIFT_TYPES[int(rng.integers(len(DRIFT_TYPES)))]
    if kind not in DRIFT_TYPES:
        raise ValueError(f"Unknown drift type: {kind}")
    result = {"type": kind}
    if kind == "gaussian":
        result["variance"] = float(rng.uniform(0.1, 0.4))
    elif kind == "global_rotation":
        result["angle"] = float(rng.uniform(10.0, 350.0))
    else:
        result["top"] = float(rng.uniform())
        result["left"] = float(rng.uniform())
        if kind == "local_rotation":
            result["quarter_turns"] = int(rng.integers(1, 4))
        else:
            result["area"] = float(rng.uniform(0.1, 0.3))
            result["value"] = 0.5
    return result


def apply_drift(image, parameters, seed):
    if parameters is None:
        return image.clone()
    result = image.clone()
    kind = parameters["type"]
    if kind == "gaussian":
        rng = torch.Generator().manual_seed(seed)
        noise = torch.randn(result.shape, generator=rng, dtype=result.dtype)
        return (result + math.sqrt(parameters["variance"]) * noise).clamp(0, 1)
    if kind == "global_rotation":
        from torchvision.transforms import InterpolationMode
        from torchvision.transforms.functional import rotate
        return rotate(result, parameters["angle"], InterpolationMode.BILINEAR, fill=0).clamp(0, 1)
    height, width = result.shape[-2:]
    if kind == "local_rotation":
        side = min(height, width) // 2
    elif kind == "random_erasing":
        minimum = math.ceil(math.sqrt(0.1 * height * width))
        maximum = math.floor(math.sqrt(0.3 * height * width))
        side = min(min(height, width), max(minimum, min(maximum, int(math.sqrt(parameters["area"] * height * width)))))
    else:
        raise ValueError(f"Unknown drift type: {kind}")
    top = min(height - side, int(parameters["top"] * (height - side + 1)))
    left = min(width - side, int(parameters["left"] * (width - side + 1)))
    patch = result[:, top:top + side, left:left + side]
    if kind == "local_rotation":
        result[:, top:top + side, left:left + side] = torch.rot90(patch, parameters["quarter_turns"], (-2, -1))
    else:
        result[:, top:top + side, left:left + side] = parameters["value"]
    return result.clamp(0, 1)


class DriftDataset(Dataset):
    def __init__(self, dataset, indices, transforms, seed):
        self.dataset = dataset
        self.indices = list(map(int, indices))
        self.targets = _labels(dataset)[self.indices]
        self.transforms = transforms
        self.seed = seed

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, item):
        index = self.indices[item]
        image, label = self.dataset[index]
        label = int(label)
        parameters, event_seed = self.transforms.get(label, (None, 0))
        return apply_drift(image, parameters, _seed(self.seed, event_seed, index)), label


class ClientMixtureDataset(Dataset):
    def __init__(self, datasets):
        self.datasets = datasets
        self.length = len(datasets[0]) if datasets else 0
        if any(len(dataset) != self.length for dataset in datasets):
            raise ValueError("Client evaluation distributions must contain the same test indices")
        self.targets = np.concatenate([dataset.targets for dataset in datasets]) if datasets else np.empty(0, dtype=np.int64)

    def __len__(self):
        return self.length * len(self.datasets)

    def __getitem__(self, index):
        client, item = divmod(index, self.length)
        return self.datasets[client][item]


class ImageFiles(Dataset):
    def __init__(self, samples, classes, image_size):
        self.samples = samples
        self.classes = classes
        self.targets = np.asarray([label for _, label in samples], dtype=np.int64)
        self.image_size = image_size

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        from PIL import Image
        path, label = self.samples[index]
        with Image.open(path) as file:
            image = file.convert("RGB").resize((self.image_size, self.image_size), Image.Resampling.BILINEAR)
            pixels = np.asarray(image, dtype=np.float32).copy() / 255.0
        return torch.from_numpy(pixels).permute(2, 0, 1), label


def _image_paths(directory):
    return sorted(path for path in directory.rglob("*") if path.is_file() and path.suffix.lower() in _IMAGE_SUFFIXES)


def _image_folder(directory, image_size, expected_classes):
    if not directory.is_dir():
        raise FileNotFoundError(f"Dataset directory not found: {directory}")
    classes = sorted(path.name for path in directory.iterdir() if path.is_dir() and not path.name.startswith("."))
    if len(classes) != expected_classes:
        raise ValueError(f"Expected {expected_classes} classes in {directory}; found {len(classes)}")
    samples = []
    for label, name in enumerate(classes):
        paths = _image_paths(directory / name)
        if not paths:
            raise ValueError(f"No images found for class {name} in {directory}")
        samples.extend((str(path), label) for path in paths)
    return ImageFiles(samples, classes, image_size)


def _tiny_imagenet(root):
    if not (root / "train").is_dir() and (root / "tiny-imagenet-200").is_dir():
        root = root / "tiny-imagenet-200"
    train = _image_folder(root / "train", 64, 200)
    mapping = dict(zip(train.classes, range(200)))
    annotations = root / "val" / "val_annotations.txt"
    if not annotations.is_file():
        raise FileNotFoundError(f"Tiny-ImageNet validation annotations not found: {annotations}")
    samples, seen_files = [], set()
    for line in annotations.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        fields = line.split()
        if len(fields) < 2:
            raise ValueError(f"Invalid Tiny-ImageNet annotation: {line}")
        filename, class_name = fields[:2]
        if filename in seen_files or class_name not in mapping:
            raise ValueError(f"Duplicate filename or unknown class in Tiny-ImageNet annotation: {line}")
        path = root / "val" / "images" / filename
        if not path.is_file():
            raise FileNotFoundError(f"Annotated image not found: {path}")
        samples.append((str(path), mapping[class_name]))
        seen_files.add(filename)
    if set(label for _, label in samples) != set(mapping.values()):
        raise ValueError("Tiny-ImageNet validation annotations must cover all training classes")
    return train, ImageFiles(samples, train.classes, 64)


def _raw_datasets(args):
    name = args.dataset.lower().replace("-", "_")
    if name == "synthetic":
        count = getattr(args, "rc_samples_per_class", 60)
        train = _synthetic(count, args.seed)
        test = _synthetic(max(4, count // 5), _seed(args.seed, 9000))
        return train, test, 6, 3, 32, (0.0,) * 3, (1.0,) * 3, "Synthetic six-class patterns"
    if name in ("tiny_imagenet", "tinyimagenet"):
        train, test = _tiny_imagenet(Path(args.data_dir))
        return train, test, 200, 3, 64, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225), "Tiny-ImageNet labeled validation split used for evaluation"
    if name == "digit10":
        train = _image_folder(Path(args.data_dir) / "train", 32, 10)
        test = _image_folder(Path(args.data_dir) / "test", 32, 10)
        if train.classes != test.classes:
            raise ValueError("Digit10 train/test class directory names must match")
        return train, test, 10, 3, 32, (0.5,) * 3, (0.5,) * 3, "User-provided Digit10 ImageFolder; paper does not identify dataset sources or splits"
    if name not in ("mnist", "cifar10", "cifar100"):
        raise ValueError(f"Unsupported RC-FCL dataset: {args.dataset}")
    from torchvision import datasets, transforms
    if name == "mnist":
        constructor = datasets.MNIST
        transform = transforms.Compose([transforms.Resize((32, 32)), transforms.ToTensor()])
        classes, channels, mean, std = 10, 1, (0.1307,), (0.3081,)
    else:
        constructor = datasets.CIFAR10 if name == "cifar10" else datasets.CIFAR100
        transform = transforms.ToTensor()
        classes, channels = (10 if name == "cifar10" else 100), 3
        mean, std = ((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)) if name == "cifar10" else (
            (0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761)
        )
    train = constructor(args.data_dir, train=True, transform=transform, download=getattr(args, "download", False))
    test = constructor(args.data_dir, train=False, transform=transform, download=getattr(args, "download", False))
    return train, test, classes, channels, 32, mean, std, "MNIST is an auxiliary dataset, not the paper's unspecified Digit10 benchmark" if name == "mnist" else name.upper()


class RCData:
    def __init__(self, train, test, num_classes, channels, image_size, mean, std, description, args):
        self.train_dataset, self.test_dataset = train, test
        self.num_classes, self.channels, self.image_size = num_classes, channels, image_size
        self.mean, self.std = tuple(mean), tuple(std)
        self.num_clients, self.num_tasks = args.client_num_in_total, args.num_tasks
        self.seed, self.comm_round = args.seed, args.comm_round
        iid = getattr(args, 'rc_iid', False)
        delay = getattr(args, "rc_drift_delay", None)
        delay = self.comm_round // 2 if delay is None else delay
        fraction = getattr(args, "rc_drift_fraction", 0.5)
        kind = getattr(args, "rc_drift_type", "mixed")
        if self.num_clients < 1 or self.num_tasks < 1 or num_classes % self.num_tasks:
            raise ValueError("Client/task counts must be positive and num_tasks must divide the class count")
        if self.comm_round < 1 or not isinstance(delay, int) or not 0 <= delay < self.comm_round:
            raise ValueError("rc_drift_delay must be an integer from 0 to comm_round - 1")
        if not np.isfinite(fraction) or not 0 <= fraction <= 1:
            raise ValueError("rc_drift_fraction must be between 0 and 1")
        if kind not in (*DRIFT_TYPES, "mixed"):
            raise ValueError(f"Unknown drift type: {kind}")
        if not np.isfinite(args.alpha) or args.alpha <= 0:
            raise ValueError("alpha must be finite and positive")
        order = np.random.default_rng(self.seed).permutation(num_classes)
        self.task_classes = [classes.tolist() for classes in np.split(order, self.num_tasks)]
        self.events = []
        drift_count = int(math.floor(fraction * self.num_clients + 0.5))
        for task in range(self.num_tasks):
            rng = np.random.default_rng(_seed(self.seed, 10, task))
            old_task = int(rng.integers(task)) if task else None
            selected = sorted(rng.choice(self.num_clients, drift_count, replace=False).tolist()) if task else []
            clients = []
            for client in selected:
                clients.append({"client_id": client, "onset_round": int(rng.integers(delay + 1)),
                                "transform": sample_drift(kind, rng), "seed": _seed(self.seed, 20, task, client)})
            self.events.append({"task_id": task, "old_task": old_task, "clients": clients})
        self.stage_indices = self._shard_indices(args.alpha, iid)
        test_labels = _labels(test)
        self.test_indices = [np.flatnonzero(np.isin(test_labels, classes)).tolist() for classes in self.task_classes]
        if any(not indices for indices in self.test_indices):
            raise ValueError("Every task must have at least one test sample")
        self.protocol = {
            "dataset": args.dataset, "dataset_description": description,
            "class_order": order.tolist(), "task_classes": self.task_classes,
            "clients": self.num_clients, "rounds_per_task": self.comm_round,
            "client_partition": "iid_stratified" if iid else "dirichlet",
            "dirichlet_alpha": None if iid else float(args.alpha), "drift_fraction": float(fraction),
            "drift_clients_per_stage": drift_count, "max_drift_delay": delay,
            "events": self.events,
            "stage_client_sample_counts": [[len(self.stage_indices[task][client]) for client in range(self.num_clients)]
                                           for task in range(self.num_tasks)],
            "real_sample_policy": "Disjoint class-stratified shards across stages and clients; the current stage pool contains the new task and one recurring old task before client partitioning",
            "transformation_policy": "Fixed parameters per client/event; stable independent train/test noise per base index; apply to raw pixels before normalization",
            "recurrence_policy": "Prior client/task transform persists until replaced by a later event; no composition",
            "evaluation_policy": "Equal mixture over clients, repeating each test example under every client's current transform",
            "preprocessing": {"image_size": image_size, "channels": channels, "mean": list(mean), "std": list(std), "training_augmentation": "none", "rotation_interpolation": "bilinear", "rotation_fill": 0.0,
                              "local_rotation_patch": "square with half the image side", "erasing_shape": "square", "erasing_value": 0.5},
            "assumptions": ["Paper does not specify real-stream allocation, drifted-client fraction, onset distribution, transform composition, augmentation, or normalization.",
                            "Onsets are uniform integers from zero through max_drift_delay; client selection is uniform without replacement.",
                            "Future recurrence shards are withheld from earlier training stages; samples are never reused across stages."]
        }

    def _shard_indices(self, alpha, iid):
        labels = _labels(self.train_dataset)
        stage_samples = [[] for _ in range(self.num_tasks)]
        for task, classes in enumerate(self.task_classes):
            appearances = [task] + [stage for stage in range(task + 1, self.num_tasks) if self.events[stage]["old_task"] == task]
            for label in classes:
                indices = np.flatnonzero(labels == label)
                rng = np.random.default_rng(_seed(self.seed, 30, label))
                shards = np.array_split(rng.permutation(indices), len(appearances))
                for stage, shard in zip(appearances, shards):
                    stage_samples[stage].extend(shard.tolist())
        partitions = {}
        for stage, indices in enumerate(stage_samples):
            indices = np.asarray(indices, dtype=np.int64)
            seed = _seed(self.seed, 40, stage)
            if iid:
                partitions[stage] = _iid_indices(indices, labels, self.num_clients, seed)
                continue
            local = non_iid_partition_with_dirichlet_distribution(
                labels[indices], self.num_clients, self.num_classes, alpha, seed=seed
            )
            partitions[stage] = {client: indices[local[client]].tolist() for client in range(self.num_clients)}
        return partitions

    def _validate_time(self, task_id, round_in_task):
        if not 0 <= task_id < self.num_tasks or not 0 <= round_in_task < self.comm_round:
            raise ValueError("Task or round index out of range")

    def _transforms_for(self, client_id, task_id, round_in_task):
        if not 0 <= client_id < self.num_clients:
            raise ValueError("Client index out of range")
        transforms = {}
        for stage in range(1, task_id + 1):
            event = self.events[stage]
            for client_event in event["clients"]:
                if client_event["client_id"] != client_id:
                    continue
                if stage == task_id and round_in_task < client_event["onset_round"]:
                    continue
                for label in self.task_classes[event["old_task"]]:
                    transforms[label] = (client_event["transform"], client_event["seed"])
        return transforms

    def train_dataset_for(self, client_id, task_id, round_in_task):
        self._validate_time(task_id, round_in_task)
        transforms = self._transforms_for(client_id, task_id, round_in_task)
        return DriftDataset(self.train_dataset, self.stage_indices[task_id][client_id], transforms, _seed(self.seed, 50))

    def test_dataset_for(self, task_id, round_in_task, eval_task_id):
        self._validate_time(task_id, round_in_task)
        if not 0 <= eval_task_id <= task_id:
            raise ValueError("Evaluation task must already have arrived")
        datasets = [DriftDataset(self.test_dataset, self.test_indices[eval_task_id],
                                 self._transforms_for(client, task_id, round_in_task), _seed(self.seed, 60))
                    for client in range(self.num_clients)]
        return ClientMixtureDataset(datasets)


def load_rcfcl_data(args):
    return RCData(*_raw_datasets(args), args)
