import math

import torch
import torch.nn.functional as F


def sinkhorn_transport(source, target, epsilon=0.05, max_iter=200, tol=1e-5):
    if source.ndim != 2 or target.ndim != 2 or source.size(1) != target.size(1):
        raise ValueError('Sinkhorn inputs must be nonempty [samples, features] matrices.')
    if not source.size(0) or not target.size(0):
        raise ValueError('Sinkhorn inputs must contain at least one sample.')
    if (not math.isfinite(epsilon) or epsilon <= 0 or max_iter < 1
            or not math.isfinite(tol) or tol <= 0):
        raise ValueError('Sinkhorn epsilon and tolerance must be finite and positive; iterations must be positive.')
    if source.device != target.device:
        raise ValueError('Sinkhorn inputs must use the same device.')
    if not torch.isfinite(source).all() or not torch.isfinite(target).all():
        raise FloatingPointError('Sinkhorn features contain non-finite values.')

    source, target = source.double(), target.double()
    cost = torch.cdist(source, target, p=2, compute_mode='donot_use_mm_for_euclid_dist').square()
    if not torch.isfinite(cost).all():
        raise FloatingPointError('Sinkhorn squared distances overflowed.')
    log_a = cost.new_full((source.size(0),), -math.log(source.size(0)))
    log_b = cost.new_full((target.size(0),), -math.log(target.size(0)))
    potential_a, potential_b = torch.zeros_like(log_a), torch.zeros_like(log_b)
    temperatures = []
    temperature = max(float(cost.max()), epsilon)
    while temperature > epsilon:
        temperatures.append(temperature)
        temperature *= 0.25
    temperatures.append(epsilon)
    iterations = 0
    converged = False
    # Epsilon scaling warm-starts the dual potentials without changing the final objective.
    for temperature in temperatures:
        stage_tolerance = tol if temperature == epsilon else tol * 0.1
        for iteration in range(1, max_iter + 1):
            potential_a = temperature * (log_a - torch.logsumexp(
                (potential_b[None, :] - cost) / temperature, dim=1))
            potential_b = temperature * (log_b - torch.logsumexp(
                (potential_a[:, None] - cost) / temperature, dim=0))
            iterations += 1
            if iteration % 5 == 0 or iteration == max_iter:
                log_plan = (potential_a[:, None] + potential_b[None, :] - cost) / temperature
                row_error = (torch.logsumexp(log_plan, dim=1).exp() - log_a.exp()).abs().max()
                column_error = (torch.logsumexp(log_plan, dim=0).exp() - log_b.exp()).abs().max()
                marginal_error = torch.maximum(row_error, column_error)
                if marginal_error.item() <= stage_tolerance:
                    break
        if temperature == epsilon:
            converged = marginal_error.item() <= tol

    plan = log_plan.exp()
    transport_cost = (plan * cost).sum()
    # Standard convex entropic OT uses +epsilon * sum(T log T).
    objective = transport_cost + epsilon * (plan * log_plan).sum()
    if not torch.isfinite(plan).all() or not torch.isfinite(objective):
        raise FloatingPointError('Sinkhorn transport produced non-finite values.')
    return {'cost': transport_cost, 'regularized_objective': objective, 'plan': plan,
            'marginal_error': float(marginal_error), 'iterations': iterations,
            'final_iterations': iteration, 'temperatures': len(temperatures),
            'converged': converged}


def sinkhorn_distance(source, target, epsilon=0.05, max_iter=200, tol=1e-5,
                      return_plan=False):
    result = sinkhorn_transport(source, target, epsilon, max_iter, tol)
    if not result['converged']:
        raise RuntimeError(f"Sinkhorn did not converge (marginal error {result['marginal_error']:.3g}, "
                           f"tolerance {tol:g}). Increase max_iter or inspect the feature scale.")
    return (result['cost'], result['plan']) if return_plan else result['cost']


def drift_aggregation_weights(scores, epsilon0=1e-8):
    scores = torch.as_tensor(scores)
    if scores.ndim != 2 or not scores.size(0) or not scores.size(1):
        raise ValueError('Drift scores must have shape [participating clients, classes].')
    if not scores.is_floating_point():
        scores = scores.float()
    if not torch.isfinite(scores).all() or (scores < 0).any() or not math.isfinite(epsilon0) or epsilon0 <= 0:
        raise ValueError('Drift scores must be finite and nonnegative; epsilon0 must be positive.')
    prevalence = scores.gt(0).to(scores.dtype).mean(dim=0)
    magnitudes = (scores * prevalence).sum(dim=1) / (prevalence.sum() + epsilon0)
    raw_weights = 1 + magnitudes
    if not torch.isfinite(raw_weights.sum()):
        raise FloatingPointError('Drift aggregation weights overflowed.')
    return raw_weights / raw_weights.sum(), prevalence, magnitudes


def novelty_weights(discriminator_logits, drift_mask):
    logits = discriminator_logits.reshape(-1)
    drift_mask = torch.as_tensor(drift_mask, device=logits.device, dtype=torch.bool).reshape(-1)
    if logits.shape != drift_mask.shape or not torch.isfinite(logits).all():
        raise ValueError('Novelty logits and drift mask must have matching finite vectors.')
    return torch.where(drift_mask, 1 - logits.sigmoid(), torch.ones_like(logits)).detach()


def weighted_cross_entropy(logits, labels, weights, seen_classes=None):
    labels = labels.to(device=logits.device, dtype=torch.long)
    weights = weights.to(device=logits.device, dtype=logits.dtype).detach()
    if labels.ndim != 1 or weights.shape != labels.shape or labels.size(0) != logits.size(0):
        raise ValueError('Classifier labels and weights must match the minibatch size.')
    if not labels.numel() or not torch.isfinite(weights).all() or (weights < 0).any():
        raise ValueError('Classifier weights must be finite and nonnegative in a nonempty batch.')
    if seen_classes is not None:
        classes = torch.as_tensor(seen_classes, dtype=torch.long, device=logits.device)
        if (classes.ndim != 1 or not classes.numel() or classes.unique().numel() != classes.numel()
                or classes.min() < 0 or classes.max() >= logits.size(1)):
            raise ValueError('Seen classes must be unique valid classifier output indices.')
        matches = labels[:, None].eq(classes[None, :])
        if not matches.any(dim=1).all():
            raise ValueError('A training label is outside the seen classes.')
        labels = matches.long().argmax(dim=1)
        logits = logits.index_select(1, classes)
    return (weights * F.cross_entropy(logits, labels, reduction='none')).mean()
