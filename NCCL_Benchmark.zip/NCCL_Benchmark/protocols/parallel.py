import copy
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor

import torch
from torch.utils.data import DataLoader, Subset

from .client import Client
from .classifier import ClassificationTrainer
from ..training import seed_everything

_worker = {}


def _initialize(model, train_dataset, args, device):
    torch.set_num_threads(args.threads)
    if str(device).startswith('cuda'):
        torch.cuda.set_device(device)
    _worker.update(trainer=ClassificationTrainer(model, args), dataset=train_dataset,
                   args=args, device=device)


def _train(job):
    seed_everything(job['seed'])
    args = _worker['args']
    args.lr = job['lr']
    loader = DataLoader(Subset(_worker['dataset'], job['indices']),
                        batch_size=args.batch_size, shuffle=True,
                        generator=torch.Generator().manual_seed(job['seed']), num_workers=0)
    client = Client(job['client'], loader, None, len(job['indices']), args,
                    _worker['device'], _worker['trainer'])
    return client.train(job['weights'])


class ParallelClients:
    def __init__(self, model, train_dataset, args, devices):
        self.executors = [ProcessPoolExecutor(
            max_workers=1, mp_context=mp.get_context('spawn'), initializer=_initialize,
            initargs=(copy.deepcopy(model).cpu(), train_dataset, copy.deepcopy(args), device),
        ) for device in devices]
        self.next_worker = 0

    def submit(self, job):
        executor = self.executors[self.next_worker % len(self.executors)]
        self.next_worker += 1
        return executor.submit(_train, job)

    def close(self):
        for executor in self.executors:
            executor.shutdown(wait=True, cancel_futures=True)
