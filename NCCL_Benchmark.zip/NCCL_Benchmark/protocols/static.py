import csv
import json
import logging
from pathlib import Path

import numpy as np
import torch

from .client import Client


class FedAvgAPI:
    def __init__(self, dataset, device, args, model_trainer):
        self.device = device
        self.args = args
        (self.train_data_num_in_total, self.test_data_num_in_total,
         self.train_global, self.test_global, self.train_data_local_num_dict,
         self.train_data_local_dict, self.test_data_local_dict, self.class_num) = dataset
        self.client_indexes = []
        self.client_list = []
        self.train_acc = []
        self.test_acc = []
        self.history = []
        self.model_trainer = model_trainer
        self._setup_clients(self.train_data_local_num_dict, self.train_data_local_dict,
                            self.test_data_local_dict, model_trainer)

    def _setup_clients(self, sample_counts, train_loaders, test_loaders, model_trainer):
        for client_idx in range(self.args.client_num_in_total):
            self.client_list.append(Client(client_idx, train_loaders.get(client_idx),
                                           test_loaders.get(client_idx),
                                           sample_counts.get(client_idx, 0), self.args,
                                           self.device, model_trainer))

    def train(self):
        w_global = self.model_trainer.get_model_params()
        for round_idx in range(self.args.comm_round):
            self._client_sampling(round_idx, self.args.client_num_in_total,
                                  self.args.client_num_per_round)
            logging.info('Round %s | Clients %s', round_idx + 1, self.client_indexes)
            w_locals = []
            for client_idx in self.client_indexes:
                client = self.client_list[client_idx]
                if client.get_sample_number() == 0:
                    continue

                local_params = client.train(w_global)
                w_locals.append((client.get_sample_number(), local_params))
            if w_locals:
                w_global = self._aggregate(w_locals)
            else:
                logging.warning('Selected clients have no training samples; retaining the previous model.')
            self.model_trainer.set_model_params(w_global)

            interval = max(1, getattr(self.args, 'eval_every',
                                      getattr(self.args, 'eval_interval', 5)))
            if round_idx % interval == 0 or round_idx == self.args.comm_round - 1:
                self._local_test_on_all_clients(round_idx)
        self._save_results()
        return self.history

    def _client_sampling(self, round_idx, client_num_in_total, client_num_per_round):
        count = min(client_num_in_total, client_num_per_round)
        if count <= 0:
            raise ValueError('Total clients and clients per round must be positive.')
        rng = np.random.default_rng(getattr(self.args, 'seed', 0) + round_idx)
        self.client_indexes = (list(range(client_num_in_total)) if count == client_num_in_total
                               else rng.choice(client_num_in_total, count, replace=False).tolist())
        return self.client_indexes

    def _aggregate(self, w_locals):
        nonempty = [(number, params) for number, params in w_locals if number > 0]
        if not nonempty:
            return self.model_trainer.get_model_params()
        total_samples = sum(number for number, _ in nonempty)
        averaged_params = {}
        for name, first in nonempty[0][1].items():
            if torch.is_floating_point(first) or torch.is_complex(first):
                averaged = torch.zeros_like(first)
                for number, params in nonempty:
                    averaged.add_(params[name], alpha=number / total_samples)
                averaged_params[name] = averaged
            else:
                averaged_params[name] = torch.stack([params[name] for _, params in nonempty]).amax(dim=0)
        self.model_trainer.set_model_params(averaged_params)
        return averaged_params

    def _local_test_on_all_clients(self, round_idx):
        train_metrics = self.model_trainer.test(self.train_global, self.device, self.args)
        test_metrics = self.model_trainer.test(self.test_global, self.device, self.args)
        train_total = train_metrics['test_total']
        test_total = test_metrics['test_total']
        record = {
            'round': round_idx + 1,
            'train_accuracy': train_metrics['test_correct'] / train_total if train_total else 0.0,
            'train_loss': train_metrics['test_loss'] / train_total if train_total else 0.0,
            'test_accuracy': test_metrics['test_correct'] / test_total if test_total else 0.0,
            'test_loss': test_metrics['test_loss'] / test_total if test_total else 0.0,
            'test_samples': test_total,
        }
        self.train_acc.append(record['train_accuracy'])
        self.test_acc.append(record['test_accuracy'])
        self.history.append(record)
        logging.info('Round %s | Train accuracy %.4f | Test accuracy %.4f',
                     record['round'], record['train_accuracy'], record['test_accuracy'])
        return record

    def _save_results(self):
        output_dir = Path(getattr(self.args, 'output_dir', 'output/FedAvg'))
        output_dir.mkdir(parents=True, exist_ok=True)
        torch.save(self.model_trainer.get_model_params(), output_dir / 'model.pt')
        with (output_dir / 'metrics.csv').open('w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(self.history[0]))
            writer.writeheader()
            writer.writerows(self.history)
        with (output_dir / 'metrics.json').open('w', encoding='utf-8') as handle:
            json.dump({'baseline': 'FedAvg', 'history': self.history}, handle,
                      ensure_ascii=False, indent=2)
