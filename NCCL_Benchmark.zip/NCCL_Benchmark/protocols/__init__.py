"""Asynchronous continual-learning protocols and static control."""
