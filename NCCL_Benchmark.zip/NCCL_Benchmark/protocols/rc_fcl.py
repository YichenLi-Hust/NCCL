import copy
import csv
import json
import logging
import random
from pathlib import Path

import torch
from torch.utils.data import DataLoader, Dataset

from ..training import state_copy
from ..models.cgan import ConditionalGenerator, Discriminator
from .rcfcl_calibration import drift_aggregation_weights
from .rcfcl_client import ParallelRCClients, RCFCLClient


def average_states(states, weights):
    weights = torch.as_tensor(weights, dtype=torch.float64)
    if len(states) != weights.numel() or not states:
        raise ValueError('A nonempty state list and one weight per state are required')
    if not torch.isfinite(weights).all() or (weights < 0).any() or weights.sum() <= 0:
        raise ValueError('Aggregation weights must be finite, nonnegative and have positive sum')
    weights = weights / weights.sum()
    result = {}
    for name, first in states[0].items():
        values = [state[name] for state in states]
        if any(value.shape != first.shape or not torch.isfinite(value).all() for value in values):
            raise ValueError(f'Invalid client state: {name}')
        if first.is_floating_point() or first.is_complex():
            value = torch.zeros_like(first)
            for weight, local in zip(weights.tolist(), values):
                value.add_(local, alpha=weight)
            if not torch.isfinite(value).all():
                raise FloatingPointError(f'Non-finite aggregation: {name}')
            result[name] = value
        else:
            result[name] = torch.stack(values).amax(dim=0)
    return result


class NormalizedDataset(Dataset):
    def __init__(self, dataset, mean, std):
        self.dataset = dataset
        self.mean = torch.tensor(mean).view(-1, 1, 1)
        self.std = torch.tensor(std).view(-1, 1, 1)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        image, label = self.dataset[index]
        return (image - self.mean) / self.std, label


class RCFCLAPI:
    def __init__(self, dataset, device, args, model_trainer):
        self.dataset, self.device, self.args = dataset, device, args
        self.model_trainer = model_trainer
        self.task_classes = dataset.task_classes
        self.w_global = state_copy(model_trainer.model)
        self.generator = ConditionalGenerator(dataset.num_classes, dataset.channels,
            dataset.image_size, args.rc_latent_dim, args.rc_gan_width)
        self.discriminator = Discriminator(dataset.channels, dataset.image_size,
            args.rc_gan_width, num_classes=None if args.rc_unconditional_discriminator else dataset.num_classes)
        self.g_global = state_copy(self.generator)
        initial_d = state_copy(self.discriminator)
        self.local_discriminators = {k: copy.deepcopy(initial_d) for k in range(args.client_num_in_total)}
        self.client = None if args.gpus else RCFCLClient(copy.deepcopy(model_trainer.model),
            copy.deepcopy(self.generator), copy.deepcopy(self.discriminator), dataset, args, device)
        self.rng = random.Random(args.seed)
        self.history, self.events, self.best_accuracy = [], [], {}
        self.version = 0

    def _references(self, old_classes, task_id):
        labels = torch.tensor(old_classes, dtype=torch.long).repeat_interleave(self.args.rc_reference_samples)
        if not labels.numel():
            return torch.empty(0, self.dataset.channels, self.dataset.image_size, self.dataset.image_size), labels
        self.generator.load_state_dict(self.g_global)
        self.generator.to(self.device).eval()
        rng = torch.Generator().manual_seed((self.args.seed * 1000003 + 90001 + task_id) % 2 ** 32)
        noise = torch.randn(len(labels), self.args.rc_latent_dim, generator=rng)
        images = []
        with torch.no_grad():
            for start in range(0, len(labels), self.args.batch_size):
                end = start + self.args.batch_size
                images.append(self.generator(noise[start:end].to(self.device), labels[start:end].to(self.device)).cpu())
        result = torch.cat(images)
        if not torch.isfinite(result).all() or result.min() < 0 or result.max() > 1:
            raise FloatingPointError('Generator references must be finite pixels in [0, 1]')
        return result, labels

    def _aggregate(self, results):
        scores = torch.stack([item['drift_scores'] for item in results])
        weights, prevalence, magnitude = drift_aggregation_weights(scores, epsilon0=self.args.rc_epsilon0)
        self.w_global = average_states([item['model_state'] for item in results], weights)
        self.g_global = average_states([item['generator_state'] for item in results],
                                       [item['real_samples'] for item in results])
        for item in results:
            self.local_discriminators[item['client']] = item['discriminator_state']
        self.version += 1
        return weights, prevalence, magnitude

    def _evaluate(self, task_id, round_in_task):
        self.model_trainer.set_model_params(self.w_global)
        allowed = sorted(label for task in self.task_classes[:task_id + 1] for label in task)
        accuracy, total_correct, total_samples = {}, 0, 0
        for task in range(task_id + 1):
            data = self.dataset.test_dataset_for(task_id, round_in_task, task)
            loader = DataLoader(NormalizedDataset(data, self.dataset.mean, self.dataset.std),
                                batch_size=self.args.batch_size, num_workers=self.args.num_workers)
            metrics = self.model_trainer.test(loader, self.device, self.args, allowed_classes=allowed)
            if metrics['test_total'] == 0:
                raise ValueError(f'No evaluation samples for task {task}')
            accuracy[task] = 100.0 * metrics['test_correct'] / metrics['test_total']
            total_correct += metrics['test_correct']
            total_samples += metrics['test_total']
            self.best_accuracy[task] = max(self.best_accuracy.get(task, 0.0), accuracy[task])
        drops = [self.best_accuracy[t] - accuracy[t] for t in range(task_id + 1)]
        row = {'round': task_id * self.args.comm_round + round_in_task + 1, 'task': task_id,
               'round_in_task': round_in_task + 1, 'version': self.version,
               'AC': 100.0 * total_correct / total_samples,
               'FS': sum(drops) / len(drops),
               'FS_old': sum(drops[:-1]) / task_id if task_id else 0.0}
        row.update({f'task_{t}': accuracy.get(t) for t in range(self.args.num_tasks)})
        self.history.append(row)
        logging.info('Task=%d Round=%d AC=%.2f FS=%.2f FS_old=%.2f', task_id + 1,
                     round_in_task + 1, row['AC'], row['FS'], row['FS_old'])
        return row

    def _save_results(self, output):
        torch.save({'classifier': self.w_global, 'generator': self.g_global,
                    'task_classes': self.task_classes, 'args': vars(self.args)}, output / 'model.pt')
        with (output / 'metrics.json').open('w') as handle:
            json.dump({'baseline': 'RCFCL', 'history': self.history,
                       'final': self.history[-1], 'config': vars(self.args)}, handle, indent=2, allow_nan=False)
        with (output / 'metrics.csv').open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(self.history[0]))
            writer.writeheader()
            writer.writerows(self.history)

    def train(self):
        output = Path(self.args.output_dir)
        output.mkdir(parents=True, exist_ok=True)
        with (output / 'protocol.json').open('w') as handle:
            json.dump(self.dataset.protocol, handle, indent=2, allow_nan=False)
        with (output / 'config.json').open('w') as handle:
            json.dump(vars(self.args), handle, indent=2, allow_nan=False)
        pool = None
        if self.args.gpus:
            devices = [torch.device(f'cuda:{int(value)}') for value in self.args.gpus.split(',')]
            pool = ParallelRCClients(self.model_trainer.model, self.generator, self.discriminator,
                                     self.dataset, self.args, devices)
        try:
            with (output / 'events.jsonl').open('w') as events_file:
                for task_id in range(self.args.num_tasks):
                    old = sorted(label for task in self.task_classes[:task_id] for label in task)
                    seen = sorted(old + self.task_classes[task_id])
                    reference_images, reference_labels = self._references(old, task_id)
                    reference_classifier = copy.deepcopy(self.w_global)
                    reference_discriminators = copy.deepcopy(self.local_discriminators)
                    for round_in_task in range(self.args.comm_round):
                        selected = self.rng.sample(range(self.args.client_num_in_total), self.args.client_num_per_round)
                        jobs = []
                        for client_id in selected:
                            if len(self.dataset.train_dataset_for(client_id, task_id, round_in_task)) == 0:
                                continue
                            seed = (self.args.seed * 1000003 + (task_id * self.args.comm_round + round_in_task)
                                    * self.args.client_num_in_total + client_id) % 2 ** 32
                            jobs.append({'client': client_id, 'task': task_id, 'round_in_task': round_in_task,
                                'seed': seed, 'model_state': self.w_global, 'generator_state': self.g_global,
                                'discriminator_state': self.local_discriminators[client_id],
                                'reference_images': reference_images, 'reference_labels': reference_labels,
                                'reference_classifier_state': reference_classifier,
                                'reference_discriminator_state': reference_discriminators[client_id],
                                'old_classes': old, 'seen_classes': seen})
                        if pool:
                            futures = [pool.submit(job) for job in jobs]
                            results = [future.result() for future in futures]
                        else:
                            results = [self.client.train(job) for job in jobs]
                        if results:
                            weights, prevalence, magnitude = self._aggregate(results)
                            event = {'round': task_id * self.args.comm_round + round_in_task + 1,
                                'task': task_id, 'version': self.version, 'selected': selected,
                                'clients': [item['client'] for item in results],
                                'classifier_weights': weights.tolist(), 'prevalence': prevalence.tolist(),
                                'drift_magnitudes': magnitude.tolist(),
                                'drift_scores': [item['drift_scores'].tolist() for item in results],
                                'real_samples': [item['real_samples'] for item in results],
                                'local_metrics': [item['metrics'] for item in results]}
                            self.events.append(event)
                            events_file.write(json.dumps(event, allow_nan=False) + '\n')
                            events_file.flush()
                        else:
                            logging.warning('Round has no nonempty participating clients')
                        if (round_in_task + 1) % self.args.eval_every == 0 or round_in_task == self.args.comm_round - 1:
                            self._evaluate(task_id, round_in_task)
                self._save_results(output)
        finally:
            if pool:
                pool.close()
        return self.history
