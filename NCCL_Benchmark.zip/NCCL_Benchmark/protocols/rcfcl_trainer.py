import copy
from contextlib import contextmanager

import torch
from torch import nn
import torch.nn.functional as F

from ..training import avoid_singleton_batch_norm, state_copy
from .rcfcl_calibration import novelty_weights, sinkhorn_transport, weighted_cross_entropy


@contextmanager
def frozen_discriminator(discriminator):
    modes = [(module, module.training) for module in discriminator.modules()]
    gradients = [(parameter, parameter.requires_grad) for parameter in discriminator.parameters()]
    try:
        discriminator.eval()
        for parameter, _ in gradients:
            parameter.requires_grad_(False)
        yield
    finally:
        for parameter, requires_grad in gradients:
            parameter.requires_grad_(requires_grad)
        for module, training in modes:
            module.training = training


class RCFCLTrainer:
    def __init__(self, model, generator, discriminator, args, device):
        self.model = model.to(device)
        self.generator = generator.to(device)
        self.discriminator = discriminator.to(device)
        self.args = args
        self.device = torch.device(device)

    def normalize(self, pixels):
        channels = pixels.size(1)
        mean = pixels.new_tensor(getattr(self.args, 'rc_mean', (0.0,) * channels)).view(1, -1, 1, 1)
        std = pixels.new_tensor(getattr(self.args, 'rc_std', (1.0,) * channels)).view(1, -1, 1, 1)
        if mean.size(1) != channels or std.size(1) != channels or (std <= 0).any():
            raise ValueError('RC-FCL normalization must provide one positive standard deviation per channel.')
        return (pixels - mean) / std

    def _frozen_copy(self, module, state):
        frozen = copy.deepcopy(module)
        if state is not None:
            frozen.load_state_dict(state)
        frozen.eval().requires_grad_(False)
        return frozen

    def _sample_current(self, dataset, old_classes, limit, rng):
        targets = getattr(dataset, 'targets', None)
        if targets is None:
            targets = [dataset[index][1] for index in range(len(dataset))]
        targets = torch.as_tensor(targets, dtype=torch.long).cpu()
        if targets.ndim != 1 or len(targets) != len(dataset):
            raise ValueError('Current dataset targets must match its samples.')
        samples = {}
        for label in old_classes:
            indices = torch.where(targets == label)[0]
            if indices.numel():
                order = torch.randperm(indices.numel(), generator=rng)[:limit]
                samples[label] = torch.stack([dataset[int(index)][0] for index in indices[order]])
        return samples

    def _features(self, model, pixels):
        features = []
        for batch in pixels.split(getattr(self.args, 'batch_size', 32)):
            output = model.forward_features(self.normalize(batch.to(self.device)))
            features.append(output.flatten(1))
        features = torch.cat(features)
        if getattr(self.args, 'rc_feature_normalize', False):
            features = F.normalize(features, dim=1)
        return features

    @torch.no_grad()
    def detect_drift(self, real_loader, reference_images, reference_labels, reference_model,
                     old_classes, seed):
        scores = torch.zeros(self.generator.num_classes, dtype=torch.float64)
        diagnostics = {'detected_classes': [], 'sinkhorn_unconverged': 0,
                       'sinkhorn_max_marginal_error': 0.0, 'sinkhorn_total_iterations': 0,
                       'sinkhorn_max_iterations': 0, 'sinkhorn_max_temperatures': 0,
                       'class_distances': {}}
        if not old_classes or real_loader is None or not len(real_loader.dataset) or not reference_labels.numel():
            return scores, diagnostics
        limit = getattr(self.args, 'rc_detection_samples', 64)
        if limit < 1:
            raise ValueError('rc_detection_samples must be positive.')
        rng = torch.Generator().manual_seed(seed)
        current = self._sample_current(real_loader.dataset, old_classes, limit, rng)
        for label, pixels in current.items():
            indices = torch.where(reference_labels == label)[0]
            if not indices.numel():
                continue
            indices = indices[torch.randperm(indices.numel(), generator=rng)[:limit]]
            result = sinkhorn_transport(
                self._features(reference_model, pixels),
                self._features(reference_model, reference_images[indices]),
                epsilon=getattr(self.args, 'rc_epsilon', 0.05),
                max_iter=getattr(self.args, 'rc_sinkhorn_iters', 1000),
                tol=getattr(self.args, 'rc_sinkhorn_tol', 1e-5))
            if not result['converged']:
                raise RuntimeError(
                    f"Sinkhorn did not converge for class {label} "
                    f"(marginal error {result['marginal_error']:.3g}). "
                    'Increase --rc_sinkhorn_iters or inspect the feature scale; '
                    'no drift score was accepted.')
            distance = float(result['cost'])
            scores[label] = max(0.0, distance - getattr(self.args, 'rc_tau', 0.4))
            diagnostics['class_distances'][int(label)] = distance
            diagnostics['sinkhorn_unconverged'] += int(not result['converged'])
            diagnostics['sinkhorn_max_marginal_error'] = max(
                diagnostics['sinkhorn_max_marginal_error'], result['marginal_error'])
            diagnostics['sinkhorn_total_iterations'] += result['iterations']
            diagnostics['sinkhorn_max_iterations'] = max(diagnostics['sinkhorn_max_iterations'], result['iterations'])
            diagnostics['sinkhorn_max_temperatures'] = max(diagnostics['sinkhorn_max_temperatures'], result['temperatures'])
        diagnostics['detected_classes'] = torch.where(scores > 0)[0].tolist()
        return scores, diagnostics

    def _optimizer(self, parameters, lr, weight_decay=0.0):
        if getattr(self.args, 'client_optimizer', 'adam').lower() == 'sgd':
            return torch.optim.SGD(parameters, lr=lr, weight_decay=weight_decay)
        return torch.optim.Adam(parameters, lr=lr, weight_decay=weight_decay)

    def _gan_step(self, images, labels, rng, optimizer_g, optimizer_d):
        batch_size = images.size(0)
        label_indices = torch.randint(labels.numel(), (batch_size,), generator=rng).to(self.device)
        generated_labels = labels[label_indices]
        noise = torch.randn(batch_size, self.generator.latent_dim, generator=rng).to(self.device)
        optimizer_g.zero_grad(set_to_none=True)
        optimizer_d.zero_grad(set_to_none=True)
        with avoid_singleton_batch_norm(self.generator, batch_size), avoid_singleton_batch_norm(self.discriminator, batch_size):
            generated = self.generator(noise, generated_labels)
            real_logits = self.discriminator(images, labels)
            fake_logits = self.discriminator(generated.detach(), generated_labels)
            discriminator_loss = (F.binary_cross_entropy_with_logits(real_logits, torch.ones_like(real_logits))
                                  + F.binary_cross_entropy_with_logits(fake_logits, torch.zeros_like(fake_logits)))
            if not torch.isfinite(discriminator_loss):
                raise FloatingPointError('RC-FCL discriminator loss is not finite.')
            discriminator_loss.backward()
            optimizer_d.step()

            with frozen_discriminator(self.discriminator):
                fake_logits = self.discriminator(generated, generated_labels)
                objective = getattr(self.args, 'rc_gan_loss', 'minimax')
                if objective == 'minimax':
                    generator_loss = -F.binary_cross_entropy_with_logits(fake_logits, torch.zeros_like(fake_logits))
                elif objective == 'non_saturating':
                    generator_loss = F.binary_cross_entropy_with_logits(fake_logits, torch.ones_like(fake_logits))
                else:
                    raise ValueError('rc_gan_loss must be minimax or non_saturating.')
                if not torch.isfinite(generator_loss):
                    raise FloatingPointError('RC-FCL generator loss is not finite.')
                generator_loss.backward()
            optimizer_g.step()
        return float(generator_loss.detach()), float(discriminator_loss.detach())

    def train_round(self, real_loader, reference_images, reference_labels,
                    reference_classifier_state, reference_discriminator_state,
                    old_classes, seen_classes, seed):
        old_classes = [int(label) for label in old_classes]
        seen_classes = [int(label) for label in seen_classes]
        if len(set(old_classes)) != len(old_classes) or not set(old_classes) <= set(seen_classes):
            raise ValueError('Old classes must be unique and contained in seen classes.')
        if any(label < 0 or label >= self.generator.num_classes for label in seen_classes):
            raise ValueError('Seen classes are outside the generator label range.')
        reference_images = reference_images.detach().cpu()
        reference_labels = reference_labels.detach().to(device='cpu', dtype=torch.long)
        if reference_images.size(0) != reference_labels.numel():
            raise ValueError('Reference images and labels must have matching lengths.')
        if reference_labels.numel() and not torch.isin(reference_labels, torch.tensor(old_classes)).all():
            raise ValueError('Synthetic reference labels must belong to old classes.')
        reference_model = self._frozen_copy(self.model, reference_classifier_state)
        reference_discriminator = self._frozen_copy(self.discriminator, reference_discriminator_state)
        scores, diagnostics = self.detect_drift(real_loader, reference_images, reference_labels,
                                                reference_model, old_classes, seed)
        del reference_model
        keep_replay = scores[reference_labels].eq(0)
        replay_images, replay_labels = reference_images[keep_replay], reference_labels[keep_replay]
        diagnostics.update({'replay_available': len(replay_labels), 'real_samples': 0,
                            'replay_samples': 0, 'classifier_loss': 0.0, 'generator_loss': 0.0,
                            'discriminator_loss': 0.0, 'mean_real_weight': 0.0, 'gan_steps': 0})
        if real_loader is None or not len(real_loader.dataset):
            return self._result(scores, diagnostics)
        if not seen_classes:
            raise ValueError('Training requires at least one seen class.')

        self.model.train()
        self.generator.train()
        self.discriminator.train()
        optimizer = self._optimizer(self.model.parameters(), getattr(self.args, 'lr', 0.001),
                                    getattr(self.args, 'wd', 0.0))
        optimizer_g = self._optimizer(self.generator.parameters(), getattr(self.args, 'rc_gan_lr', 0.001))
        optimizer_d = self._optimizer(self.discriminator.parameters(), getattr(self.args, 'rc_gan_lr', 0.001))
        rng = torch.Generator().manual_seed(seed + 1)
        for _ in range(getattr(self.args, 'epochs', 20)):
            for real_images, real_labels in real_loader:
                real_images = real_images.to(self.device)
                real_labels = real_labels.to(device=self.device, dtype=torch.long)
                if (real_labels < 0).any() or (real_labels >= scores.numel()).any():
                    raise ValueError('Current labels are outside the classifier output range.')
                drift_mask = scores[real_labels.cpu()].gt(0).to(self.device)
                real_weights = torch.ones(real_labels.size(0), device=self.device)
                if drift_mask.any():
                    with torch.no_grad():
                        novelty_logits = reference_discriminator(real_images, real_labels)
                        real_weights = novelty_weights(novelty_logits, drift_mask)
                images, labels, weights = real_images, real_labels, real_weights
                if replay_labels.numel():
                    indices = torch.randint(replay_labels.numel(), (real_labels.numel(),), generator=rng)
                    images = torch.cat((images, replay_images[indices].to(self.device)))
                    labels = torch.cat((labels, replay_labels[indices].to(self.device)))
                    weights = torch.cat((weights, torch.ones(len(indices), device=self.device)))
                    diagnostics['replay_samples'] += len(indices)
                    order = torch.randperm(labels.numel(), generator=rng).to(self.device)
                    images, labels, weights = images[order], labels[order], weights[order]

                diagnostics['real_samples'] += real_labels.numel()
                diagnostics['mean_real_weight'] += float(real_weights.sum())
                batch_size = getattr(self.args, 'batch_size', 32)
                for batch_images, batch_labels, batch_weights in zip(
                        images.split(batch_size), labels.split(batch_size), weights.split(batch_size)):
                    optimizer.zero_grad(set_to_none=True)
                    with avoid_singleton_batch_norm(self.model, batch_images.size(0)):
                        logits = self.model(self.normalize(batch_images))
                        loss = weighted_cross_entropy(logits, batch_labels, batch_weights, seen_classes)
                        if not torch.isfinite(loss):
                            raise FloatingPointError('RC-FCL classifier loss is not finite.')
                        loss.backward()
                        optimizer.step()
                    diagnostics['classifier_loss'] += float(loss.detach()) * batch_labels.numel()
                    for _ in range(getattr(self.args, 'rc_gan_steps', 1)):
                        generator_loss, discriminator_loss = self._gan_step(
                            batch_images, batch_labels, rng, optimizer_g, optimizer_d)
                        diagnostics['generator_loss'] += generator_loss
                        diagnostics['discriminator_loss'] += discriminator_loss
                        diagnostics['gan_steps'] += 1

        total_samples = diagnostics['real_samples'] + diagnostics['replay_samples']
        diagnostics['classifier_loss'] /= max(total_samples, 1)
        diagnostics['mean_real_weight'] /= max(diagnostics['real_samples'], 1)
        diagnostics['generator_loss'] /= max(diagnostics['gan_steps'], 1)
        diagnostics['discriminator_loss'] /= max(diagnostics['gan_steps'], 1)
        return self._result(scores, diagnostics)

    def _result(self, scores, metrics):
        return {'model_state': state_copy(self.model), 'generator_state': state_copy(self.generator),
                'discriminator_state': state_copy(self.discriminator), 'drift_scores': scores,
                'metrics': metrics}
