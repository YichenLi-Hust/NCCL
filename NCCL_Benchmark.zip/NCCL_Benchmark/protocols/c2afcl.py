import copy
import csv
import json
import logging
import random
from pathlib import Path

import torch
from torch.utils.data import DataLoader, Subset

from .c2afcl_data import split_c2afcl_tasks
from .client import Client
from .parallel import ParallelClients
from ..training import seed_everything


class C2AFCLAPI:
    def __init__(self, dataset, device, args, model_trainer):
        self.args, self.device, self.model_trainer = args, device, model_trainer
        self.train_global, self.test_global = dataset[2], dataset[3]
        (self.train_data_local_dict, self.test_tasks, self.task_classes,
         self.task_domains) = split_c2afcl_tasks(dataset, args)
        self.client_list = [Client(k, self.train_data_local_dict[k][0], self.test_tasks[0],
                           len(self.train_data_local_dict[k][0].dataset), args, device, model_trainer)
                            for k in range(args.client_num_in_total)]
        self.w_global = model_trainer.get_model_params()

        self.parameter_names = [name for name, p in model_trainer.model.named_parameters() if p.requires_grad]
        self.parameter_count = sum(self.w_global[name].numel() for name in self.parameter_names)
        self.version = 0
        self.update_cache = {}  # (client_id, task_id) -> raw update
        self.task_sums, self.task_counts = {}, {}
        self.task_buffers = {}
        self.seen_tasks, self.best_accuracy = set(), {}
        self.history, self.events = [], []
        self.rng = random.Random(args.seed)
        self.task_arrival = [[0] + [t * args.comm_round + self.rng.randint(0, args.task_delay)
                            for t in range(1, args.num_tasks)]
                            for _ in range(args.client_num_in_total)]
        self.dispatch_counts = [[0] * args.num_tasks for _ in range(args.client_num_in_total)]
        self.accepted_counts = [[0] * args.num_tasks for _ in range(args.client_num_in_total)]
        self.memory = {k: [] for k in range(args.client_num_in_total)}
        self.memory_seen = {k: set() for k in range(args.client_num_in_total)}
        self.memory_rng = {k: random.Random(args.seed + k + 1) for k in range(args.client_num_in_total)}

    def _flatten(self, weights):
        return torch.cat([weights[name].detach().cpu().reshape(-1) for name in self.parameter_names])

    def _set_vector(self, vector):
        start = 0
        for name in self.parameter_names:
            old = self.w_global[name]
            self.w_global[name] = vector[start:start + old.numel()].view_as(old).clone()
            start += old.numel()

    def _calibrate_update(self, client_id, task_id, raw_update):
        old = self.update_cache.get((client_id, task_id))
        delta = raw_update.clone()
        if old is not None and not self.args.no_intra:
            delta = delta - old

        # Eq. (5): project against earlier task means.
        history = [self.task_sums[j] / self.task_counts[j]
                   for j in sorted(self.task_sums) if j < task_id]
        safe, rank = delta, 0
        if history and not self.args.no_inter:
            matrix = torch.stack(history, dim=1)
            basis, values, _ = torch.linalg.svd(matrix, full_matrices=False)
            rank = int((values > values[0] * 1e-6).sum())
            if self.args.subspace_dim > 0:
                rank = min(rank, self.args.subspace_dim)
            basis = basis[:, :rank]
            safe = delta - basis @ (basis.T @ delta)
        if not torch.isfinite(safe).all():
            raise FloatingPointError('Calibration produced a nonfinite update; check learning rate and client loss')

        change = raw_update if old is None else raw_update - old
        task_sum = self.task_sums[task_id] + change if task_id in self.task_sums else change.clone()
        if not torch.isfinite(task_sum).all():
            raise FloatingPointError('Historical task mean overflowed')
        self.task_sums[task_id] = task_sum
        self.task_counts[task_id] = self.task_counts.get(task_id, 0) + int(old is None)
        self.update_cache[(client_id, task_id)] = raw_update.clone()
        info = {'rank': rank, 'raw_norm': float(raw_update.double().norm()),
                'delta_norm': float(delta.double().norm()), 'safe_norm': float(safe.double().norm())}
        return safe, info

    def _aggregate(self, task_id):
        # Eq. (6): normalize by the total number of clients.
        updates = self.task_buffers[task_id]
        total = torch.zeros_like(updates[0])
        for update in updates:
            total.add_(update)
        vector = self._flatten(self.w_global) + self.args.server_lr * total / self.args.client_num_in_total
        if not torch.isfinite(vector).all():
            raise FloatingPointError('Server parameters overflowed; check server_lr')
        self._set_vector(vector)
        del self.task_buffers[task_id]
        self.version += 1

    def _receive_update(self, client_id, task_id, raw_update, local_buffers, base_version):
        staleness = self.version - base_version
        if staleness < 0:
            raise ValueError('Downloaded version cannot exceed the current server version')
        info = {'accepted': False, 'staleness': staleness, 'arrival_version': self.version,
                'version': self.version, 'aggregated': False}
        if staleness > self.args.max_staleness:
            return info
        if raw_update.shape != (self.parameter_count,) or not torch.isfinite(raw_update).all():
            raise ValueError('Raw update has an invalid shape or nonfinite values')

        # BatchNorm buffers are excluded from the projection.
        for name, value in local_buffers.items():
            if name not in self.w_global or value.shape != self.w_global[name].shape:
                raise ValueError(f'Model buffer mismatch: {name}')
            if not torch.isfinite(value).all():
                raise ValueError(f'Model buffer contains nonfinite values: {name}')
        safe, calibration_info = self._calibrate_update(client_id, task_id, raw_update)
        self.task_buffers.setdefault(task_id, []).append(safe)
        self.seen_tasks.add(task_id)
        self.accepted_counts[client_id][task_id] += 1
        for name, value in local_buffers.items():
            old = self.w_global[name]
            self.w_global[name] = old * 0.9 + value * 0.1 if old.is_floating_point() else torch.maximum(old, value)
        if len(self.task_buffers[task_id]) >= self.args.buffer_size:
            self._aggregate(task_id)
            info['aggregated'] = True
        info.update(accepted=True, version=self.version, **calibration_info)
        return info

    def _training_indices(self, client_id, task_id):
        current = list(self.train_data_local_dict[client_id][task_id].dataset.indices)
        indices = sorted(set(current) | set(self.memory[client_id]))

        for index in current:
            if index in self.memory_seen[client_id]:
                continue
            self.memory_seen[client_id].add(index)
            memory = self.memory[client_id]
            if len(memory) < self.args.memory_size:
                memory.append(index)
            elif self.args.memory_size:
                slot = self.memory_rng[client_id].randrange(len(self.memory_seen[client_id]))
                if slot < self.args.memory_size:
                    memory[slot] = index
        return indices

    def _train_one_client(self, client_id, indices, weights, seed):
        seed_everything(seed)
        train_loader = DataLoader(Subset(self.train_global.dataset, indices),
                                  batch_size=self.args.batch_size, shuffle=True,
                                  generator=torch.Generator().manual_seed(seed), num_workers=0)
        client = self.client_list[client_id]
        client.local_training_data, client.local_sample_number = train_loader, len(indices)
        return client.train(weights)

    def _released_tasks(self, round_idx):
        return [task for task in range(self.args.num_tasks)
                if any(arrivals[task] <= round_idx for arrivals in self.task_arrival)]

    def _evaluate(self, round_idx):
        self.model_trainer.set_model_params(self.w_global)
        seen = self._released_tasks(round_idx)
        allowed = sorted({label for t in seen for label in self.task_classes[t]})
        accuracy = {}
        for task in seen:
            metrics = self.model_trainer.test(self.test_tasks[task], self.device, self.args,
                                               allowed_classes=allowed)
            accuracy[task] = 100.0 * metrics['test_correct'] / max(1, metrics['test_total'])
        ac = sum(accuracy.values()) / len(seen) if seen else None
        old = seen[:-1]
        fs = sum(max(0.0, self.best_accuracy.get(t, accuracy[t]) - accuracy[t])
                 for t in old) / len(old) if old else 0.0
        for task, value in accuracy.items():
            self.best_accuracy[task] = max(self.best_accuracy.get(task, value), value)
        row = {'round': round_idx, 'version': self.version, 'AC': ac, 'FS': fs,
               'released_tasks': len(seen), 'tasks_with_updates': len(self.seen_tasks)}
        row.update({f'task_{t}': accuracy.get(t) for t in range(self.args.num_tasks)})
        self.history.append(row)
        logging.info('Round=%d version=%d released_tasks=%s AC=%s FS=%.2f', round_idx, self.version,
                     seen, 'N/A' if ac is None else f'{ac:.2f}', fs)

    def train(self):
        # Scheduling rounds and server versions are distinct.
        total_rounds = max(arrivals[-1] for arrivals in self.task_arrival) + self.args.comm_round
        pending, job_id, round_idx = [], 0, 0
        initial_lr = self.args.lr
        pool = None
        if self.args.gpus:
            devices = [torch.device(f'cuda:{int(i)}') for i in self.args.gpus.split(',')]
            pool = ParallelClients(self.model_trainer.model, self.train_global.dataset, self.args, devices)
        output = Path(self.args.output_dir)
        output.mkdir(parents=True, exist_ok=True)
        events_file = (output / 'events.jsonl').open('w')
        try:
            while True:
                due = sorted([item for item in pending if item['due'] <= round_idx],
                             key=lambda item: (item['due'], item['job_id']))
                for item in due:
                    if 'future' in item:
                        local = item.pop('future').result()
                        item['raw'] = self._flatten(local) - item.pop('downloaded')
                        item['buffers'] = {k: v for k, v in local.items() if k not in self.parameter_names}
                    info = self._receive_update(item['client'], item['task'], item['raw'],
                                                item['buffers'], item['base_version'])
                    event = {'round': round_idx, 'client': item['client'], 'task': item['task'],
                             'job_id': item['job_id'], 'base_version': item['base_version'],
                             'dispatch_round': item['dispatch_round'],
                             'task_arrival_round': self.task_arrival[item['client']][item['task']],
                             'current_samples': item['current_samples'],
                             'replay_samples': item['replay_samples'], **info}
                    self.events.append(event)
                    events_file.write(json.dumps(event, allow_nan=False) + '\n')
                    events_file.flush()
                    pending = [p for p in pending if p['job_id'] != item['job_id']]

                if round_idx < total_rounds:
                    busy = {item['client'] for item in pending}
                    selected = self.rng.sample(range(self.args.client_num_in_total), self.args.client_num_per_round)
                    for client_id in selected:
                        if client_id in busy or self.rng.random() >= self.args.availability:
                            continue
                        task_id = sum(time <= round_idx for time in self.task_arrival[client_id]) - 1
                        if len(self.train_data_local_dict[client_id][task_id].dataset) == 0:
                            continue
                        indices = self._training_indices(client_id, task_id)
                        seed = (self.args.seed * 1000003 + job_id) % (2 ** 32)
                        self.args.lr = initial_lr * (1 - (1 - self.args.lr_end_factor) *
                                                    round_idx / max(1, total_rounds - 1))
                        snapshot = copy.deepcopy(self.w_global)
                        item = {'client': client_id, 'task': task_id, 'job_id': job_id,
                                'base_version': self.version,
                                'dispatch_round': round_idx,
                                'current_samples': len(self.train_data_local_dict[client_id][task_id].dataset),
                                'due': round_idx + self.rng.randint(1, self.args.max_delay)}
                        item['replay_samples'] = len(indices) - item['current_samples']
                        if pool:
                            item['downloaded'] = self._flatten(snapshot)
                            item['future'] = pool.submit({'client': client_id, 'indices': indices,
                                                         'weights': snapshot, 'seed': seed, 'lr': self.args.lr})
                        else:
                            local = self._train_one_client(client_id, indices, snapshot, seed)
                            item['raw'] = self._flatten(local) - self._flatten(snapshot)
                            item['buffers'] = {k: v for k, v in local.items() if k not in self.parameter_names}
                        pending.append(item)
                        self.dispatch_counts[client_id][task_id] += 1
                        job_id += 1

                finished = round_idx >= total_rounds and not pending
                if finished:
                    for task_id in sorted(self.task_buffers):
                        self._aggregate(task_id)
                if round_idx % self.args.eval_every == 0 or finished:
                    self._evaluate(round_idx)
                round_idx += 1
                if finished:
                    break
        finally:
            events_file.close()
            if pool:
                pool.close()
            self.args.lr = initial_lr
        self.model_trainer.set_model_params(self.w_global)
        self._save_results(output)

    def _save_results(self, output):
        with (output / 'metrics.csv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(self.history[0]))
            writer.writeheader()
            writer.writerows(self.history)
        (output / 'metrics.json').write_text(json.dumps(self.history, indent=2) + '\n')
        coverage = {
            'data_protocol': 'asynchronous_task_stream',
            'incremental_setting': 'domain' if self.task_domains else 'class',
            'task_domains': self.task_domains,
            'task_classes': self.task_classes,
            'task_arrival': self.task_arrival,
            'dispatch_counts': self.dispatch_counts,
            'accepted_counts': self.accepted_counts,
            'released_tasks': self._released_tasks(self.history[-1]['round']),
            'tasks_without_dispatch': [task for task in range(self.args.num_tasks)
                                       if not any(row[task] for row in self.dispatch_counts)],
            'tasks_without_accepted_update': [task for task in range(self.args.num_tasks)
                                              if not any(row[task] for row in self.accepted_counts)],
            'client_tasks_without_dispatch': [[client, task]
                for client, row in enumerate(self.dispatch_counts)
                for task, count in enumerate(row) if not count],
        }
        (output / 'data_coverage.json').write_text(json.dumps(coverage, indent=2) + '\n')
        # Model export excludes scheduler state and calibration caches.
        torch.save({'model': self.w_global, 'args': vars(self.args),
                    'task_classes': self.task_classes, 'task_domains': self.task_domains,
                    'task_arrival': self.task_arrival,
                    'server_version': self.version}, output / 'model.pt')

        logging.info('C2AFCL completed: accepted uploads %d / %d; paper accuracy remains unverified.',
                     sum(event['accepted'] for event in self.events), len(self.events))
        logging.info('Training coverage: %d/%d client-task pairs dispatched; %d/%d tasks received updates.',
                     self.args.client_num_in_total * self.args.num_tasks - len(coverage['client_tasks_without_dispatch']),
                     self.args.client_num_in_total * self.args.num_tasks,
                     self.args.num_tasks - len(coverage['tasks_without_accepted_update']), self.args.num_tasks)
        if coverage['tasks_without_accepted_update']:
            logging.warning('Tasks %s received no accepted update; their released test sets remain in AC/FS.',
                            coverage['tasks_without_accepted_update'])
