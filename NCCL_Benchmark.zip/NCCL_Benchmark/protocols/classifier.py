import logging

import torch
from torch import nn

from ..training import avoid_singleton_batch_norm, state_copy


class ClassificationTrainer:
    def __init__(self, model, args=None):
        self.model = model
        self.args = args
        self.id = 0

    def get_model_params(self):
        return state_copy(self.model)

    def set_model_params(self, model_parameters):
        self.model.load_state_dict(model_parameters)

    def train(self, train_data, device, args=None):
        args = args if args is not None else self.args
        model = self.model.to(device)
        model.train()
        if train_data is None:
            return 0.0

        parameters = [parameter for parameter in model.parameters() if parameter.requires_grad]
        is_c2afcl = str(getattr(args, 'baseline', 'FedAvg')).lower() == 'c2afcl'
        if args.client_optimizer.lower() == 'sgd':
            optimizer = torch.optim.SGD(parameters, lr=args.lr)
        else:
            optimizer = torch.optim.Adam(parameters, lr=args.lr,
                                         weight_decay=getattr(args, 'wd', 0.0),
                                         amsgrad=not is_c2afcl)

        scheduler = None if is_c2afcl else torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='min', factor=0.2, patience=2)
        criterion = nn.CrossEntropyLoss()
        total_loss, total_samples = 0.0, 0
        for epoch in range(args.epochs):
            epoch_loss, epoch_samples = 0.0, 0
            for images, labels in train_data:
                images = images.to(device)
                labels = labels.to(device, dtype=torch.long)
                optimizer.zero_grad(set_to_none=True)

                with avoid_singleton_batch_norm(model, images.size(0)):
                    logits = model(images)
                    loss = criterion(logits, labels)
                    if not torch.isfinite(loss):
                        raise FloatingPointError(
                            f'Client {self.id} produced a nonfinite training loss; check inputs and learning rate.')
                    loss.backward()
                    optimizer.step()

                batch_size = labels.size(0)
                epoch_loss += loss.item() * batch_size
                epoch_samples += batch_size
            if epoch_samples:
                mean_loss = epoch_loss / epoch_samples
                if scheduler is not None:
                    scheduler.step(mean_loss)
                logging.info('Client %s | Epoch %s | Loss %.6f', self.id, epoch, mean_loss)
                total_loss += epoch_loss
                total_samples += epoch_samples
        return total_loss / total_samples if total_samples else 0.0

    def test(self, test_data, device, args=None, allowed_classes=None):
        model = self.model.to(device)
        model.eval()
        metrics = {'test_correct': 0, 'test_loss': 0.0, 'test_total': 0}
        if test_data is None:
            return metrics
        classes = None
        if allowed_classes is not None:
            classes = torch.as_tensor(list(allowed_classes), dtype=torch.long, device=device)
            if classes.numel() == 0:
                return metrics
            if classes.unique().numel() != classes.numel():
                raise ValueError('allowed_classes must not contain duplicate classes.')

        criterion = nn.CrossEntropyLoss(reduction='sum')
        with torch.no_grad():
            for images, targets in test_data:
                images = images.to(device)
                targets = targets.to(device, dtype=torch.long)
                if classes is not None:
                    matches = targets[:, None].eq(classes[None, :])
                    keep = matches.any(dim=1)
                    if not keep.any():
                        continue
                    images = images[keep]
                    targets = matches[keep].long().argmax(dim=1)
                logits = model(images)
                if classes is not None:
                    if classes.min() < 0 or classes.max() >= logits.size(1):
                        raise ValueError('allowed_classes is outside the classifier output range.')
                    logits = logits.index_select(1, classes)
                metrics['test_loss'] += criterion(logits, targets).item()
                metrics['test_correct'] += logits.argmax(dim=1).eq(targets).sum().item()
                metrics['test_total'] += targets.size(0)
        return metrics
