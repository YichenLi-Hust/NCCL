import copy
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor

import torch
from torch.utils.data import DataLoader

from .rcfcl_trainer import RCFCLTrainer
from ..training import seed_everything


class RCFCLClient:
    def __init__(self, model, generator, discriminator, dataset, args, device):
        self.dataset, self.args = dataset, args
        self.trainer = RCFCLTrainer(model, generator, discriminator, args, device)

    def train(self, job):
        seed_everything(job['seed'])
        self.trainer.model.load_state_dict(job['model_state'])
        self.trainer.generator.load_state_dict(job['generator_state'])
        self.trainer.discriminator.load_state_dict(job['discriminator_state'])
        data = self.dataset.train_dataset_for(job['client'], job['task'], job['round_in_task'])
        loader = DataLoader(data, batch_size=self.args.batch_size, shuffle=True,
                            generator=torch.Generator().manual_seed(job['seed']),
                            num_workers=self.args.num_workers)
        result = self.trainer.train_round(
            loader, job['reference_images'], job['reference_labels'],
            job['reference_classifier_state'], job['reference_discriminator_state'],
            job['old_classes'], job['seen_classes'], job['seed'])
        result.update(client=job['client'], real_samples=len(data))
        return result


_worker = None


def _initialize(model, generator, discriminator, dataset, args, device):
    global _worker
    torch.set_num_threads(args.threads)
    if str(device).startswith('cuda'):
        torch.cuda.set_device(device)
    _worker = RCFCLClient(model, generator, discriminator, dataset, args, device)


def _train(job):
    return _worker.train(job)


class ParallelRCClients:
    def __init__(self, model, generator, discriminator, dataset, args, devices):
        self.executors = [ProcessPoolExecutor(
            max_workers=1, mp_context=mp.get_context('spawn'), initializer=_initialize,
            initargs=(copy.deepcopy(model).cpu(), copy.deepcopy(generator).cpu(),
                      copy.deepcopy(discriminator).cpu(), dataset, copy.deepcopy(args), device),
        ) for device in devices]
        self.next_worker = 0

    def submit(self, job):
        executor = self.executors[self.next_worker % len(self.executors)]
        self.next_worker += 1
        return executor.submit(_train, job)

    def close(self):
        for executor in self.executors:
            executor.shutdown(wait=True, cancel_futures=True)
