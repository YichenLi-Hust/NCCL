"""Shared classifier backbones."""

from .resnet import resnet11, resnet18, small_cnn

CLASSIFIERS = {"resnet11": resnet11, "resnet18": resnet18, "small_cnn": small_cnn}
