import math

import torch
from torch import nn
import torch.nn.functional as F


class ConditionalGenerator(nn.Module):
    def __init__(self, num_classes, channels=3, image_size=32, latent_dim=100, width=64):
        super().__init__()
        if num_classes < 1 or channels < 1 or image_size < 8 or latent_dim < 1 or width < 2:
            raise ValueError('Invalid conditional generator dimensions.')
        self.num_classes = num_classes
        self.channels = channels
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.base_size = math.ceil(image_size / 8)
        self.base_channels = width * 4
        self.label_embedding = nn.Embedding(num_classes, latent_dim)
        self.fc = nn.Linear(latent_dim * 2, self.base_channels * self.base_size ** 2)
        blocks = []
        in_channels = self.base_channels
        for out_channels in (width * 2, width, max(width // 2, 1)):
            blocks.extend([nn.Upsample(scale_factor=2, mode='nearest'),
                           nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
                           nn.BatchNorm2d(out_channels), nn.LeakyReLU(0.2, inplace=True)])
            in_channels = out_channels
        self.blocks = nn.Sequential(*blocks)
        self.output = nn.Conv2d(in_channels, channels, 3, padding=1)

    def forward(self, z, labels):
        if z.ndim != 2 or z.size(1) != self.latent_dim or labels.shape != (z.size(0),):
            raise ValueError('Generator expects latent vectors and one label per sample.')
        features = self.fc(torch.cat((z, self.label_embedding(labels.long())), dim=1))
        features = features.reshape(-1, self.base_channels, self.base_size, self.base_size)
        pixels = self.output(self.blocks(features))
        if pixels.shape[-2:] != (self.image_size, self.image_size):
            pixels = F.interpolate(pixels, size=(self.image_size, self.image_size),
                                   mode='bilinear', align_corners=False)
        return pixels.sigmoid()


class Discriminator(nn.Module):
    def __init__(self, channels=3, image_size=32, width=64, num_classes=None):
        super().__init__()
        if channels < 1 or image_size < 8 or width < 2:
            raise ValueError('Invalid discriminator dimensions.')
        blocks = []
        in_channels = channels
        for out_channels in (width, width * 2, width * 4):
            blocks.extend([nn.Conv2d(in_channels, out_channels, 4, 2, 1, bias=False),
                           nn.BatchNorm2d(out_channels), nn.LeakyReLU(0.2, inplace=True)])
            in_channels = out_channels
        self.features = nn.Sequential(*blocks)
        self.output = nn.Linear(width * 4, 1)
        self.label_embedding = nn.Embedding(num_classes, width * 4) if num_classes is not None else None

    def forward(self, images, labels=None):
        features = self.features(images).mean(dim=(-2, -1))
        logits = self.output(features).flatten()
        if self.label_embedding is not None:
            if labels is None or labels.shape != (images.size(0),):
                raise ValueError('Conditional discriminator requires one label per image.')
            logits = logits + (features * self.label_embedding(labels.long())).sum(dim=1) / math.sqrt(features.size(1))
        return logits
