"""MFCL adapted from Babakniya et al., NeurIPS 2023, Sections 3.1–3.2.

https://proceedings.neurips.cc/paper_files/paper/2023/hash/d160ea01902c33e30660851dfbac5980-Abstract-Conference.html
"""

import math
from contextlib import contextmanager

import torch
from torch import nn
from torch.nn import functional as F

from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.generative import _freeze, _ImageGenerator, _sample
from .survey.strategies import LocalStrategy


@contextmanager
def _inversion_statistics(teacher):
    losses = []

    def measure(layer, inputs):
        value = inputs[0]
        dims = (0, *range(2, value.ndim))
        mean = value.mean(dim=dims)
        variance = value.var(dim=dims, unbiased=False).clamp_min(layer.eps)
        reference = layer.running_var.clamp_min(layer.eps)
        kl = (variance / reference).log() + (reference + (mean - layer.running_mean).square()) / variance - 1
        losses.append(kl.mean() * 0.5)

    hooks = [layer.register_forward_pre_hook(measure) for layer in teacher.modules()
             if isinstance(layer, nn.BatchNorm2d) and layer.track_running_stats]
    try:
        yield losses
    finally:
        for hook in hooks:
            hook.remove()


class MFCL(LocalStrategy):
    """Data-free server inversion and local replay with feature distillation."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.latent_dim = max(stream.num_classes, args.survey_latent_dim)
        self.generator = _ImageGenerator(self.latent_dim, args.survey_gan_width,
                                         stream.channels, stream.image_size).to(device)
        self.mean = torch.tensor(stream.mean, device=device).view(1, -1, 1, 1)
        self.std = torch.tensor(stream.std, device=device).view(1, -1, 1, 1)
        axis = torch.arange(-2, 3, dtype=torch.float32, device=device).square().mul(-0.5).exp()
        kernel = axis[:, None] * axis[None, :]
        self.blur_kernel = (kernel / kernel.sum()).expand(stream.channels, 1, -1, -1).contiguous()
        self.teacher = None
        self.replay = None

    def _synthesize(self, count, class_count):
        noise = torch.randn(count, self.latent_dim, device=self.device)
        indices = noise[:, :class_count].argmax(dim=1)
        pixels = self.generator(noise)
        return pixels, indices

    def begin_task(self, task, old_classes, seen_classes):
        self.current_classes = torch.as_tensor(self.stream.task_classes[task], dtype=torch.long, device=self.device)
        # Preserve the noise coordinate assigned to each class when new classes arrive.
        discovered = dict.fromkeys(label for group in self.stream.task_classes[:task + 1] for label in group)
        self.seen_classes = torch.tensor(list(discovered), dtype=torch.long, device=self.device)
        self.old_classes = self.seen_classes[:len(old_classes)]
        self.current_index = self._class_index(self.current_classes)
        self.seen_index = self._class_index(self.seen_classes)
        self.replay = None
        capacity = self.args.survey_replay_samples
        if self.teacher is None or not self.old_classes.numel() or not capacity:
            return

        batches, targets = [], []
        with torch.no_grad():
            for offset in range(0, capacity, self.args.batch_size):
                remaining = min(self.args.batch_size, capacity - offset)
                pixels, indices = self._synthesize(remaining, self.old_classes.numel())
                batches.append(((pixels - self.mean) / self.std).cpu())
                targets.append(self.old_classes[indices].cpu())
        self.replay = torch.cat(batches), torch.cat(targets)

    def _class_index(self, classes):
        indices = torch.full((self.stream.num_classes,), -1, device=self.device, dtype=torch.long)
        indices[classes] = torch.arange(classes.numel(), device=self.device)
        return indices

    def fit_client(self, client, loader, device):
        self.model.train()
        optimizer = optimizer_for(self.model.parameters(), self.args)
        teacher_weights = self.teacher.fc.weight[self.old_classes] if self.teacher is not None else None
        for _ in range(self.args.epochs):
            for images, labels in loader:
                images, labels = images.to(device), labels.to(device)
                real_count = len(labels)
                if self.replay is not None:
                    generated, pseudo_labels = _sample(self.replay, real_count)
                    images = torch.cat((images, generated.to(device)))
                    labels = torch.cat((labels, pseudo_labels.to(device)))
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(labels)):
                    features = self.model.forward_features(images)
                logits = self.model.fc(features[:real_count])[:, self.current_classes]
                loss = F.cross_entropy(logits, self.current_index[labels[:real_count]])
                if self.replay is not None:
                    calibrated = self.model.fc(features.detach())[:, self.seen_classes]
                    loss = loss + self.args.mfcl_ft_weight * F.cross_entropy(calibrated, self.seen_index[labels])
                if teacher_weights is not None and teacher_weights.numel():
                    with torch.no_grad():
                        previous = self.teacher.forward_features(images)
                    loss = loss + self.args.mfcl_kd_weight * F.linear(features - previous, teacher_weights).square().mean()
                if not torch.isfinite(loss):
                    raise FloatingPointError('MFCL client loss became nonfinite')
                loss.backward()
                optimizer.step()

    def finish_task(self, task):
        self.teacher = _freeze(self.model)
        if not self.args.survey_replay_samples:
            return
        self.generator.train()
        optimizer = torch.optim.Adam(self.generator.parameters(), lr=self.args.mfcl_generator_lr)
        batch_size = max(2, self.args.batch_size)
        for _ in range(self.args.survey_generator_steps):
            optimizer.zero_grad(set_to_none=True)
            pixels, targets = self._synthesize(batch_size, self.seen_classes.numel())
            images = (pixels - self.mean) / self.std
            with _inversion_statistics(self.teacher) as statistics:
                logits = self.teacher(images)[:, self.seen_classes]
            probabilities = logits.softmax(dim=1).mean(dim=0)
            diversity = (probabilities * probabilities.clamp_min(1e-12).log()).mean()
            smooth = F.conv2d(F.pad(pixels, (2, 2, 2, 2), mode='replicate'), self.blur_kernel,
                              groups=self.stream.channels)
            prior = (pixels - smooth).flatten(1).square().sum(dim=1).mean()
            loss = (F.cross_entropy(logits, targets) + self.args.mfcl_diversity_weight * diversity
                    + self.args.mfcl_prior_weight * prior)
            if statistics:
                loss = loss + self.args.mfcl_bn_weight * torch.stack(statistics).mean()
            if not torch.isfinite(loss):
                raise FloatingPointError('MFCL generator inversion loss became nonfinite')
            loss.backward()
            optimizer.step()
        self.generator.eval()

    def checkpoint(self):
        return {'mfcl_generator': state_copy(self.generator), 'mfcl_generator_latent_dim': self.latent_dim}


def add_args(parser):
    parser.add_argument('--mfcl_ft_weight', type=float, default=1.0)
    parser.add_argument('--mfcl_kd_weight', type=float, default=1.0)
    parser.add_argument('--mfcl_diversity_weight', type=float, default=1.0)
    parser.add_argument('--mfcl_bn_weight', type=float, default=75.0)
    parser.add_argument('--mfcl_prior_weight', type=float, default=0.001)
    parser.add_argument('--mfcl_generator_lr', type=float, default=0.001)


def validate_args(parser, args):
    names = ('mfcl_ft_weight', 'mfcl_kd_weight', 'mfcl_diversity_weight', 'mfcl_bn_weight', 'mfcl_prior_weight')
    if any(not math.isfinite(getattr(args, name)) or getattr(args, name) < 0 for name in names):
        parser.error('MFCL loss weights must be finite and nonnegative')
    if not math.isfinite(args.mfcl_generator_lr) or args.mfcl_generator_lr <= 0:
        parser.error('MFCL generator learning rate must be finite and positive')
