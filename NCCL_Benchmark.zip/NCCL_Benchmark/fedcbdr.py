"""Paper-based FedCBDR for the benchmark's synchronous class stream."""

from collections import deque

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader, Subset

from .survey.common import avoid_singleton_batch_norm, optimizer_for
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--fedcbdr_rank", type=int, default=32, help="Rank of the shared leverage subspace")
    parser.add_argument("--fedcbdr_old_temperature", type=float, default=0.9)
    parser.add_argument("--fedcbdr_new_temperature", type=float, default=1.1)
    parser.add_argument("--fedcbdr_old_weight", type=float, default=1.1)
    parser.add_argument("--fedcbdr_new_weight", type=float, default=0.9)


def validate_args(parser, args):
    for name in ("rank", "old_temperature", "new_temperature", "old_weight", "new_weight"):
        if getattr(args, f"fedcbdr_{name}") <= 0:
            parser.error(f"--fedcbdr_{name} must be positive")


def _balanced_sample(candidates, capacity, rng):
    """Allocate one slot per class per pass within separate client budgets."""
    by_label = {}
    selections = [[] for _ in candidates]
    for client, (labels, scores) in enumerate(candidates):
        # Gumbel ranks sample proportionally to leverage without replacement.
        priorities = np.log(np.maximum(scores, 1e-12)) + rng.gumbel(size=len(scores))
        for sample, label in enumerate(labels):
            by_label.setdefault(int(label), []).append((priorities[sample], client, sample))
    class_order = sorted(by_label, key=lambda label: (len(by_label[label]), label))
    queues = deque(deque(sorted(by_label[label], reverse=True)) for label in class_order)
    while queues:
        choices = queues.popleft()
        while choices:
            _, client, sample = choices.popleft()
            if len(selections[client]) < capacity:
                selections[client].append(sample)
                break
        if choices:
            queues.append(choices)
    return selections


class FedCBDR(LocalStrategy):
    """Globally coordinated exemplars and task-aware client temperature scaling.

    See Qi et al., Class-wise Balancing Data Replay for Federated
    Class-Incremental Learning (NeurIPS 2025), Sections 4.1–4.3.
    """

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        if stream.protocol["scenario"] != "class-il":
            raise ValueError("FedCBDR requires disjoint class-incremental tasks")
        self.memory = [None] * len(stream.train[0])
        self.replay_trace = []
        stream.protocol["fedcbdr"] = {
            "rank": args.fedcbdr_rank,
            "replay_capacity_per_client": args.memory_size,
            "replay_trace": self.replay_trace,
            "selection": "Pooled feature Gram and client leverage scores with class-balanced allocation",
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.seen = torch.tensor(seen_classes, dtype=torch.long, device=self.device)
        self.label_index = torch.full((self.stream.num_classes,), -1, dtype=torch.long, device=self.device)
        self.label_index[self.seen] = torch.arange(len(self.seen), device=self.device)
        self.old_classes = torch.isin(self.seen, torch.tensor(old_classes, dtype=torch.long, device=self.device))

    def build_client_data(self, client, current, replay):
        return super().build_client_data(client, current, self.memory[client])

    def fit_client(self, client, loader, device):
        args = self.args
        optimizer = optimizer_for(self.model.parameters(), args)
        temperatures = torch.where(self.old_classes, args.fedcbdr_old_temperature, args.fedcbdr_new_temperature)
        has_old = bool(self.old_classes.any())
        self.model.train()
        for _ in range(args.epochs):
            for inputs, labels in loader:
                inputs, labels = inputs.to(device), self.label_index[labels.to(device)]
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    scores = self.model(inputs).index_select(1, self.seen)
                    if has_old:
                        losses = F.cross_entropy(scores / temperatures, labels, reduction="none")
                        old = self.old_classes[labels]
                        old_loss = (losses * old).sum() / old.sum().clamp_min(1)
                        new_loss = (losses * ~old).sum() / (~old).sum().clamp_min(1)
                        loss = args.fedcbdr_old_weight * old_loss + args.fedcbdr_new_weight * new_loss
                    else:
                        loss = F.cross_entropy(scores, labels)
                loss.backward()
                optimizer.step()

    @torch.no_grad()
    def finish_task(self, task):
        if not self.args.memory_size or task + 1 == self.stream.num_tasks:
            return
        self.model.eval()
        datasets = [self.build_client_data(client, current, None)
                    for client, current in enumerate(self.stream.train[task])]
        feature_sets = []
        gram = None
        for data in datasets:
            if not len(data):
                feature_sets.append((None, np.empty(0, dtype=np.int64)))
                continue
            features, labels = [], []
            for inputs, targets in DataLoader(data, batch_size=self.args.batch_size,
                                              num_workers=self.args.num_workers):
                features.append(self.model.forward_features(inputs.to(self.device)).float().cpu())
                labels.append(targets.cpu())
            features = torch.cat(features)
            local = features.to(self.device)
            contribution = local.T @ local
            gram = contribution if gram is None else gram + contribution
            feature_sets.append((features, torch.cat(labels).numpy()))
        if gram is None:
            return

        # Orthogonal row-mixing cancels in X.T @ X. The shared feature rotation
        # can also be omitted since squared leverage is invariant to it.
        eigenvalues, vectors = torch.linalg.eigh(gram)
        threshold = torch.finfo(gram.dtype).eps * gram.shape[0] * eigenvalues[-1].clamp_min(0)
        rank = min(self.args.fedcbdr_rank, int((eigenvalues > threshold).sum()))
        if rank:
            projection = (vectors[:, -rank:] * eigenvalues[-rank:].rsqrt()).cpu()

        candidates = []
        for features, labels in feature_sets:
            scores = (features @ projection).square().sum(dim=1).numpy() if rank and len(labels) else np.ones(len(labels))
            candidates.append((labels, scores))
        rng = np.random.default_rng(np.random.SeedSequence([self.args.seed, task, 829]))
        selected = _balanced_sample(candidates, self.args.memory_size, rng)
        self.memory = [Subset(dataset, indices) if indices else None
                       for dataset, indices in zip(datasets, selected)]
        chosen_labels = np.concatenate([labels[indices] for (labels, _), indices in zip(candidates, selected)])
        label_counts = np.bincount(chosen_labels, minlength=self.stream.num_classes)
        self.replay_trace.append({"task": task + 1, "clients": [len(indices) for indices in selected],
                                  "class_counts": label_counts.tolist(), "effective_rank": rank})
