"""Survey adaptations of pFedDIL (ECCV 2024) and SR-FDIL (IEEE TPDS 2024)."""

import copy

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import ConcatDataset, DataLoader, Subset

from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--pfeddil_threshold", type=float,
                        help="Reuse threshold (default: 0.8 on Office-31, 0.5 elsewhere)")
    parser.add_argument("--srfdil_gan_epochs", type=int, default=1)
    parser.add_argument("--srfdil_score_mix", type=float, default=0.5,
                        help="Weight of the local prototype score in SR-FDIL")


class PFedDIL(LocalStrategy):
    """Private membership heads and correlation-weighted parameter migration."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.personal_model = copy.deepcopy(model).to(device)
        self.auxiliary = nn.Linear(model.fc.in_features, 1).to(device)
        self.initial = (state_copy(model), state_copy(self.auxiliary))
        self.history = {client: [] for client in range(args.client_num_in_total)}
        self.current = {}
        self.migration = {}
        self.parameter_names = [name for name, _ in model.named_parameters()]
        self.threshold = args.pfeddil_threshold
        if self.threshold is None:
            self.threshold = 0.8 if args.dataset == "office31" else 0.5
        if not 0 <= self.threshold <= 1:
            raise ValueError("pfeddil_threshold must be in [0, 1]")
        stream.protocol["pfeddil"] = {"reuse_threshold": self.threshold,
                                      "evaluation": "Mean of active client ensembles on the shared test stream"}

    def begin_task(self, task, old_classes, seen_classes):
        super().begin_task(task, old_classes, seen_classes)
        self.current.clear()
        self.migration.clear()

    def _load_personal(self, snapshot):
        classifier, auxiliary = snapshot
        self.personal_model.load_state_dict(classifier)
        self.auxiliary.load_state_dict(auxiliary)

    @torch.no_grad()
    def _initialize_client(self, client, loader):
        past = self.history[client]
        self.personal_model.eval()
        matching = []
        for snapshot in past:
            self._load_personal(snapshot)
            strength = 0.0
            for images, _ in loader:
                features = self.personal_model.forward_features(images.to(self.device))
                strength += self.auxiliary(features).sigmoid().sum().item()
            matching.append(strength / len(loader.dataset))

        initial = self.initial if past else (state_copy(self.model), self.initial[1])
        if matching and max(matching) >= self.threshold:
            selected = int(np.argmax(matching))
            initial = past.pop(selected)
            matching.pop(selected)
        self.current[client] = initial
        total = sum(matching)
        if total > 0:
            # The weighted squared distances have the same gradients as one
            # squared distance to the weighted parameter mean.
            center = {}
            for name in self.parameter_names:
                center[name] = sum(
                    snapshot[0][name] * (strength / total)
                    for snapshot, strength in zip(past, matching)
                )
            self.migration[client] = (total, center)

    def fit_client(self, client, loader, device):
        if client in self.current:
            _, auxiliary = self.current[client]
            self.personal_model.load_state_dict(self.model.state_dict())
            self.auxiliary.load_state_dict(auxiliary)
        else:
            self._initialize_client(client, loader)
            self._load_personal(self.current[client])

        model = self.personal_model.train()
        self.auxiliary.train()
        optimizer = optimizer_for(list(model.parameters()) + list(self.auxiliary.parameters()), self.args)
        migration = self.migration.get(client)
        if migration is not None:
            strength, targets = migration
            targets = {name: target.to(device) for name, target in targets.items()}
        for _ in range(self.args.epochs):
            for images, labels in loader:
                images, labels = images.to(device), labels.to(device)
                optimizer.zero_grad()
                with avoid_singleton_batch_norm(model, images.shape[0]):
                    features = model.forward_features(images)
                    logits = model.fc(features)
                membership_logits = self.auxiliary(features)
                loss = F.cross_entropy(logits, labels) + F.softplus(-membership_logits).mean()
                if migration is not None:
                    loss = loss + strength * sum(
                        (value - targets[name]).square().sum() for name, value in model.named_parameters()
                    )
                loss.backward()
                optimizer.step()

        snapshot = state_copy(model)
        self.current[client] = (snapshot, state_copy(self.auxiliary))
        self.model.load_state_dict(snapshot)
        return snapshot

    def finish_task(self, task):
        for client, snapshot in self.current.items():
            self.history[client].append(snapshot)
        self.current.clear()
        self.migration.clear()

    def checkpoint(self):
        return {"personal_models": self.history}

    @torch.no_grad()
    def predict(self, inputs):
        self.personal_model.eval()
        pooled = None
        count = 0
        for client, past in self.history.items():
            snapshots = past + ([self.current[client]] if client in self.current else [])
            if not snapshots:
                continue
            weighted = 0
            weight_total = 0
            for snapshot in snapshots:
                self._load_personal(snapshot)
                features = self.personal_model.forward_features(inputs)
                weight = self.auxiliary(features).sigmoid()
                weighted = weighted + self.personal_model.fc(features).softmax(dim=1) * weight
                weight_total = weight_total + weight
            prediction = weighted / weight_total.clamp_min(1e-12)
            pooled = prediction if pooled is None else pooled + prediction
            count += 1
        if count == 0:
            return self.model(inputs)
        return (pooled / count).clamp_min(1e-12).log()


class SRFDIL(LocalStrategy):
    """Selective replay using local prototypes and a federated discriminator."""

    noise_size = 32
    gan_image_size = 32

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.device = device
        self.stream = stream
        self.memory = [{} for _ in range(args.client_num_in_total)]
        self.client_scores = np.ones(args.client_num_in_total)
        self.discriminator = nn.Sequential(
            nn.Conv2d(stream.channels, 16, 4, stride=2, padding=1),
            nn.LeakyReLU(0.2),
            nn.Conv2d(16, 32, 4, stride=2, padding=1),
            nn.LeakyReLU(0.2),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(32, 1),
        ).to(device)
        self.auxiliary_modules["discriminator"] = self.discriminator
        self.generator = nn.Sequential(
            nn.ConvTranspose2d(self.noise_size, 64, 4),
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, 4, stride=2, padding=1),
            nn.ReLU(),
            nn.ConvTranspose2d(32, 16, 4, stride=2, padding=1),
            nn.ReLU(),
            nn.ConvTranspose2d(16, stream.channels, 4, stride=2, padding=1),
        ).to(device)
        self.initial_generator = state_copy(self.generator)
        self.generators = {}
        self.gan_epochs = args.srfdil_gan_epochs
        self.score_mix = args.srfdil_score_mix
        if self.gan_epochs < 1:
            raise ValueError("srfdil_gan_epochs must be positive")
        if not 0 <= self.score_mix <= 1:
            raise ValueError("srfdil_score_mix must be in [0, 1]")
        stream.protocol["srfdil"] = {"gan_epochs": self.gan_epochs, "local_score_weight": self.score_mix,
                                     "gan_image_size": self.gan_image_size,
                                     "aggregation": "Equal-weight classifier and discriminator averages"}

    def _gan_inputs(self, images):
        return F.interpolate(images, size=(self.gan_image_size, self.gan_image_size),
                             mode="bilinear", align_corners=False)

    @torch.no_grad()
    def _score(self, dataset):
        self.model.eval()
        self.discriminator.eval()
        features, labels, rarity = [], [], []
        for inputs, targets in DataLoader(dataset, batch_size=self.args.batch_size,
                                          num_workers=self.args.num_workers):
            inputs = inputs.to(self.device)
            features.append(self.model.forward_features(inputs).flatten(1).cpu())
            labels.append(targets)
            rarity.append((1.0 - self.discriminator(self._gan_inputs(inputs)).sigmoid().flatten()).cpu())
        features, labels, rarity = torch.cat(features), torch.cat(labels), torch.cat(rarity)
        local_score = torch.empty_like(rarity)
        for label in labels.unique():
            selection = labels == label
            group = features[selection]
            prototype = group.mean(dim=0, keepdim=True)
            local_score[selection] = F.cosine_similarity(group, prototype, dim=1)
        return self.score_mix * local_score + (1.0 - self.score_mix) * rarity

    def begin_task(self, task, old_classes, seen_classes):
        super().begin_task(task, old_classes, seen_classes)
        for client, dataset in enumerate(self.stream.train[task]):
            means = [float(self._score(samples).mean()) for samples in self.memory[client].values()]
            if len(dataset):
                means.append(float(self._score(dataset).mean()))
            self.client_scores[client] = max(float(np.mean(means)), 1e-12) if means else 1e-12

    def sample_clients(self, eligible, count, rng):
        scores = self.client_scores[eligible]
        return rng.choice(eligible, size=count, replace=False, p=scores / scores.sum()).tolist()

    def build_client_data(self, client, dataset, _replay):
        retained = list(self.memory[client].values())
        return ConcatDataset([dataset, *retained]) if retained else dataset

    def aggregation_weight(self, client, loader):
        return 1

    def _adversarial_training(self, client, loader):
        generator = self.generator.train()
        generator.load_state_dict(self.generators.get(client, self.initial_generator))
        discriminator = self.discriminator.train()
        generator_optimizer = torch.optim.Adam(generator.parameters(), lr=self.args.lr, betas=(0.5, 0.99))
        discriminator_optimizer = torch.optim.Adam(discriminator.parameters(), lr=self.args.lr, betas=(0.5, 0.99))
        for _ in range(self.gan_epochs):
            for inputs, _ in loader:
                real = self._gan_inputs(inputs.to(self.device))
                noise_shape = (len(real), self.noise_size, 1, 1)
                with torch.no_grad():
                    generated = generator(torch.randn(noise_shape, device=self.device))
                discriminator_optimizer.zero_grad()
                loss = F.softplus(-discriminator(real)).mean() + F.softplus(discriminator(generated)).mean()
                loss.backward()
                discriminator_optimizer.step()

                generator_optimizer.zero_grad()
                generated = generator(torch.randn(noise_shape, device=self.device))
                discriminator.requires_grad_(False)
                loss = F.softplus(-discriminator(generated)).mean()
                loss.backward()
                generator_optimizer.step()
                discriminator.requires_grad_(True)
        self.generators[client] = state_copy(generator)

    def fit_client(self, client, loader, device):
        snapshot = super().fit_client(client, loader, device)
        self._adversarial_training(client, loader)
        return snapshot

    def finish_task(self, task):
        if self.args.memory_size == 0:
            return
        for client, dataset in enumerate(self.stream.train[task]):
            candidates = self.memory[client].copy()
            if len(dataset):
                candidates[task] = dataset
            scores = [(float(score), source_task, index)
                      for source_task, samples in candidates.items()
                      for index, score in enumerate(self._score(samples))]
            keep = {}
            for _, source_task, index in sorted(scores, reverse=True)[:self.args.memory_size]:
                keep.setdefault(source_task, []).append(index)
            retained = {}
            for source_task, indices in keep.items():
                if source_task != task:
                    indices = [candidates[source_task].indices[index] for index in indices]
                retained[source_task] = Subset(self.stream.train[source_task][client], indices)
            self.memory[client] = retained

    def checkpoint(self):
        return {
            "discriminator": state_copy(self.discriminator),
            "client_generators": self.generators,
            "replay_indices": [{task: samples.indices for task, samples in memory.items()}
                               for memory in self.memory],
        }
