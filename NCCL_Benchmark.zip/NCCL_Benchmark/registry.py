"""Native execution settings. Paper metadata lives in the shared catalog."""

from dataclasses import dataclass

from .catalog import find_work


CLASS_INCREMENTAL_DATASETS = ("cifar10", "cifar100", "tinyimagenet")
DOMAIN_INCREMENTAL_DATASETS = ("digit10", "office31", "officecaltech10")
SURVEY_DATASETS = (*CLASS_INCREMENTAL_DATASETS, *DOMAIN_INCREMENTAL_DATASETS)
DATASET_ALIASES = {
    "cifar-10": "cifar10", "cifar-100": "cifar100", "tiny-imagenet": "tinyimagenet",
    "cifar-10-c": "cifar10c", "cifar-100-c": "cifar100c",
    "digit-10": "digit10", "office-31": "office31", "office-caltech-10": "officecaltech10",
}


def dataset_id(name):
    normalized = name.lower().replace("_", "-")
    return DATASET_ALIASES.get(normalized, normalized)


@dataclass(frozen=True)
class Method:
    id: str
    protocol: str
    backend: str
    baseline: str
    datasets: tuple
    aliases: tuple = ()
    strategy: str = ""

    @property
    def label(self):
        return "FedAvg (static control)" if self.id == "fedavg-static" else find_work(self.id).label

    @property
    def source(self):
        return find_work("fedavg" if self.id == "fedavg-static" else self.id).paper


def synchronized(method_id, strategy, datasets=SURVEY_DATASETS, aliases=()):
    return Method(method_id, "survey", "nccl_benchmark.survey_runner:run_survey",
                  method_id, datasets, aliases, strategy)


PROTOCOL_RUNNER = "nccl_benchmark.protocols.runner:run"
BENCHMARK_METHODS = (
    synchronized("fedavg", "survey.strategies:FedAvg"),
    synchronized("re-fed", "survey.strategies:ReFed"),
    synchronized("fedcil", "survey.generative:FedCIL"),
    synchronized("glfc", "glfc:GLFCStrategy"),
    synchronized("fot", "fot:FOT"),
    synchronized("fedweit", "fedweit:FedWeIT"),
    synchronized("cfed", "cfed:CFeDStrategy"),
    synchronized("target", "survey.generative:Target"),
    synchronized("af-fcl", "survey.strategies:AFFCL"),
    synchronized("mfcl", "mfcl:MFCL"),
    synchronized("pfeddil", "personalized:PFedDIL"),
    synchronized("sr-fdil", "personalized:SRFDIL"),
    Method("c2afcl", "asynchronous-task-arrival", PROTOCOL_RUNNER, "C2AFCL",
           ("cifar100", "tinyimagenet", "office31", "officecaltech10", "cifar10", "mnist")),
    Method("rc-fcl", "asynchronous-concept-drift", PROTOCOL_RUNNER, "RCFCL",
           ("cifar10", "cifar100", "tinyimagenet", "digit10", "mnist")),
    synchronized("fedssi", "fedssi:FedSSI"),
    synchronized("li-fil", "lifil:LiFIL", CLASS_INCREMENTAL_DATASETS),
    synchronized("special", "special:Special", DOMAIN_INCREMENTAL_DATASETS),
    synchronized("fedcbdr", "fedcbdr:FedCBDR", CLASS_INCREMENTAL_DATASETS),
    synchronized("clif", "clif:CLIF", CLASS_INCREMENTAL_DATASETS, ("clif-r",)),
    synchronized("spr-fil", "sprfil:SPRFIL", CLASS_INCREMENTAL_DATASETS),
    synchronized("fedrnc", "fedrnc:FedRNC", CLASS_INCREMENTAL_DATASETS),
    synchronized("hr", "hybrid_rehearsal:HybridRehearsal", CLASS_INCREMENTAL_DATASETS, ("hybrid-rehearsal",)),
    synchronized("can", "can:CAN", CLASS_INCREMENTAL_DATASETS),
    synchronized("pfedmxf", "pfedmxf:PFedMxF", CLASS_INCREMENTAL_DATASETS, ("pfedmixf",)),
    Method("dcu", "decentralized-class-unlearning", "nccl_benchmark.dcu:run", "DCU",
           CLASS_INCREMENTAL_DATASETS),
    Method("bpfedctta", "continual-test-time-adaptation", "nccl_benchmark.protocols.bpfedctta:run",
           "BPFedCTTA", ("cifar10c", "cifar100c", "digit10", "office31", "officecaltech10")),
    synchronized("uopp", "uopp:UOPP", ("cifar100",)),
    synchronized("feat", "feat:FEAT", CLASS_INCREMENTAL_DATASETS, ("feat-f",)),
)
AUXILIARY_METHODS = (
    Method("fedavg-static", "static", PROTOCOL_RUNNER, "FedAvg", ("cifar10", "cifar100", "mnist")),
)
METHODS = (*BENCHMARK_METHODS, *AUXILIARY_METHODS)


def get_method(name):
    def normalize(value):
        return value.casefold().replace("-", "").replace("_", "")

    key = normalize(name)
    for method in METHODS:
        if any(normalize(alias) == key for alias in (method.id, *method.aliases)):
            return method
    raise ValueError(f"unknown method {name!r}. See `python -m nccl_benchmark list`.")
