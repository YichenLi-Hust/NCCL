"""UOPP for federated few-shot class-incremental learning (ICLR 2025)."""

from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Subset

from .data import _labels
from .survey.common import optimizer_for, state_copy
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--uopp_shots", type=int, default=5, help="Maximum novel samples per class at each client")
    parser.add_argument("--uopp_base_classes", type=int, help="Base-task classes (CIFAR-100 default: 60)")
    parser.add_argument("--uopp_weights", help="Local torchvision ViT-B/16 ImageNet-1K state dict")
    parser.add_argument("--uopp_ode_steps", type=int, help="RK4 steps (40 normally, 2 on synthetic)")
    parser.add_argument("--uopp_prompt_length", type=int, default=5)
    parser.add_argument("--uopp_match_weight", type=float, default=1.0)


def validate_args(parser, args):
    if args.dataset not in ("cifar100", "synthetic"):
        parser.error("UOPP supports cifar100 and synthetic")
    if args.uopp_ode_steps is None:
        args.uopp_ode_steps = 2 if args.dataset == "synthetic" else 40
    if min(args.uopp_shots, args.uopp_prompt_length, args.uopp_ode_steps) < 1 or args.uopp_match_weight < 0:
        parser.error("UOPP needs positive shots, prompt length, ODE steps, and a nonnegative matching weight")


def class_groups(num_classes, requested_tasks, args):
    if args.dataset not in ("cifar100", "synthetic"):
        raise ValueError("UOPP supports CIFAR-100 and synthetic class streams")
    base = args.uopp_base_classes
    if base is None:
        base = 60 if args.dataset == "cifar100" else 2
    tasks = requested_tasks if requested_tasks is not None else (9 if args.dataset == "cifar100" else 3)
    if not 0 < base < num_classes or not 2 <= tasks <= num_classes - base + 1:
        raise ValueError("UOPP needs a nonempty base task and at least one class per novel task")
    novel_groups = np.array_split(np.arange(base, num_classes), tasks - 1)
    return (tuple(range(base)), *(tuple(map(int, group)) for group in novel_groups))


def _frozen_vit(args):
    from torchvision.models import ViT_B_16_Weights, vit_b_16
    from torchvision.models.vision_transformer import VisionTransformer

    if args.dataset == "synthetic":
        if args.uopp_weights:
            raise ValueError("--uopp_weights applies to the full-size CIFAR-100 backbone")
        return VisionTransformer(image_size=32, patch_size=8, num_layers=2, num_heads=4,
                                 hidden_dim=32, mlp_dim=64), "seeded tiny ViT (synthetic)"
    weights = ViT_B_16_Weights.IMAGENET1K_V1
    if args.uopp_weights:
        vit = vit_b_16(weights=None)
        vit.load_state_dict(torch.load(args.uopp_weights, map_location="cpu", weights_only=True))
        return vit, "local torchvision ViT-B/16 weights"
    cached = Path(torch.hub.get_dir(), "checkpoints", weights.url.rsplit("/", 1)[-1])
    if not cached.is_file() and not args.download:
        raise FileNotFoundError("Supply --uopp_weights FILE or --download to load ImageNet ViT-B/16 weights")
    return vit_b_16(weights=weights), "torchvision ViT-B/16 IMAGENET1K_V1"


class _Prompts(nn.Module):
    def __init__(self, tasks, dim, length, base_classes):
        super().__init__()
        self.keys = nn.ParameterList([nn.Parameter(torch.randn(length, dim) * 0.02) for _ in range(tasks)])
        self.values = nn.ParameterList([nn.Parameter(torch.randn(length, dim) * 0.02) for _ in range(tasks)])
        self.head = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, base_classes))


def _encoded(vit, images, prefix=None):
    """Use the same task-wise key/value prefix at every frozen ViT attention layer."""
    tokens = vit._process_input(images)
    tokens = torch.cat((vit.class_token.expand(len(images), -1, -1), tokens), dim=1)
    if prefix is None:
        return vit.encoder(tokens)[:, 0]
    x = tokens + vit.encoder.pos_embedding
    for layer in vit.encoder.layers:
        attn = layer.self_attention
        b, n, dim = x.shape
        heads = attn.num_heads
        q, k, v = F.linear(layer.ln_1(x), attn.in_proj_weight, attn.in_proj_bias).chunk(3, -1)
        k = torch.cat((prefix[0].expand(b, -1, -1), k), dim=1)
        v = torch.cat((prefix[1].expand(b, -1, -1), v), dim=1)
        q, k, v = (z.reshape(b, -1, heads, dim // heads).transpose(1, 2) for z in (q, k, v))
        output = F.scaled_dot_product_attention(q, k, v)
        x = x + attn.out_proj(output.transpose(1, 2).reshape(b, n, dim))
        x = x + layer.mlp(layer.ln_2(x))
    return vit.encoder.ln(x)[:, 0]


class _GradNet(nn.Module):
    """A client-local vector field conditioned on labeled support and unlabeled query features."""

    def __init__(self, dim):
        super().__init__()
        width = min(128, dim)
        self.net = nn.Sequential(nn.Linear(2 * dim, width), nn.Tanh(), nn.Linear(width, dim))

    def forward(self, z, support_means, queries):
        weights = (F.normalize(z) @ F.normalize(queries).T * 10).softmax(1)
        return self.net(torch.cat((support_means - z, weights @ queries - z), dim=1))


def _rectify(net, z, support_means, queries, steps):
    dt = 1 / steps
    for _ in range(steps):
        k1 = net(z, support_means, queries)
        k2 = net(z + dt * k1 / 2, support_means, queries)
        k3 = net(z + dt * k2 / 2, support_means, queries)
        k4 = net(z + dt * k3, support_means, queries)
        z = z + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6
    return z


class UOPP(LocalStrategy):
    @staticmethod
    def build_model(args, stream):
        dim = 32 if args.dataset == "synthetic" else 768
        args.model = "tiny-vit-prefix" if args.dataset == "synthetic" else "vit-b16-prefix"
        return _Prompts(stream.num_tasks, dim, args.uopp_prompt_length, len(stream.task_classes[0]))

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        backbone, source = _frozen_vit(args)
        self.vit = backbone.to(device).requires_grad_(False).eval()
        dim = self.vit.hidden_dim
        self.base = len(stream.task_classes[0])
        self.means = torch.zeros(stream.num_classes, dim, device=device)
        self.variances = torch.zeros_like(self.means)
        self.known = torch.zeros(stream.num_classes, dtype=torch.bool, device=device)
        self.gradnet = _GradNet(dim).to(device)
        self.initial_gradnet = state_copy(self.gradnet)
        self.client_gradnets = {}
        self.shot_trace = []
        stream.protocol["uopp"] = {"backbone": source, "novel_shots_per_client_class": args.uopp_shots,
                                   "client_class_training_counts": self.shot_trace, "ode_steps": args.uopp_ode_steps,
                                   "routing": "per-example cosine key matching", "raw_exemplar_replay": False}
        self.normalization = [torch.as_tensor(v, device=device).reshape(1, 3, 1, 1) for v in
                              (stream.mean, stream.std, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225))]

    def _images(self, inputs):
        x = inputs.to(self.device)
        if self.args.dataset == "synthetic":
            return x
        mean, std, target_mean, target_std = self.normalization
        x = (x * std + mean - target_mean) / target_std
        return F.interpolate(x, size=(self.vit.image_size, self.vit.image_size),
                             mode="bilinear", align_corners=False, antialias=True)

    def _features(self, x, task):
        return _encoded(self.vit, x, (self.model.keys[task], self.model.values[task]))

    def begin_task(self, task, old_classes, seen_classes):
        self.task = task
        self.visits = np.zeros(len(self.stream.train[task]), dtype=np.int64)
        self.client_data = {}
        self.shot_trace.append([])
        if task == 0:
            self.stream.protocol["uopp"]["partition_counts_before_sampling"] = [
                counts.copy() for counts in self.stream.protocol["train_client_sample_counts"]
            ]

    def build_client_data(self, client, current, replay):
        labels = _labels(current)
        if self.task:
            rng = np.random.default_rng(np.random.SeedSequence([self.args.seed, self.task, client]))
            indices = []
            for label in np.unique(labels):
                choices = np.flatnonzero(labels == label)
                indices.extend(rng.choice(choices, min(self.args.uopp_shots, len(choices)), replace=False).tolist())
            current, labels = Subset(current, indices), labels[indices]
        self.client_data[client] = current
        classes, counts = np.unique(labels, return_counts=True)
        self.shot_trace[-1].append({int(c): int(n) for c, n in zip(classes, counts)})
        self.stream.protocol["train_client_sample_counts"][self.task][client] = len(current)
        return current

    def _loader(self, data):
        return DataLoader(data, batch_size=self.args.batch_size, num_workers=self.args.num_workers)

    def _moments(self, data):
        total, squared = torch.zeros_like(self.means), torch.zeros_like(self.means)
        counts = torch.zeros(len(total), device=self.device)
        for x, y in self._loader(data):
            y = y.to(self.device)
            features = self._features(self._images(x), self.task)
            total = total.index_add(0, y, features)
            squared = squared.index_add(0, y, features.square())
            counts.index_add_(0, y, torch.ones_like(y, dtype=counts.dtype))
        ids = counts.nonzero().flatten()
        mean = total[ids] / counts[ids, None]
        var = (squared[ids] / counts[ids, None] - mean.square()).clamp_min(0)
        return ids, mean, var

    @torch.no_grad()
    def _merge_prototypes(self, reports):
        sums, second = torch.zeros_like(self.means), torch.zeros_like(self.means)
        weights = torch.zeros(len(sums), device=self.device)
        for ids, means, var, weight in reports:
            sums[ids] += weight * means
            second[ids] += weight * (var + means.square())
            weights[ids] += weight
        mask = weights > 0
        self.means[mask] = sums[mask] / weights[mask, None]
        self.variances[mask] = (second[mask] / weights[mask, None] - self.means[mask].square()).clamp_min(0)
        self.known |= mask

    @torch.no_grad()
    def begin_round(self, task, round_in_task, selected):
        self.reports = []
        self.visits[selected] += 1
        if round_in_task == 1:
            reports = [(*self._moments(self.client_data[client]), 1) for client in selected]
            self._merge_prototypes(reports)

    def aggregation_weight(self, client, loader):
        return int(self.visits[client])

    def _episode(self, data):
        ids, means, var = self._moments(data)
        # Sample multiple local support features per class and global unlabeled query features.
        noise = torch.randn(len(ids), 4, means.shape[1], device=self.device)
        support = means[:, None, :] + noise * (var.detach() + 1e-8).sqrt()[:, None, :]
        queries = self.means[self.known] + torch.randn_like(self.means[self.known]) * self.variances[self.known].sqrt()
        if not len(queries):
            queries = means.detach()
        dynamic = _rectify(self.gradnet, means, support.mean(1), queries, self.args.uopp_ode_steps)
        return ids, dynamic, var, support

    def fit_client(self, client, loader, device):
        task = self.task
        key, value = self.model.keys[task], self.model.values[task]
        parameters = [key, value]
        if task:
            self.gradnet.load_state_dict(self.client_gradnets.get(client, self.initial_gradnet))
            parameters.extend(self.gradnet.parameters())
        else:
            parameters.extend(self.model.head.parameters())
        optimizer = optimizer_for(parameters, self.args)
        for _ in range(self.args.epochs):
            for inputs, labels in loader:
                x, labels = self._images(inputs), labels.to(device)
                features = self._features(x, task)
                with torch.no_grad():
                    query = _encoded(self.vit, x)
                match = 1 - F.cosine_similarity(query, key.mean(0)[None], dim=1).mean()
                if task:
                    ids, dynamic, var, support = self._episode(loader.dataset)
                    centers = self.means.index_copy(0, ids, dynamic)
                    observed = self.known.clone()
                    observed[ids] = True
                    combined = torch.cat((features, support.flatten(0, 1)))
                    targets = torch.cat((labels, ids.repeat_interleave(support.shape[1])))
                    scores = 10 * F.normalize(combined) @ F.normalize(centers).T
                    logits = scores.masked_fill(~observed, -1e3)
                else:
                    known = self.known.nonzero().flatten()
                    combined = torch.cat((features, self.means[known]))
                    targets = torch.cat((labels, known))
                    logits = self.model.head(combined)
                loss = F.cross_entropy(logits, targets) + self.args.uopp_match_weight * match
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
        with torch.no_grad():
            if task:
                self.client_gradnets[client] = state_copy(self.gradnet)
                ids, means, var, _ = self._episode(loader.dataset)
            else:
                ids, means, var = self._moments(loader.dataset)
            self.reports.append((ids, means, var, self.aggregation_weight(client, loader)))

    def post_round(self):
        self._merge_prototypes(self.reports)
        self.reports = []

    def predict(self, inputs):
        x = self._images(inputs)
        keys = torch.stack([key.mean(0) for key in self.model.keys[:self.task + 1]])
        routes = (F.normalize(_encoded(self.vit, x)) @ F.normalize(keys).T).argmax(1)
        logits = x.new_full((len(x), self.stream.num_classes), -1e3)
        for route in routes.unique().tolist():
            mask = routes == route
            features = self._features(x[mask], route)
            if route == 0:
                logits[mask, :self.base] = self.model.head(features)
            else:
                sim = 10 * F.normalize(features) @ F.normalize(self.means).T
                logits[mask] = sim.masked_fill(~self.known, -1e3)
        return logits

    def checkpoint(self):
        return {"frozen_backbone": state_copy(self.vit), "client_gradnets": self.client_gradnets,
                "prototype_means": self.means.cpu(), "prototype_variances": self.variances.cpu(),
                "available_classes": self.known.cpu()}
