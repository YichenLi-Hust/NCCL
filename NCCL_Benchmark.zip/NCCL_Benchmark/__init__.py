"""Benchmark entry points for non-centralized continual learning."""
