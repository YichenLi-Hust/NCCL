import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset


class TensorImageDataset(Dataset):
    def __init__(self, images, labels):
        self.data = torch.as_tensor(images, dtype=torch.float32)
        self.targets = torch.as_tensor(labels, dtype=torch.long)
        if len(self.data) != len(self.targets):
            raise ValueError("Image and label counts do not match")

    def __len__(self):
        return len(self.targets)

    def __getitem__(self, index):
        return self.data[index], self.targets[index]


def read_data(train_data_dir, test_data_dir):
    groups, train_data, test_data = [], {}, {}
    for directory, destination in ((train_data_dir, train_data), (test_data_dir, test_data)):
        files = sorted(Path(directory).glob("*.json"))
        if not files:
            raise FileNotFoundError(f"No MNIST JSON files found: {directory}/*.json")
        for path in files:
            with path.open(encoding="utf-8") as file:
                content = json.load(file)
            for user, values in content["user_data"].items():
                target = destination.setdefault(user, {"x": [], "y": []})
                target["x"].extend(values["x"])
                target["y"].extend(values["y"])
            if destination is train_data:
                groups.extend(content.get("hierarchies", []))
    return sorted(train_data), groups, train_data, test_data


def _leaf_dataset(user_data):
    images, labels = [], []
    for user in sorted(user_data):
        images.extend(user_data[user]["x"])
        labels.extend(user_data[user]["y"])
    images = np.asarray(images, dtype=np.float32).reshape(-1, 1, 28, 28)

    return TensorImageDataset((images > 0).astype(np.float32), labels)


def _labels(dataset):
    if isinstance(dataset, Subset):
        return _labels(dataset.dataset)[dataset.indices]
    targets = dataset.targets
    if torch.is_tensor(targets):
        targets = targets.detach().cpu().numpy()
    return np.asarray(targets, dtype=np.int64)


def non_iid_partition_with_dirichlet_distribution(
    label_list, client_num, classes=None, alpha=0.1, task="classification", seed=0
):
    if client_num < 1 or not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("client_num must be a positive integer and alpha must be positive")
    labels = np.asarray(label_list, dtype=np.int64)
    if labels.ndim != 1:
        raise ValueError("Dirichlet partitioning requires a one-dimensional label array")
    rng = np.random.default_rng(seed)
    partitions = [[] for _ in range(client_num)]
    for label in np.unique(labels):
        indices = rng.permutation(np.flatnonzero(labels == label))
        probabilities = rng.dirichlet(np.full(client_num, alpha))
        counts = rng.multinomial(len(indices), probabilities)
        for destination, chunk in zip(partitions, np.split(indices, np.cumsum(counts)[:-1])):
            destination.extend(chunk.tolist())

    if len(labels) >= client_num:
        for destination in partitions:
            if not destination:
                donor = max(partitions, key=len)
                destination.append(donor.pop())
    for indices in partitions:
        rng.shuffle(indices)
    return dict(enumerate(partitions))


def _loader(dataset, batch_size, shuffle=False, seed=0, num_workers=0):
    return DataLoader(
        dataset, batch_size=batch_size, shuffle=shuffle and len(dataset) > 0,
        drop_last=False, num_workers=num_workers,
        generator=torch.Generator().manual_seed(seed),
    )


def batch_data(data, batch_size):
    return _loader(_leaf_dataset({"user": data}), batch_size, shuffle=True, seed=100)


def _partition(train, test, class_num, args):
    clients = args.client_num_in_total
    train_indices = non_iid_partition_with_dirichlet_distribution(
        _labels(train), clients, class_num, args.alpha, seed=args.seed
    )

    test_indices = np.array_split(np.random.default_rng(args.seed + 1).permutation(len(test)), clients)
    local_train, local_test, local_num = {}, {}, {}
    for client in range(clients):
        local_num[client] = len(train_indices[client])
        local_train[client] = _loader(
            Subset(train, train_indices[client]), args.batch_size, True,
            args.seed + client, args.num_workers,
        )
        local_test[client] = _loader(
            Subset(test, test_indices[client].tolist()), args.batch_size,
            num_workers=args.num_workers,
        )
    return [len(train), len(test),
            _loader(train, args.batch_size, num_workers=args.num_workers),
            _loader(test, args.batch_size, num_workers=args.num_workers),
            local_num, local_train, local_test, class_num]


def _synthetic(samples_per_class, seed):
    if samples_per_class < 1:
        raise ValueError("synthetic_samples_per_class must be positive")
    rng = torch.Generator().manual_seed(seed)
    labels = torch.arange(6).repeat_interleave(samples_per_class)

    colors = torch.tensor([[1., 0., 0.], [0., 1., 0.], [0., 0., 1.],
                           [1., 1., 0.], [0., 1., 1.], [1., 0., 1.]])
    images = colors[labels, :, None, None].expand(-1, -1, 32, 32).clone() * 0.7
    for label in range(6):
        images[labels == label, :, 3 + label * 4:5 + label * 4, :] += 0.2
    images += 0.05 * torch.randn(images.shape, generator=rng)
    return TensorImageDataset(images.clamp(0, 1), labels)


def _raw_datasets(args):
    name = args.dataset.lower()
    if name == "synthetic":
        count = getattr(args, "synthetic_samples_per_class", 12)
        return _synthetic(count, args.seed), _synthetic(max(4, count // 3), args.seed + 10000), 6
    if name == "mnist":
        root = Path(args.data_dir)
        train_path = Path(getattr(args, "train_path", None) or root / "train")
        test_path = Path(getattr(args, "test_path", None) or root / "test")
        if any(train_path.glob("*.json")) or any(test_path.glob("*.json")):
            _, _, train, test = read_data(train_path, test_path)
            return _leaf_dataset(train), _leaf_dataset(test), 10
    if name not in ("mnist", "cifar10", "cifar100"):
        raise ValueError(f"Unsupported dataset {name}; choose mnist/cifar10/cifar100/synthetic")

    from torchvision import datasets, transforms
    if name == "mnist":
        constructor = datasets.MNIST
        train_transform = test_transform = transforms.ToTensor()
        classes = 10
    else:
        constructor = datasets.CIFAR10 if name == "cifar10" else datasets.CIFAR100
        mean, std = ((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)) if name == "cifar10" else (
            (0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761)
        )
        train_transform = transforms.Compose([
            transforms.RandomCrop(32, padding=4), transforms.RandomHorizontalFlip(),
            transforms.ToTensor(), transforms.Normalize(mean, std),
        ])
        test_transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean, std)])
        classes = 10 if name == "cifar10" else 100
    try:
        train = constructor(args.data_dir, train=True, transform=train_transform, download=args.download)
        test = constructor(args.data_dir, train=False, transform=test_transform, download=args.download)
    except RuntimeError as error:
        raise RuntimeError(f"Could not load data; check --data_dir or add --download for the first run. Details: {error}") from error
    return train, test, classes


def load_data(args):
    args = SimpleNamespace(**vars(args))
    for name, default in (("seed", 0), ("num_workers", 0), ("download", False)):
        if not hasattr(args, name):
            setattr(args, name, default)
    return _partition(*_raw_datasets(args), args)


def load_partition_data_mnist(batch_size, client_num_in_total, alpha, data_dir,
                              train_path=None, test_path=None, **kwargs):
    args = SimpleNamespace(dataset="mnist", batch_size=batch_size,
                           client_num_in_total=client_num_in_total, alpha=alpha,
                           data_dir=data_dir, train_path=train_path, test_path=test_path, **kwargs)
    return (client_num_in_total, *load_data(args))


def load_partition_data_cifar10(batch_size, client_number, partition_alpha,
                                data_dir="./data", **kwargs):
    args = SimpleNamespace(dataset="cifar10", batch_size=batch_size,
                           client_num_in_total=client_number, alpha=partition_alpha,
                           data_dir=data_dir, **kwargs)
    return (client_number, *load_data(args))


def load_partition_data_cifar100(batch_size, client_number, partition_alpha,
                                 data_dir="./data", **kwargs):
    args = SimpleNamespace(dataset="cifar100", batch_size=batch_size,
                           client_num_in_total=client_number, alpha=partition_alpha,
                           data_dir=data_dir, **kwargs)
    return (client_number, *load_data(args))


def load_partition_data_synthetic(batch_size, client_number, partition_alpha,
                                  data_dir="./data", **kwargs):
    args = SimpleNamespace(dataset="synthetic", batch_size=batch_size,
                           client_num_in_total=client_number, alpha=partition_alpha,
                           data_dir=data_dir, **kwargs)
    return (client_number, *load_data(args))


def split_into_tasks(dataset, args):
    train, test, class_num = dataset[2].dataset, dataset[3].dataset, dataset[7]
    task_num = args.num_tasks
    if task_num < 1 or class_num % task_num:
        raise ValueError(f"num_tasks={task_num} must divide the class count {class_num}")
    seed, workers = getattr(args, "seed", 0), getattr(args, "num_workers", 0)
    class_order = np.random.default_rng(seed).permutation(class_num)
    task_classes = [classes.tolist() for classes in np.split(class_order, task_num)]
    train_labels, test_labels = _labels(train), _labels(test)
    clients = args.client_num_in_total
    client_tasks = {client: {} for client in range(clients)}
    task_tests = []
    for task, classes in enumerate(task_classes):
        indices = np.flatnonzero(np.isin(train_labels, classes))
        if len(indices) < clients:
            raise ValueError(f"Task {task} has {len(indices)} training samples: insufficient for {clients} clients")
        partitions = non_iid_partition_with_dirichlet_distribution(
            train_labels[indices], clients, class_num, args.alpha, seed=seed + 1000 + task
        )
        for client in range(clients):
            global_indices = indices[partitions[client]].tolist()
            client_tasks[client][task] = _loader(
                Subset(train, global_indices), args.batch_size, True,
                seed + 1000 + task * clients + client, workers,
            )
        task_tests.append(_loader(
            Subset(test, np.flatnonzero(np.isin(test_labels, classes)).tolist()),
            args.batch_size, num_workers=workers,
        ))
    return client_tasks, task_tests, task_classes
