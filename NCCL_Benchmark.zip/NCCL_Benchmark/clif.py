"""CLIF-R adaptation for the benchmark's bounded class-incremental replay.

Qi et al., ICML 2026, https://proceedings.mlr.press/v306/qi26n.html
"""

import copy

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset

from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--clif_p", type=float, default=2.0, help="Lewis weight exponent in [1, 2]")
    parser.add_argument("--clif_peer_views", type=int, default=2,
                        help="maximum number of peer models used to score each client's exemplars")


def validate_args(parser, args):
    if not 1 <= args.clif_p <= 2:
        parser.error("clif_p must be in [1, 2]")
    if args.clif_peer_views < 0:
        parser.error("clif_peer_views must be nonnegative")


def _lewis_weights(features, exponent):
    left, singular, _ = torch.linalg.svd(features.to(torch.float64), full_matrices=False)
    tolerance = singular[0] * max(features.shape) * torch.finfo(singular.dtype).eps
    basis = left[:, singular > tolerance]
    if basis.shape[1] == 0:
        return torch.zeros(len(features), dtype=torch.float64)

    leverage = basis.square().sum(dim=1)
    if exponent == 2:
        return leverage

    weights = leverage.clamp_min(1e-12)
    for _ in range(50):
        scaling = weights.pow(1 - 2 / exponent)
        gram = basis.T @ (scaling[:, None] * basis)
        inverse_rows = torch.linalg.solve(gram, basis.T).T
        update = (basis * inverse_rows).sum(dim=1).clamp_min(1e-24).pow(exponent / 2)
        error = ((update - weights).abs() / weights).max()
        weights = update
        if float(error) < 1e-6:
            break
    return torch.where(leverage > 0, weights, 0)


def _sample_exemplars(scores, capacity, rng):
    """Draw until capacity distinct rows have appeared and record multiplicity."""
    weights = np.maximum(scores, max(scores.max() * 1e-9, np.finfo(np.float64).tiny))
    weights /= weights.sum()
    remaining = weights.copy()
    indices = np.empty(capacity, dtype=np.int64)
    frequencies = np.ones(capacity, dtype=np.int64)
    for position in range(capacity):
        remaining_mass = remaining.sum()
        if position:
            # Geometric failures count draws of already-selected examples.
            repeats = int(rng.geometric(min(1.0, remaining_mass))) - 1
            prior = weights[indices[:position]]
            frequencies[:position] += rng.multinomial(repeats, prior / prior.sum())
        index = rng.choice(len(weights), p=remaining / remaining_mass)
        indices[position] = index
        remaining[index] = 0
    return indices.tolist(), frequencies


class _ReplayExamples(Subset):
    def __init__(self, dataset, indices, frequencies):
        super().__init__(dataset, indices)
        self.frequencies = frequencies


class _WeightedTraining(Dataset):
    def __init__(self, current, replay):
        self.dataset = current if replay is None else ConcatDataset((current, replay))
        self.weights = torch.ones(len(self.dataset), dtype=torch.float32)
        if replay is not None and len(replay):
            counts = torch.as_tensor(replay.frequencies, dtype=torch.float64)
            self.weights[len(current):] = (counts / counts.mean()).to(torch.float32)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        inputs, label = self.dataset[index]
        return inputs, label, self.weights[index]


class CLIF(LocalStrategy):
    uses_local_replay = True

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.last_round_states = {}
        self.replay_counts = {}
        self.selected_views = {}
        stream.protocol["clif"] = {
            "variant": "cross-view Lewis weighting on the shared class-incremental stream",
            "memory": "bounded distinct examples per client across all prior tasks",
            "feature_views": "post-aggregation, own final-round update if available, and sampled final-round peers",
            "loss": "cross entropy with mean-one replay selection frequencies",
            "lewis_p": args.clif_p,
            "max_peer_views": args.clif_peer_views,
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.last_round_states.clear()
        self.task = task
        self.seen = torch.as_tensor(seen_classes, device=self.device)
        self.label_map = torch.full((self.stream.num_classes,), -1, dtype=torch.long, device=self.device)
        self.label_map[self.seen] = torch.arange(len(self.seen), device=self.device)

    def begin_round(self, task, round_in_task, selected):
        self.save_view = (self.args.memory_size > 0 and round_in_task == self.args.comm_round
                          and task + 1 < self.stream.num_tasks)

    def build_client_data(self, client, current, replay):
        return _WeightedTraining(current, replay)

    def fit_client(self, client, loader, device):
        optimizer = optimizer_for(self.model.parameters(), self.args)
        self.model.train()
        for _ in range(self.args.epochs):
            for inputs, labels, weights in loader:
                inputs, weights = inputs.to(device), weights.to(device)
                labels = self.label_map[labels.to(device)]
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    logits = self.model(inputs).index_select(1, self.seen)
                    losses = F.cross_entropy(logits, labels, reduction="none")
                    loss = (losses * weights).sum() / weights.sum()
                loss.backward()
                optimizer.step()
        if self.save_view:
            self.last_round_states[client] = state_copy(self.model)

    def aggregation_weight(self, client, loader):
        return 1

    @torch.no_grad()
    def select_replay(self, client, candidates, capacity):
        if len(candidates) <= capacity:
            self.replay_counts[client] = len(candidates)
            self.selected_views[client] = 0
            return _ReplayExamples(candidates, range(len(candidates)), np.ones(len(candidates)))

        seed = np.random.SeedSequence((self.args.seed, self.task, client))
        rng = np.random.default_rng(seed)
        peers = sorted(set(self.last_round_states) - {client})
        chosen = rng.choice(peers, size=min(len(peers), self.args.clif_peer_views), replace=False).tolist()
        if client in self.last_round_states:
            chosen.insert(0, client)
        scorer = copy.deepcopy(self.model).eval()
        views = [None, *chosen]
        fused = torch.zeros(len(candidates), dtype=torch.float64)
        feature_seed = int(rng.integers(2 ** 32))
        for view in views:
            if view is not None:
                scorer.load_state_dict(self.last_round_states[view])
            # Use the same input augmentation for each model's view of an example.
            with torch.random.fork_rng(devices=[]):
                torch.random.default_generator.manual_seed(feature_seed)
                loader = DataLoader(candidates, batch_size=self.args.batch_size,
                                    num_workers=self.args.num_workers,
                                    generator=torch.Generator().manual_seed(feature_seed))
                features = torch.cat([scorer.forward_features(inputs.to(self.device)).cpu()
                                      for inputs, _ in loader])
            fused = torch.maximum(fused, _lewis_weights(features, self.args.clif_p))

        sampled, frequencies = _sample_exemplars(fused.numpy(), capacity, rng)
        self.replay_counts[client] = len(sampled)
        self.selected_views[client] = len(views)
        return _ReplayExamples(candidates, sampled, frequencies)

    def checkpoint(self):
        return {"replay_counts": self.replay_counts, "selected_views": self.selected_views}
