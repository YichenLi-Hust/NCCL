"""FEAT-F (CVPR 2026), geometric correction with FedCBDR exemplar selection."""

import torch
from torch.nn import functional as F

from .fedcbdr import FedCBDR
from .survey.common import avoid_singleton_batch_norm, optimizer_for


def add_args(parser):
    parser.add_argument("--feat_temperature", type=float, default=0.5,
                        help="Temperature of the pairwise angular distributions")
    parser.add_argument("--feat_alignment_weight", type=float, default=0.1)
    parser.add_argument("--feat_ema_rate", type=float, default=0.9,
                        help="Weight of new replay statistics in the client EMA")
    parser.add_argument("--fedcbdr_rank", type=int, default=32,
                        help="Rank used by the FedCBDR replay selector")


def validate_args(parser, args):
    if args.feat_temperature <= 0 or args.feat_alignment_weight < 0:
        parser.error("FEAT needs positive temperature and nonnegative alignment weight")
    if not 0 < args.feat_ema_rate <= 1 or args.fedcbdr_rank < 1:
        parser.error("FEAT needs an EMA rate in (0, 1] and positive replay rank")


def _angular_loss(features, prototypes, labels, temperature):
    unit_features = F.normalize(features, dim=1)
    targets = prototypes[labels]
    feature_log_probs = F.log_softmax((unit_features @ unit_features.T) / temperature, dim=1)
    target_log_probs = F.log_softmax((targets @ targets.T) / temperature, dim=1)
    rows = (feature_log_probs.exp() * (feature_log_probs - target_log_probs)).sum(1)
    counts = torch.bincount(labels, minlength=len(prototypes))
    return (rows / counts[labels]).sum() / counts.count_nonzero()


class FEAT(FedCBDR):
    """Use FEAT's ETF training and inference with its FedCBDR replay variant."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        dimension = model.fc.in_features
        if dimension < stream.num_classes:
            raise ValueError("FEAT needs a feature dimension at least as large as the number of classes. "
                             "Use resnet18 for CIFAR-100 or TinyImageNet.")
        # Recenter a common orthonormal basis whenever the observed class set grows.
        basis = torch.randn(dimension, stream.num_classes,
                            generator=torch.Generator().manual_seed(args.seed))
        self.basis = torch.linalg.qr(basis, mode="reduced").Q.to(device)
        self.model.fc.requires_grad_(False)
        self.stream.protocol["feat"] = {
            "variant": "FEAT-F",
            "replay": "FedCBDR",
            "temperature": args.feat_temperature,
            "alignment_weight": args.feat_alignment_weight,
            "ema_rate": args.feat_ema_rate,
            "singleton_subspace_divisor": 1,
        }

    @torch.no_grad()
    def begin_task(self, task, old_classes, seen_classes):
        super().begin_task(task, old_classes, seen_classes)
        axes = self.basis[:, self.seen].T
        prototypes = F.normalize(axes - axes.mean(0), dim=1) if len(axes) > 1 else axes
        self.model.fc.weight.zero_()
        self.model.fc.weight[self.seen] = prototypes
        if self.model.fc.bias is not None:
            self.model.fc.bias.zero_()
        self.local_priors = {}
        self.global_prior = None
        self.subspaces = []
        if old_classes:
            for directions in (prototypes[~self.old_classes], prototypes[self.old_classes]):
                orthonormal = torch.linalg.qr(directions.T, mode="reduced").Q
                self.subspaces.append((orthonormal, max(1, len(directions) - 1)))

    def aggregation_weight(self, client, loader):
        return 1

    def begin_round(self, task, round_in_task, selected):
        self.replay_counts = {}

    def _energies(self, features):
        projections = [features @ basis for basis, _ in self.subspaces]
        energies = torch.stack([proj.square().sum(1) / divisor
                                for proj, (_, divisor) in zip(projections, self.subspaces)], dim=1)
        return energies, projections

    def fit_client(self, client, loader, device):
        self.model.train()
        optimizer = optimizer_for((p for p in self.model.parameters() if p.requires_grad), self.args)
        prototypes = self.model.fc.weight[self.seen]
        for _ in range(self.args.epochs):
            for inputs, labels in loader:
                labels = self.label_index[labels.to(device)]
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(labels)):
                    features = self.model.forward_features(inputs.to(device))
                    loss = F.cross_entropy(features @ prototypes.T, labels)
                    if self.subspaces:
                        loss = loss + self.args.feat_alignment_weight * _angular_loss(
                            features, prototypes, labels, self.args.feat_temperature)
                        tail = self.old_classes[labels]
                        if tail.any():
                            normalized = F.normalize(features[tail].detach(), dim=1)
                            energies, _ = self._energies(normalized)
                            observed = energies.mean(0)
                            prior = self.local_priors.get(client, observed)
                            self.local_priors[client] = prior.lerp(observed, self.args.feat_ema_rate)
                            self.replay_counts[client] = self.replay_counts.get(client, 0) + len(energies)
                loss.backward()
                optimizer.step()

    def post_round(self):
        if self.replay_counts:
            total = sum(self.replay_counts.values())
            self.global_prior = sum(self.local_priors[k] * (n / total)
                                    for k, n in self.replay_counts.items())

    def predict(self, inputs):
        features = F.normalize(self.model.forward_features(inputs), dim=1)
        if self.global_prior is not None:
            energies, projections = self._energies(features)
            gate = F.relu(energies[:, 0] - self.global_prior[0]) / (energies.sum(1) + 1e-8)
            head = projections[0] @ self.subspaces[0][0].T
            tail = projections[1] @ self.subspaces[1][0].T
            features = F.normalize(features + gate[:, None] * (tail - head), dim=1)
        return self.model.fc(features)

    def checkpoint(self):
        return {"seen_classes": self.seen.cpu(), "old_classes": self.seen[self.old_classes].cpu(),
                "tail_energy_prior": None if self.global_prior is None else self.global_prior.cpu()}
