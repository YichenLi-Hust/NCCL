"""CAN, ICML 2025. Client-guided synthetic replay on a class-incremental stream."""

import copy
import math

import torch
from torch.nn import functional as F

from .models.cgan import ConditionalGenerator
from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.generative import _GeneratorMethod, _balanced_labels, _freeze


def add_args(parser):
    parser.add_argument("--can_gap", type=float, default=0.67,
                        help="weight of the reference/server disagreement in generator training")
    parser.add_argument("--can_profile_steps", type=int, default=20,
                        help="temporary local updates used to estimate forgetting on synthetic past tasks")


def validate_args(parser, args):
    if not 0 <= args.can_gap <= 1 or args.can_profile_steps < 1:
        parser.error("can_gap must be in [0, 1] and can_profile_steps must be positive")
    if args.survey_gan_width < 2:
        parser.error("CAN requires survey_gan_width >= 2")


def _quotas(weights, capacity):
    shares = weights.double() / weights.sum() * capacity
    whole = shares.floor().long()
    remainder = capacity - int(whole.sum())
    whole[(shares - whole).argsort(descending=True, stable=True)[:remainder]] += 1
    return whole.tolist()


class CAN(_GeneratorMethod):
    """Paper equations 2–9 and 13–14, with the shared benchmark generator."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.archive = []
        self.expert_history, self.allocations = {}, {}
        self.capacity = args.survey_replay_samples
        stream.protocol["can"] = {
            "expert_metric": "per-class training accuracy on each participating client's current shard",
            "expert_candidates": "latest update from each participating client in the task; global fallback for unseen classes",
            "generator": "benchmark conditional CNN; Adam at 0.002; one synthesis pool per completed task",
            "buffer_per_client": self.capacity, "server_pool_per_task": self.capacity,
            "gap_weight": args.can_gap, "profile_steps": args.can_profile_steps,
            "profile_data": "class-balanced synthetic task pools and current local training data",
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.task = task
        self.seen = torch.tensor(seen_classes, dtype=torch.long, device=self.device)
        self.current = torch.tensor(self.stream.task_classes[task], dtype=torch.long, device=self.device)
        if set(old_classes).intersection(self.current.tolist()):
            raise ValueError("CAN expects disjoint classes across tasks")
        self.label_to_seen = torch.full((self.stream.num_classes,), -1, device=self.device, dtype=torch.long)
        self.label_to_seen[self.seen] = torch.arange(len(self.seen), device=self.device)
        self.old = torch.tensor(old_classes, dtype=torch.long, device=self.device)
        self.old_positions = self.label_to_seen[self.old]
        self.uploads, self.buffers = {}, {}
        self.allocations[task] = {}
        self.teacher = _freeze(self.model) if self.archive else None
        if self.teacher is not None:
            current_count = len(self.current)
            kappa = math.log2(1 + current_count / 2)
            delta = math.sqrt(len(self.old) / current_count)
            self.new_weight, self.replay_weight = (1 + 1 / kappa) / delta, kappa * delta

    def _buffer(self, amounts):
        """Use distinct synthetic examples for the exact per-task quotas."""
        parts = []
        for task, count in enumerate(amounts):
            indices = torch.randperm(len(self.archive[task][0]))[:count]
            parts.extend((task, i) for i in indices.tolist())
        return parts

    def _local_step(self, model, optimizer, batch, replay):
        images, labels = (value.to(self.device) for value in batch)
        if replay:
            positions = torch.randint(len(replay), (len(labels),)).tolist()
            selected = [replay[index] for index in positions]
            previous = torch.stack([self.archive[t][0][i] for t, i in selected]).to(self.device)
            with torch.no_grad():
                target = self.teacher(previous)[:, self.old].softmax(1)
            output = model(torch.cat((images, previous)))[:, self.seen]
            new_scores, past_scores = output.split(len(labels))
            kl = F.kl_div(past_scores.log_softmax(1)[:, self.old_positions], target, reduction="batchmean")
            loss = self.new_weight * F.cross_entropy(new_scores, self.label_to_seen[labels]) + self.replay_weight * kl
        else:
            with avoid_singleton_batch_norm(model, len(labels)):
                loss = F.cross_entropy(model(images)[:, self.seen], self.label_to_seen[labels])
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

    def _profile(self, loader):
        temporary = copy.deepcopy(self.model).train()
        optimizer = optimizer_for(temporary.parameters(), self.args)
        balanced = self._buffer(_quotas(torch.ones(len(self.archive)), self.capacity))
        batches = iter(loader)
        for _ in range(self.args.can_profile_steps):
            batch = next(batches, None)
            if batch is None:
                batches = iter(loader)
                batch = next(batches)
            self._local_step(temporary, optimizer, batch, balanced)

        # Evaluate only generated examples. Even a client with capacity below
        # the number of old tasks can still score every server-side pool.
        temporary.eval()
        counts = []
        with torch.no_grad():
            for task, (images, labels) in enumerate(self.archive):
                ids = [i for t, i in balanced if t == task] or [0]
                hits = 0
                for positions in torch.tensor(ids).split(self.args.batch_size):
                    logits = temporary(images[positions].to(self.device))[:, self.seen]
                    hits += int((self.seen[logits.argmax(1)].cpu() == labels[positions]).sum())
                counts.append(1 / max(hits / len(ids), 1e-3))
        return _quotas(torch.tensor(counts), self.capacity)

    def fit_client(self, client, loader, device):
        if self.archive and client not in self.buffers:
            counts = self._profile(loader)
            self.buffers[client] = self._buffer(counts)
            self.allocations[self.task][client] = counts
        replay = self.buffers.get(client, ())
        self.model.train()
        optimizer = optimizer_for(self.model.parameters(), self.args)
        for _ in range(self.args.epochs):
            for batch in loader:
                self._local_step(self.model, optimizer, batch, replay)
        if self.task + 1 < self.stream.num_tasks:
            self._record_expertise(client, loader)

    @torch.no_grad()
    def _record_expertise(self, client, loader):
        self.model.eval()
        totals = torch.zeros(self.stream.num_classes)
        correct = torch.zeros_like(totals)
        for images, labels in loader:
            predicted = self.seen[self.model(images.to(self.device))[:, self.seen].argmax(1)].cpu()
            totals += torch.bincount(labels, minlength=len(totals))
            correct += torch.bincount(labels[labels == predicted], minlength=len(totals))
        accuracy = torch.where(totals > 0, correct / totals.clamp_min(1), -1)
        self.uploads[client] = state_copy(self.model), accuracy

    def finish_task(self, task):
        if task + 1 == self.stream.num_tasks:
            return
        clients = sorted(self.uploads)
        accuracies = torch.stack([self.uploads[c][1] for c in clients])
        best, winners = accuracies.max(0)
        owners = {label: clients[int(winners[label])] if best[label] >= 0 else None
                  for label in self.current.tolist()}
        expert_ids = torch.full((self.stream.num_classes,), -1, dtype=torch.long, device=self.device)
        for label, owner in owners.items():
            if owner is not None:
                expert_ids[label] = owner
        self.expert_history[task] = owners
        server = _freeze(self.model)
        experts = {}
        for owner in set(owners.values()):
            expert = server
            if owner is not None:
                expert = _freeze(self.model)
                expert.load_state_dict(self.uploads[owner][0])
            experts[-1 if owner is None else owner] = expert
        self.uploads.clear()
        generator = ConditionalGenerator(self.stream.num_classes, self.stream.channels,
                                         self.stream.image_size, self.latent_dim, self.args.survey_gan_width).to(self.device)
        reference = copy.deepcopy(server).requires_grad_(True)
        for module in reference.modules():
            if callable(getattr(module, "reset_parameters", None)):
                module.reset_parameters()
        synth_optimizer = torch.optim.Adam(generator.parameters(), lr=0.002)
        ref_optimizer = optimizer_for(reference.parameters(), self.args)
        batch_size = max(2, self.args.batch_size)
        for _ in range(self.args.survey_generator_steps):
            labels = _balanced_labels(self.current, batch_size)
            images = self._normalize(generator(self._noise(batch_size), labels))
            # Route each image only to its winning expert. Index assignment
            # propagates image gradients back to the shared generator.
            expert_logits = images.new_zeros(len(labels), len(self.seen))
            for owner, expert in experts.items():
                mask = expert_ids[labels] == owner
                if mask.any():
                    expert_logits[mask] = expert(images[mask])[:, self.seen]
            target = self.label_to_seen[labels]
            reference.eval()
            ref_logits = reference(images)[:, self.seen]
            ref_prob = ref_logits.softmax(1)
            gap = F.kl_div(server(images)[:, self.seen].log_softmax(1), ref_prob, reduction="none").sum(1)
            navigation = F.cross_entropy(expert_logits, target)
            correct_gap = (gap * (ref_logits.argmax(1) == target)).mean()
            loss = (1 - self.args.can_gap) * navigation - self.args.can_gap * correct_gap
            synth_optimizer.zero_grad(set_to_none=True)
            loss.backward(inputs=tuple(generator.parameters()))
            synth_optimizer.step()
            reference.train()
            ref_optimizer.zero_grad(set_to_none=True)
            ref_out = reference(images.detach())[:, self.seen]
            F.kl_div(ref_out.log_softmax(1), expert_logits.detach().softmax(1), reduction="batchmean").backward()
            ref_optimizer.step()

        generator.eval()
        labels = _balanced_labels(self.current, self.capacity)
        with torch.no_grad():
            images = [self._normalize(generator(self._noise(len(batch)), batch)).cpu()
                      for batch in labels.split(batch_size)]
        self.archive.append((torch.cat(images), labels.cpu()))

    def checkpoint(self):
        return {"synthetic_task_pools": self.archive, "expert_owners": self.expert_history,
                "replay_counts_per_client_task": self.allocations}
