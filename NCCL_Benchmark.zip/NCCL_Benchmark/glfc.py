"""GLFC local learning and a feature-prototype proxy for the Survey streams."""

from copy import deepcopy

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset

from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--glfc_distillation_weight", type=float, default=0.5)
    parser.add_argument("--glfc_proxy_samples_per_client", type=int, default=128,
                        help="Maximum current-task images contributing to each client's feature statistics")


class _ReplayOrigin(Dataset):
    def __init__(self, dataset, is_replay):
        self.dataset = dataset
        self.is_replay = is_replay

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        inputs, labels = self.dataset[index]
        return inputs, labels, self.is_replay


def _herd(features, count):
    mean = features.mean(dim=0)
    running_sum = torch.zeros_like(mean)
    available = torch.ones(len(features), dtype=torch.bool)
    selected = []
    for size in range(1, count + 1):
        error = (features - (size * mean - running_sum)).square().sum(dim=1)
        index = error.masked_fill(~available, float("inf")).argmin().item()
        selected.append(index)
        running_sum += features[index]
        available[index] = False
    return selected


class GLFCStrategy(LocalStrategy):
    """Gradient compensation and class-semantic distillation with local herding."""

    uses_local_replay = True

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.distillation_weight = args.glfc_distillation_weight
        self.proxy_budget = args.glfc_proxy_samples_per_client
        if not 0 <= self.distillation_weight <= 1:
            raise ValueError("glfc_distillation_weight must be in [0, 1]")
        if self.proxy_budget < 2:
            raise ValueError("glfc_proxy_samples_per_client must be at least 2")
        self.proxy_teacher_state = None
        self.teacher = None
        stream.protocol["glfc"] = {
            "teacher_selection": "Aggregated class-feature means from current-task clients",
            "proxy_samples_per_client": self.proxy_budget,
            "distillation_weight": self.distillation_weight,
            "replay_selection": "Class-balanced feature herding",
            "task_arrival": "Common Survey task boundaries",
        }

    def begin_task(self, task, old_classes, seen_classes):
        self.task = task
        self.seen_classes = torch.as_tensor(seen_classes, dtype=torch.long, device=self.device)
        self.old_class_mask = torch.isin(self.seen_classes, torch.as_tensor(old_classes, dtype=torch.long,
                                                                          device=self.device))
        self.teacher = None
        if old_classes:
            self.teacher = deepcopy(self.model).to(self.device).eval().requires_grad_(False)
            if self.proxy_teacher_state is not None:
                self.teacher.load_state_dict(self.proxy_teacher_state)
        self.proxy_encoder = deepcopy(self.model).to(self.device).eval().requires_grad_(False)
        self.proxy_sums = torch.zeros(self.stream.num_classes, self.model.fc.in_features)
        self.proxy_counts = torch.zeros(self.stream.num_classes, dtype=torch.long)
        self.proxy_clients = set()
        self.best_score = float("-inf")
        self.best_state = None

    def build_client_data(self, client, current, replay):
        marked = _ReplayOrigin(current, False)
        if replay is None or not len(replay):
            return marked
        return ConcatDataset([marked, _ReplayOrigin(replay, True)])

    @torch.no_grad()
    def _update_proxy(self, client):
        if client in self.proxy_clients:
            return
        self.proxy_clients.add(client)
        current = self.stream.train[self.task][client]
        rng = np.random.default_rng(np.random.SeedSequence([self.args.seed, self.task, client, 2171]))
        count = min(self.proxy_budget, len(current))
        subset = Subset(current, rng.choice(len(current), count, replace=False).tolist())
        batches = DataLoader(subset, batch_size=self.args.batch_size, num_workers=self.args.num_workers)
        for inputs, labels in batches:
            features = self.proxy_encoder.forward_features(inputs.to(self.device)).cpu()
            self.proxy_sums.index_add_(0, labels, features)
            self.proxy_counts.index_add_(0, labels, torch.ones_like(labels))

    def fit_client(self, client, loader, device):
        self._update_proxy(client)
        optimizer = optimizer_for(self.model.parameters(), self.args)
        self.model.to(device).train()
        seen, old = self.seen_classes.to(device), self.old_class_mask.to(device)
        for _ in range(self.args.epochs):
            for inputs, labels, is_replay in loader:
                inputs, labels, is_replay = inputs.to(device), labels.to(device), is_replay.to(device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(inputs)):
                    logits = self.model(inputs).index_select(1, seen)
                targets = (labels[:, None] == seen).to(logits.dtype)
                gradient = ((1 - logits.detach().sigmoid()) * targets).sum(dim=1)
                weights = torch.ones_like(gradient)
                if self.task:
                    for group in (is_replay, ~is_replay):
                        if group.any():
                            values = gradient[group]
                            weights[group] = values / values.mean().clamp_min(1e-8)
                loss = (F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
                        * weights[:, None]).mean()
                if self.teacher is not None:
                    with torch.no_grad():
                        soft_targets = self.teacher(inputs.to(self.device)).to(device).index_select(1, seen).sigmoid()
                    distillation_targets = torch.where(old, soft_targets, targets)
                    soft_loss = F.binary_cross_entropy_with_logits(logits, distillation_targets)
                    loss = torch.lerp(loss, soft_loss, self.distillation_weight)
                loss.backward()
                optimizer.step()

    @torch.no_grad()
    def post_round(self):
        classes = self.proxy_counts.ge(2).nonzero(as_tuple=True)[0]
        if not len(classes):
            return
        features = self.proxy_sums[classes] / self.proxy_counts[classes, None]
        logits = self.model.fc(features.to(self.device)).index_select(1, self.seen_classes).cpu()
        targets = (classes[:, None] == self.seen_classes.cpu()).long().argmax(dim=1)
        score = -F.cross_entropy(logits, targets).item()
        if score >= self.best_score:
            self.best_score = score
            self.best_state = state_copy(self.model)

    def finish_task(self, task):
        self.proxy_teacher_state = self.best_state if self.best_state is not None else state_copy(self.model)
        self.proxy_encoder = None

    @torch.no_grad()
    def select_replay(self, client, candidates, capacity):
        if len(candidates) <= capacity or capacity == 0:
            return Subset(candidates, range(min(capacity, len(candidates))))
        self.model.to(self.device).eval()
        features, labels = [], []
        batches = DataLoader(candidates, batch_size=self.args.batch_size, num_workers=self.args.num_workers)
        for inputs, targets in batches:
            features.append(F.normalize(self.model.forward_features(inputs.to(self.device)), dim=1).cpu())
            labels.append(targets)
        features, labels = torch.cat(features), torch.cat(labels)
        classes = {label.item(): (labels == label).nonzero(as_tuple=True)[0] for label in labels.unique()}
        per_class = {label: 0 for label in classes}
        remaining = capacity
        while remaining:
            for label, indices in classes.items():
                if per_class[label] < len(indices):
                    per_class[label] += 1
                    remaining -= 1
                    if not remaining:
                        break

        selected = []
        for label, indices in classes.items():
            priorities = _herd(features[indices], per_class[label])
            selected.extend(indices[priorities].tolist())
        return Subset(candidates, selected)

    def checkpoint(self):
        return {"proxy_teacher": self.proxy_teacher_state}
