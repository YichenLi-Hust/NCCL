"""CFeD on the Survey's image streams and shared classifier."""

from copy import deepcopy
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset, Subset

from .survey.common import avoid_singleton_batch_norm, optimizer_for
from .survey.strategies import LocalStrategy


_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp", ".ppm"}


def add_args(parser):
    parser.add_argument("--cfed_surrogate_dir",
                        help="Separate, public surrogate image directory; labels are ignored")
    parser.add_argument("--cfed_temperature", type=float, default=2.0)
    parser.add_argument("--cfed_client_weight", type=float, default=0.1,
                        help="Multiplier for the local preservation loss")
    parser.add_argument("--cfed_preservation_fraction", type=float, default=0.4,
                        help="Fraction of selected clients assigned to knowledge preservation")
    parser.add_argument("--cfed_server_steps", type=int, default=None,
                        help="Server distillation batches per round (default: 0, or 1 in smoke runs)")


class PublicSurrogateImages(Dataset):
    def __init__(self, root, stream):
        from torchvision import transforms

        self.paths = sorted(path for path in root.rglob("*")
                            if path.is_file() and path.suffix.lower() in _IMAGE_SUFFIXES
                            and not any(part.startswith(".") for part in path.relative_to(root).parts))
        self.transform = transforms.Compose([
            transforms.Resize((stream.image_size, stream.image_size)),
            transforms.ToTensor(), transforms.Normalize(stream.mean, stream.std),
        ])

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index):
        from PIL import Image

        with Image.open(self.paths[index]) as image:
            return self.transform(image.convert("RGB"))


def _distill(student, teacher, temperature):
    targets = F.softmax(teacher / temperature, dim=1)
    return -(targets * F.log_softmax(student / temperature, dim=1)).sum(dim=1).mean()


class CFeDStrategy(LocalStrategy):
    """Separate private learning and public preservation clients in each round."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.temperature = args.cfed_temperature
        self.loss_weight = args.cfed_client_weight
        self.preservation_fraction = args.cfed_preservation_fraction
        self.server_steps = args.cfed_server_steps
        if self.server_steps is None:
            self.server_steps = int(args.smoke)
        if not np.isfinite(self.temperature) or self.temperature <= 0:
            raise ValueError("cfed_temperature must be finite and positive")
        if not np.isfinite(self.loss_weight) or self.loss_weight <= 0:
            raise ValueError("cfed_client_weight must be finite and positive")
        if not 0 <= self.preservation_fraction < 1:
            raise ValueError("cfed_preservation_fraction must be in [0, 1)")
        if self.server_steps < 0:
            raise ValueError("cfed_server_steps must be nonnegative")

        self.surrogate = None
        self.server_indices = []
        self.preservation_indices = []
        if self.server_steps or (stream.num_tasks > 1 and self.preservation_fraction):
            self._load_surrogates()
        self.teacher = None
        self.preservation_clients = set()
        self.server_batches = []
        self.round_in_task = 0

        source = "unused"
        if self.surrogate is not None:
            source = str(args.cfed_surrogate_dir) if args.cfed_surrogate_dir else "synthetic"
        stream.protocol["cfed"] = {
            "preservation_fraction": self.preservation_fraction,
            "temperature": self.temperature,
            "local_distillation_weight": self.loss_weight,
            "server_steps_per_round": self.server_steps,
            "surrogate_source": source,
            "surrogate_samples": len(self.surrogate) if self.surrogate is not None else 0,
            "server_surrogate_samples": len(self.server_indices),
        }

    def _load_surrogates(self):
        args, stream = self.args, self.stream
        if args.cfed_surrogate_dir is not None:
            root = Path(args.cfed_surrogate_dir)
            if not root.is_dir():
                raise FileNotFoundError(f"CFeD surrogate directory not found: {root}")
            self.surrogate = PublicSurrogateImages(root, stream)
        elif args.dataset == "synthetic":
            rng = torch.Generator().manual_seed(args.seed + 15673)
            self.surrogate = torch.rand(64, stream.channels, stream.image_size, stream.image_size,
                                        generator=rng)
        else:
            raise ValueError("CFeD requires --cfed_surrogate_dir with public images separate from all benchmark splits")

        needs_local = bool(stream.num_tasks > 1 and self.preservation_fraction)
        if len(self.surrogate) < 1 + int(self.server_steps > 0 and needs_local):
            raise ValueError("CFeD requires images for each enabled surrogate split")
        indices = np.random.default_rng(np.random.SeedSequence([args.seed, 4581])).permutation(len(self.surrogate))
        if self.server_steps:
            count = max(1, len(indices) // args.client_num_in_total) if needs_local else len(indices)
            self.server_indices = indices[:count].tolist()
            indices = indices[count:]
        self.preservation_indices = [shard.tolist() for shard in np.array_split(indices, args.client_num_in_total)]

    def begin_task(self, task, old_classes, seen_classes):
        super().begin_task(task, old_classes, seen_classes)
        self.round_in_task = 0
        self.server_rng = np.random.default_rng(np.random.SeedSequence([self.args.seed, task, 4733]))
        if task and self.preservation_fraction:
            self.teacher = deepcopy(self.model).to(self.device).eval().requires_grad_(False)

    def sample_clients(self, eligible, count, rng):
        clients = super().sample_clients(eligible, count, rng)
        self.round_in_task += 1
        count = len(clients)
        preservation = 0
        if self.teacher is not None and count > 1:
            preservation = min(count - 1, max(1, int(count * self.preservation_fraction + 0.5)))
        elif self.teacher is not None and count == 1:
            fraction = self.preservation_fraction
            preservation = int(self.round_in_task * fraction) - int((self.round_in_task - 1) * fraction)
        self.preservation_clients = set(clients[count - preservation:])

        if self.server_steps and count:
            self.server_teacher_order = {client: index for index, client in enumerate(clients, start=1)}
            selected = self.server_rng.permutation(self.server_indices)
            indices = selected[:self.server_steps * self.args.batch_size].tolist()
            self.server_batches = list(DataLoader(Subset(self.surrogate, indices), batch_size=self.args.batch_size))
            self.server_teacher_logits = [None] * len(self.server_batches)
        return clients

    def aggregation_weight(self, client, loader):
        return 1

    def fit_client(self, client, loader, device):
        if self.server_batches and self.server_teacher_order[client] == 1:
            self._record_server_teacher(0)
        if client in self.preservation_clients:
            self._fit_preservation_client(client, device)
        else:
            self.model.to(device)
            super().fit_client(client, loader, device)
        if self.server_batches:
            self._record_server_teacher(self.server_teacher_order[client])

    def _fit_preservation_client(self, client, device):
        active_shards = [index for index, shard in enumerate(self.preservation_indices) if shard]
        shard = self.preservation_indices[client]
        if not shard:
            shard = self.preservation_indices[active_shards[client % len(active_shards)]]
        batches = DataLoader(Subset(self.surrogate, shard), batch_size=self.args.batch_size,
                             num_workers=self.args.num_workers, shuffle=False)
        optimizer = optimizer_for(self.model.parameters(), self.args)
        self.model.to(device).train()
        self.teacher.to(device)
        for _ in range(self.args.epochs):
            for images in batches:
                images = images.to(device)
                with torch.no_grad():
                    teacher_logits = self.teacher(images)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(images)):
                    loss = self.loss_weight * _distill(self.model(images), teacher_logits, self.temperature)
                loss.backward()
                optimizer.step()

    @torch.no_grad()
    def _record_server_teacher(self, teacher):
        self.model.to(self.device).eval()
        teacher_count = len(self.server_teacher_order) + 1
        offset = 0
        for index, images in enumerate(self.server_batches):
            assigned = (torch.arange(len(images)) + offset) % teacher_count == teacher
            if assigned.any():
                logits = self.model(images[assigned].to(self.device)).cpu()
                if self.server_teacher_logits[index] is None:
                    self.server_teacher_logits[index] = logits.new_zeros((len(images), logits.shape[1]))
                self.server_teacher_logits[index][assigned] = logits
            offset += len(images)

    def post_round(self):
        if self.server_batches:
            self.model.to(self.device).train()
            optimizer = optimizer_for(self.model.parameters(), self.args)
            for images, teacher_logits in zip(self.server_batches, self.server_teacher_logits):
                if teacher_logits is None:
                    raise RuntimeError("CFeD server distillation did not receive teacher logits")
                images, teacher_logits = images.to(self.device), teacher_logits.to(self.device)
                optimizer.zero_grad(set_to_none=True)
                with avoid_singleton_batch_norm(self.model, len(images)):
                    loss = self.loss_weight * _distill(self.model(images), teacher_logits, self.temperature)
                loss.backward()
                optimizer.step()
        self.server_batches = []
