"""Dataset-specific experiment settings for the supported protocols."""


# Survey, Section VII, Table XI, in the order used in the paper.
# Batch size, top-k, LR, Dirichlet alpha, clients, local epochs, clients per
# round, rounds per task, tasks. The integer client counts implement the paper ratios.
SURVEY = {
    "cifar10": (64, 1, 0.01, 0.1, 20, 20, 8, 80, 5),
    "cifar100": (64, 1, 0.01, 1.0, 20, 20, 10, 100, 10),
    "tinyimagenet": (128, 10, 0.001, 10.0, 20, 20, 12, 100, 10),
    "digit10": (64, 1, 0.001, 0.1, 15, 20, 6, 60, 4),
    "office31": (32, 1, 0.01, 1.0, 10, 20, 4, 60, 3),
    "officecaltech10": (32, 1, 0.01, 1.0, 8, 15, 4, 40, 4),
}

SURVEY_KEYS = (
    "batch_size", "top_k", "lr", "alpha", "client_num_in_total", "epochs",
    "client_num_per_round", "comm_round", "num_tasks",
)


def reference_settings(method, dataset):
    if method.id == "dcu" and dataset == "cifar100":
        return dict(num_tasks=10, dcu_task_limit=3, dcu_forget_after="2:0,3:20",
                    model="resnet18", client_num_in_total=5, alpha=0.5, comm_round=50, epochs=5,
                    lr=0.01, dcu_proto_rounds=10, dcu_proto_steps=50, dcu_diffusion_batch=12,
                    dcu_unlearn_steps=50, dcu_samples=100, dcu_beta_cl=10, dcu_beta_ul=0.2)
    if method.id == "bpfedctta" and dataset in ("cifar10c", "cifar100c"):
        return dict(severity=5, adapt_fraction=0.5, target_clients_per_domain=1)
    if method.id == "pfedmxf" and dataset == "cifar100":
        return dict(num_tasks=10, client_num_in_total=10, client_num_per_round=10,
                    comm_round=5, batch_size=64, client_optimizer="adam", lr=0.001,
                    pfedmxf_adapter_lr=0.00001, pfedmxf_frequencies=3000)
    if method.id == "spr-fil" and dataset in ("cifar10", "cifar100", "tinyimagenet"):
        settings = dict(zip(SURVEY_KEYS, SURVEY[dataset]))
        settings.update(model="resnet18", client_num_in_total=20, client_num_per_round=12,
                        epochs=20, comm_round=150, alpha=1.0, top_k=5 if dataset == "tinyimagenet" else 1)
        return settings
    if method.id == "feat" and dataset == "cifar100":
        return dict(model="resnet18", client_optimizer="sgd", lr=0.04, wd=0.00001,
                    client_num_in_total=5, client_num_per_round=5, epochs=2, batch_size=128,
                    comm_round=100, num_tasks=5, alpha=0.5, eval_every=1)
    if method.id == "uopp" and dataset == "cifar100":
        return dict(num_tasks=9, client_num_in_total=20, client_num_per_round=6,
                    comm_round=10, epochs=2, uopp_ode_steps=40, uopp_shots=5)
    if method.id == "special" and dataset == "digit10":
        return dict(model="resnet18", client_optimizer="sgd", epochs=5, comm_round=20,
                    client_num_in_total=8, client_num_per_round=4, num_tasks=4,
                    batch_size=32, lr=0.001, wd=0, alpha=0.1, eval_every=1,
                    special_lambda=0.25, special_lr_decay=0.96,
                    survey_domain_order="USPS,SVHN,EMNIST,MNIST")
    if method.protocol == "survey" and dataset in SURVEY:
        settings = dict(zip(SURVEY_KEYS, SURVEY[dataset]))
        settings.update(model="resnet18", memory_size=300, eval_every=1)
        if method.id == "cfed":
            settings["cfed_server_steps"] = 1
        if method.id == "fedssi" and dataset == "cifar10":
            settings["fedssi_lambda"] = 0.2
        return settings
    if method.id == "c2afcl" and dataset in ("cifar100", "tinyimagenet", "office31", "officecaltech10"):
        return dict(model="resnet18", client_optimizer="adam", epochs=20, comm_round=100,
                    client_num_in_total=20, client_num_per_round=8, alpha=1.0,
                    availability=0.8, max_staleness=25, memory_size=300, eval_every=1,
                    num_tasks={"office31": 3, "officecaltech10": 4}.get(dataset, 10))
    if method.id == "rc-fcl" and dataset in ("cifar10", "cifar100", "tinyimagenet", "digit10"):
        return dict(model="resnet18", client_optimizer="adam", epochs=20, comm_round=100,
                    client_num_in_total=20, client_num_per_round=8, alpha=0.5,
                    batch_size=32, lr=0.001, rc_gan_lr=0.001, rc_tau=0.4, rc_epsilon=0.05,
                    eval_every=1, num_tasks=5 if dataset in ("cifar10", "digit10") else 10)
    raise ValueError(f"no reference configuration for {method.id} on {dataset}")
