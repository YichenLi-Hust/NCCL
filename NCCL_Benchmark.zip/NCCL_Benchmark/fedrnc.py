"""FedRNC (AAAI 2026) on the NCCL class-incremental image stream."""

from collections import defaultdict
from copy import copy
from dataclasses import dataclass

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset

from .data import _labels
from .survey.common import state_copy
from .survey.strategies import LocalStrategy, supervised_update
from .survey_runner import _WeightedStates


def add_args(parser):
    parser.set_defaults(class_noise_rate=0.2)
    parser.add_argument("--fedrnc_warmup_epochs", type=int, default=1,
                        help="Local epochs for each of the two denoising warm-up steps")


def validate_args(parser, args):
    if args.fedrnc_warmup_epochs < 1:
        parser.error("--fedrnc_warmup_epochs must be positive")


@dataclass
class _Example:
    task: int
    index: int
    label: int
    clean: bool = True


class _LabeledView(Dataset):
    def __init__(self, shards, examples):
        self.shards = shards
        self.examples = examples

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, index):
        example = self.examples[index]
        image, _ = self.shards[example.task][example.index]
        return image, example.label


def _low_loss_component(losses):
    """Two-component univariate Gaussian mixture, with the lower-mean component clean."""
    values = np.asarray(losses, dtype=np.float64)
    if len(values) < 2 or np.ptp(values) < 1e-8:
        return np.ones(len(values), dtype=bool)
    values = (values - values.min()) / np.ptp(values)
    means = np.quantile(values, [0.25, 0.75])
    if means[0] == means[1]:
        means = np.array([0., 1.])
    variances = np.full(2, max(values.var(), 1e-4))
    weights = np.full(2, 0.5)
    for _ in range(60):
        scores = (np.log(weights) - 0.5 * np.log(variances)
                  - 0.5 * (values[:, None] - means) ** 2 / variances)
        probs = np.exp(scores - scores.max(axis=1, keepdims=True))
        probs /= probs.sum(axis=1, keepdims=True)
        counts = probs.sum(axis=0).clip(1e-10)
        updated = (values @ probs) / counts
        variances = (((values[:, None] - updated) ** 2 * probs).sum(0) / counts).clip(1e-5)
        weights = counts / counts.sum()
        delta = np.abs(updated - means).max()
        means = updated
        if delta < 1e-6:
            break
    clean = probs[:, np.argmin(means)] >= 0.5
    clean[values.argmin()] = True
    return clean


def _correct(examples, features, prototypes, visible_by_task):
    """Match each source task and cleanliness group independently (paper Eqs. 6–9)."""
    if not examples or not prototypes:
        return 0
    labels = sorted(prototypes)
    distances = torch.cdist(features, torch.stack([prototypes[label] for label in labels]))
    nearest = distances.argmin(1).numpy()
    groups = defaultdict(lambda: defaultdict(list))
    for i, item in enumerate(examples):
        groups[(item.task, item.clean)][item.label].append(i)
    changes = 0
    for (source_task, _), by_class in groups.items():
        observed = visible_by_task[source_task]
        counts = np.array([np.bincount(nearest[rows], minlength=len(labels))
                           for rows in by_class.values()])
        frequencies = counts / counts.sum(axis=1, keepdims=True)
        positive = (frequencies > 0).all(axis=0)
        similarity = np.zeros(len(labels))
        similarity[positive] = np.exp(np.log(frequencies[:, positive]).mean(axis=0))
        # Eq. 9 leaves |Z_a| unspecified for a class absent locally. Use the
        # number of features nearest its prototype in this task/buffer group.
        quotas = np.floor(similarity * counts.sum(axis=0) + 1e-10).astype(int)
        for rows in by_class.values():
            assigned = set()
            for col in np.argsort(-similarity, kind="stable"):
                label, quota = labels[col], int(quotas[col])
                if not quota or label in observed:
                    continue
                ranked = distances[rows, col].argsort()[:quota].tolist()
                for position in ranked:
                    i = rows[position]
                    if i not in assigned:
                        changes += int(examples[i].label != label or not examples[i].clean)
                        examples[i].label = label
                        examples[i].clean = True
                        assigned.add(i)
    return changes


def _balanced_buffer(examples, capacity, rng):
    if len(examples) <= capacity:
        return list(examples)
    by_class = defaultdict(list)
    for i in rng.permutation(len(examples)):
        item = examples[i]
        by_class[item.label].append(item)
    # Randomize both within a class and the order of ties at the quota boundary.
    groups = list(by_class.values())
    kept = []
    while groups and len(kept) < capacity:
        retained_groups = []
        for group in groups:
            kept.append(group.pop())
            if len(kept) == capacity:
                return kept
            if group:
                retained_groups.append(group)
        groups = retained_groups
    return kept


class FedRNC(LocalStrategy):
    """Local loss filtering, shared prototype building and retrospective relabeling."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        if stream.protocol["scenario"] != "class-il":
            raise ValueError("FedRNC requires a class-incremental stream")
        clients = args.client_num_in_total
        self.memory = [[] for _ in range(clients)]
        self.visible = [dict() for _ in range(clients)]
        self.shards = [[] for _ in range(clients)]
        self.audit = []
        stream.protocol["fedrnc"] = {
            "local_warmup_epochs_per_phase": args.fedrnc_warmup_epochs,
            "calibration_participation": "all clients with observed examples at each task boundary",
            "noise": "Fixed target per local shard, hidden classes sampled from present classes, clean test labels",
            "memory_capacity_per_client": args.memory_size,
            "tasks": self.audit,
        }

    def _loader(self, client, examples, shuffle=False):
        return DataLoader(_LabeledView(self.shards[client], examples), self.args.batch_size,
                          shuffle=shuffle, num_workers=self.args.num_workers)

    def _warm(self, client, examples):
        settings = copy(self.args)
        settings.epochs = self.args.fedrnc_warmup_epochs
        supervised_update(self.model, self._loader(client, examples, shuffle=True),
                          self.device, settings)

    @torch.no_grad()
    def _filter(self, client, examples):
        self.model.eval()
        losses = []
        for images, labels in self._loader(client, examples):
            losses.extend(F.cross_entropy(self.model(images.to(self.device)), labels.to(self.device),
                                          reduction="none").cpu().tolist())
        for item, clean in zip(examples, _low_loss_component(losses)):
            item.clean = bool(clean)

    @torch.no_grad()
    def _encode(self, client, examples):
        self.model.eval()
        visible = sorted(set().union(*self.visible[client].values()))
        class_ids = torch.tensor(visible, device=self.device)
        features, predictions = [], []
        for images, _ in self._loader(client, examples):
            codes = self.model.forward_features(images.to(self.device))
            scores = self.model.fc(codes).index_select(1, class_ids)
            predictions.append(class_ids[scores.argmax(1)].cpu())
            features.append(codes.cpu())
        return torch.cat(features), torch.cat(predictions)

    def begin_task(self, task, old_classes, seen_classes):
        start = state_copy(self.model)
        warm_models = _WeightedStates()
        self.current = []
        for client, shard in enumerate(self.stream.train[task]):
            self.shards[client].append(shard)
            fresh = [_Example(task, i, int(label)) for i, label in enumerate(_labels(shard))]
            self.visible[client][task] = {item.label for item in fresh}
            if fresh:
                self.model.load_state_dict(start)
                self._warm(client, fresh)
                self._filter(client, fresh)
            combined = fresh + self.memory[client]
            self.current.append(combined)
            clean = [item for item in combined if item.clean]
            if clean:
                self.model.load_state_dict(start)
                self._warm(client, clean)
                warm_models.add(self.model.state_dict(), len(clean))
        self.model.load_state_dict(warm_models.average() if warm_models.weight else start)

        by_class = defaultdict(list)
        for client, examples in enumerate(self.current):
            clean = [item for item in examples if item.clean]
            if clean:
                features, assigned = self._encode(client, clean)
                for label in assigned.unique().tolist():
                    by_class[label].append(features[assigned == label].mean(0))
        prototypes = {label: torch.stack(local).mean(0) for label, local in by_class.items()}
        changes = []
        for client, examples in enumerate(self.current):
            if examples:
                features, _ = self._encode(client, examples)
                changes.append(_correct(examples, features, prototypes, self.visible[client]))
            else:
                changes.append(0)
        self.audit.append({"task": task + 1, "prototype_classes": sorted(prototypes),
                           "corrections": changes})

    def build_client_data(self, client, current, replay):
        return _LabeledView(self.shards[client], [item for item in self.current[client] if item.clean])

    def finish_task(self, task):
        self.memory = [_balanced_buffer(examples, self.args.memory_size,
                                       np.random.default_rng([self.args.seed, task, client, 827]))
                       for client, examples in enumerate(self.current)]
        self.audit[-1]["cached"] = [len(items) for items in self.memory]
        self.current = []

    def checkpoint(self):
        return {"buffers": [[vars(item) for item in memory] for memory in self.memory],
                "visible_labels": [{task: sorted(labels) for task, labels in mapping.items()}
                                   for mapping in self.visible]}
