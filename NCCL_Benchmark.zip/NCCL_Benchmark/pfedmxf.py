"""pFedMxF (CVPR 2025): disjoint Fourier PEFT and task-agnostic routing."""

import math

import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models.vision_transformer import VisionTransformer, vit_b_16

from .survey.strategies import LocalStrategy


DINO_URL = "https://dl.fbaipublicfiles.com/dino/dino_vitbase16_pretrain/dino_vitbase16_pretrain.pth"


def add_args(parser):
    parser.add_argument("--pfedmxf_weights", help="DINO ViT-B/16 backbone-only PyTorch checkpoint")
    parser.add_argument("--pfedmxf_frequencies", help="Frequency count or comma-separated counts per client")
    parser.add_argument("--pfedmxf_adapter_lr", type=float, default=1e-5)


def validate_args(parser, args):
    if args.pfedmxf_adapter_lr <= 0:
        parser.error("--pfedmxf_adapter_lr must be positive")
    if args.pfedmxf_frequencies is not None:
        try:
            counts = [int(n) for n in args.pfedmxf_frequencies.split(",")]
        except ValueError:
            parser.error("--pfedmxf_frequencies requires integer counts")
        if len(counts) not in (1, args.client_num_in_total) or min(counts) < 1:
            parser.error("Supply one positive frequency count or one count per client")


def _dino_keys(state):
    """Translate the published backbone-only DINO tensor names to torchvision."""
    translated = {}
    for name, tensor in state.items():
        if name in ("cls_token", "pos_embed"):
            name = {"cls_token": "class_token", "pos_embed": "encoder.pos_embedding"}[name]
        elif name.startswith("blocks."):
            _, index, part = name.split(".", 2)
            for old, new in (("norm1.", "ln_1."), ("norm2.", "ln_2."),
                             ("attn.qkv.", "self_attention.in_proj_"),
                             ("attn.proj.", "self_attention.out_proj."),
                             ("mlp.fc1.", "mlp.0."), ("mlp.fc2.", "mlp.3.")):
                if part.startswith(old):
                    part = new + part[len(old):]
                    break
            name = f"encoder.layers.encoder_layer_{index}.{part}"
        elif name.startswith("patch_embed.proj."):
            name = "conv_proj." + name[len("patch_embed.proj."):]
        elif name.startswith("norm."):
            name = "encoder.ln." + name[len("norm."):]
        translated[name] = tensor
    return translated


def _real_update(coefficients, indices, width):
    """Synthesize orthonormal real Fourier modes with Hermitian symmetry.

    The lower index in a conjugate pair selects its cosine and the upper its
    sine. Disjoint client/task coordinates remain orthogonal in real weights.
    """
    rows = torch.div(indices, width, rounding_mode="floor")
    cols = indices.remainder(width)
    mirrors = (-rows).remainder(width) * width + (-cols).remainder(width)
    first, second = torch.minimum(indices, mirrors), torch.maximum(indices, mirrors)
    unit = torch.ones_like(indices, dtype=torch.complex64)
    phase = torch.where(indices <= mirrors, unit, -1j * unit) / math.sqrt(2)
    phase = torch.where(indices == mirrors, unit * 0.5, phase)
    values = coefficients * phase
    spectrum = values.new_zeros(*coefficients.shape[:-1], width * width)
    spectrum.index_add_(-1, first, values)
    spectrum.index_add_(-1, second, values.conj())
    return torch.fft.ifft2(spectrum.unflatten(-1, (width, width)), norm="ortho").real


class PFedMxF(LocalStrategy):
    """Keep the immutable backbone and sparse client transfers out of head averaging."""

    @staticmethod
    def build_model(args, stream):
        if stream.protocol["scenario"] != "class-il":
            raise ValueError("pFedMxF requires disjoint class-incremental tasks")
        tiny = args.dataset == "synthetic"
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(args.seed)
            if tiny:
                encoder = VisionTransformer(image_size=32, patch_size=8, num_layers=1,
                                            num_heads=4, hidden_dim=32, mlp_dim=64)
            else:
                if not args.pfedmxf_weights and not args.download:
                    raise ValueError("Supply --pfedmxf_weights PATH to the DINO ViT-B/16 backbone-only "
                                     "checkpoint, or use --download for the official weights")
                encoder = vit_b_16(weights=None)
                weights = (torch.load(args.pfedmxf_weights, map_location="cpu", weights_only=True)
                           if args.pfedmxf_weights else torch.hub.load_state_dict_from_url(
                               DINO_URL, map_location="cpu", weights_only=True))
                encoder.heads = nn.Identity()
                encoder.load_state_dict(_dino_keys(weights), strict=True)
        encoder.heads = nn.Identity()
        args.model = "vit_smoke" if tiny else "dino_vit_b_16"
        return encoder.eval().requires_grad_(False)

    def __init__(self, model, args, stream, device):
        tiny = args.dataset == "synthetic"
        self.encoder = model
        self.width = self.encoder.hidden_dim
        super().__init__(nn.Linear(self.width, stream.num_classes).to(device), args, stream, device)
        self.projections = {name + ".in_proj_weight": attention.in_proj_weight
                            for name, attention in self.encoder.named_modules()
                            if isinstance(attention, nn.MultiheadAttention)}
        counts = ([int(x) for x in args.pfedmxf_frequencies.split(",")] if args.pfedmxf_frequencies
                  else [min(16 if tiny else 3000, self.width ** 2 // (stream.num_tasks * args.client_num_in_total))])
        if len(counts) == 1:
            counts *= args.client_num_in_total
        if min(counts) < 1 or sum(counts) * stream.num_tasks > self.width ** 2:
            raise ValueError("The requested client/task frequencies exceed the distinct modes in a Q/K matrix")
        self.offsets = [0]
        for count in counts:
            self.offsets.append(self.offsets[-1] + count)
        generator = torch.Generator().manual_seed(args.seed)
        self.permutation = torch.randperm(self.width ** 2, generator=generator)
        self.coefficients = {}
        self.task_ids = []
        self.image_scale = torch.tensor(stream.std, device=device).view(1, 3, 1, 1)
        self.image_offset = torch.tensor(stream.mean, device=device).view(1, 3, 1, 1)
        imagenet_mean = torch.tensor((0.485, 0.456, 0.406), device=device).view(1, 3, 1, 1)
        imagenet_std = torch.tensor((0.229, 0.224, 0.225), device=device).view(1, 3, 1, 1)
        self.image_scale = self.image_scale / imagenet_std
        self.image_offset = (self.image_offset - imagenet_mean) / imagenet_std
        stream.protocol["pfedmxf"] = {"backbone": "toy ViT, seeded random weights" if tiny else "DINO ViT-B/16",
                                      "frequency_counts_per_client_per_task": counts,
                                      "adapter_layers": "attention queries and keys", "router": "task-head centroids"}

    def begin_task(self, task, old_classes, seen_classes):
        self.task = task
        ids = torch.as_tensor(self.stream.task_classes[task], device=self.device)
        self.task_ids.append(ids)
        self.label_index = torch.full((self.stream.num_classes,), -1, dtype=torch.long, device=self.device)
        self.label_index[ids] = torch.arange(len(ids), device=self.device)

    def begin_round(self, task, round_in_task, selected):
        self.updates = {}

    def _indices(self, client):
        start = self.task * self.offsets[-1]
        return self.permutation[start + self.offsets[client]: start + self.offsets[client + 1]].to(self.device)

    def _images(self, inputs):
        images = inputs * self.image_scale + self.image_offset
        size = self.encoder.image_size
        if images.shape[-2:] != (size, size):
            images = F.interpolate(images, (size, size), mode="bicubic", align_corners=False, antialias=True)
        return images

    def fit_client(self, client, loader, device):
        indices = self._indices(client)
        updates = nn.Parameter(torch.zeros(len(self.projections), 2, len(indices), device=device))
        ids = self.task_ids[-1]
        head = nn.Linear(self.width, len(ids)).to(device)
        with torch.no_grad():
            head.weight.copy_(self.model.weight[ids])
            head.bias.copy_(self.model.bias[ids])
        optimizer = torch.optim.Adam([{"params": head.parameters(), "lr": self.args.lr},
                                      {"params": [updates], "lr": self.args.pfedmxf_adapter_lr}])
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, self.args.epochs * len(loader))
        for _ in range(self.args.epochs):
            for images, labels in loader:
                dense = _real_update(updates, indices, self.width).flatten(1, 2)
                overrides = {name: torch.cat((base[:2 * self.width] + delta, base[2 * self.width:]))
                             for (name, base), delta in zip(self.projections.items(), dense)}
                features = torch.func.functional_call(self.encoder, overrides, (self._images(images.to(device)),))
                loss = F.cross_entropy(head(features), self.label_index[labels.to(device)])
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
                scheduler.step()
        with torch.no_grad():
            self.model.weight[ids] = head.weight
            self.model.bias[ids] = head.bias
        self.updates[client] = updates.detach()

    @torch.no_grad()
    def post_round(self):
        if not self.updates:
            return
        indices = torch.cat([self._indices(client) for client in self.updates])
        updates = torch.cat(list(self.updates.values()), dim=-1)
        for client, delta in self.updates.items():
            key = (self.task, client)
            if key in self.coefficients:
                self.coefficients[key].add_(delta.cpu())
            else:
                self.coefficients[key] = delta.cpu().clone()
        # Eq. 13 merges disjoint frequency coefficients by union (sum).
        for layer, base in enumerate(self.projections.values()):
            dense = _real_update(updates[layer], indices, self.width)
            base[:2 * self.width].add_(dense.flatten(0, 1))
        self.updates.clear()

    def predict(self, inputs):
        features = self.encoder(self._images(inputs))
        centers = torch.stack([self.model.weight[ids].mean(0) for ids in self.task_ids])
        routing = F.log_softmax(-0.5 * torch.cdist(features, centers).square(), dim=1)
        logits = self.model(features)
        output = torch.full_like(logits, torch.finfo(logits.dtype).min)
        for task, ids in enumerate(self.task_ids):
            output[:, ids] = F.log_softmax(logits[:, ids], dim=1) + routing[:, task:task + 1]
        return output

    def checkpoint(self):
        return {"frequency_updates": self.coefficients, "coordinate_permutation": self.permutation,
                "client_offsets": self.offsets, "task_classes": [ids.cpu() for ids in self.task_ids],
                "backbone": self.stream.protocol["pfedmxf"]["backbone"], "seed": self.args.seed,
                "dino_backbone_url": DINO_URL}
