"""FedWeIT's decomposed weights and sparse transfers on the Survey streams.

Reference: Yoon et al., ICML 2021, https://proceedings.mlr.press/v139/yoon21b.html
"""

import copy
import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .survey.common import avoid_singleton_batch_norm, optimizer_for, state_copy
from .survey.strategies import LocalStrategy


def add_args(parser):
    parser.add_argument("--fedweit_mask_prune", type=float, default=0.3,
                        help="fraction of shared output channels withheld per layer")
    parser.add_argument("--fedweit_adapter_keep", type=float, default=0.03,
                        help="fraction of largest adapter weights stored between rounds")
    parser.add_argument("--fedweit_kb_size", type=int, default=4,
                        help="maximum number of foreign client adapters received per task")
    parser.add_argument("--fedweit_sparsity", type=float, default=1e-3,
                        help="L1 coefficient for masks and task adapters")
    parser.add_argument("--fedweit_retroactive", type=float, default=100.0,
                        help="historical effective-weight reconstruction penalty")


def _validate(mask_prune, adapter_keep, kb_size, sparsity, retroactive):
    if not math.isfinite(mask_prune) or not 0 <= mask_prune < 1:
        raise ValueError("fedweit_mask_prune must be in [0, 1)")
    if not math.isfinite(adapter_keep) or not 0 < adapter_keep <= 1:
        raise ValueError("fedweit_adapter_keep must be in (0, 1]")
    if kb_size < 1:
        raise ValueError("fedweit_kb_size must be positive")
    if not all(math.isfinite(value) and value >= 0 for value in (sparsity, retroactive)):
        raise ValueError("FedWeIT sparsity and retroactive penalties must be finite and nonnegative")


def validate_args(parser, args):
    try:
        _validate(args.fedweit_mask_prune, args.fedweit_adapter_keep, args.fedweit_kb_size,
                  args.fedweit_sparsity, args.fedweit_retroactive)
    except ValueError as error:
        parser.error(str(error))


def _broadcast(mask, weight):
    return mask.reshape((-1,) + (1,) * (weight.ndim - 1))


def _pack(weight, fraction):
    flat = weight.detach().flatten()
    count = min(len(flat), max(1, math.ceil(fraction * len(flat))))
    indices = flat.abs().topk(count, sorted=False).indices
    values = flat[indices]
    keep = values != 0
    return indices[keep].int().cpu(), values[keep].cpu()


def _sparse_add(flat, adapter, scale=1):
    indices, values = adapter
    return flat.index_add(0, indices.to(flat.device, dtype=torch.long), values.to(flat) * scale)


class _DecomposedLayer(nn.Module):
    def __init__(self, layer):
        super().__init__()
        self.weight, self.bias = layer.weight, layer.bias
        self.private = None
        self.convolution = isinstance(layer, nn.Conv2d)
        if self.convolution:
            self.conv_options = (layer.stride, layer.padding, layer.dilation, layer.groups)

    def forward(self, features):
        weight = self.weight
        if self.private is not None:
            mask, adapter, attention, peers = self.private
            weight = weight * _broadcast(mask.sigmoid(), weight) + adapter
            flat = weight.flatten()
            for coefficient, peer in zip(attention, peers):
                flat = _sparse_add(flat, peer, coefficient)
            weight = flat.reshape_as(weight)
        if self.convolution:
            return F.conv2d(features, weight, self.bias, *self.conv_options)
        return F.linear(features, weight, self.bias)


class FedWeIT(LocalStrategy):
    """Masked client bases, sparse task adapters, and learned cross-client transfer."""

    def __init__(self, model, args, stream, device):
        super().__init__(model, args, stream, device)
        self.mask_prune = getattr(args, "fedweit_mask_prune", 0.3)
        self.adapter_keep = getattr(args, "fedweit_adapter_keep", 0.03)
        self.kb_size = getattr(args, "fedweit_kb_size", 4)
        self.sparsity = getattr(args, "fedweit_sparsity", 1e-3)
        self.retroactive = getattr(args, "fedweit_retroactive", 100.0)
        _validate(self.mask_prune, self.adapter_keep, self.kb_size, self.sparsity, self.retroactive)
        self.layers = {}
        for name, layer in list(model.named_modules()):
            if name and name != "fc" and isinstance(layer, (nn.Conv2d, nn.Linear)):
                parent = model
                for part in name.split(".")[:-1]:
                    parent = getattr(parent, part)
                replacement = _DecomposedLayer(layer)
                setattr(parent, name.split(".")[-1], replacement)
                self.layers[name + ".weight"] = replacement
        if not self.layers:
            raise ValueError("FedWeIT requires at least one convolutional or hidden linear layer")
        self.private_keys = tuple(name for name in model.state_dict() if name not in self.layers)
        self.initial_base = {name: layer.weight.detach().cpu().clone() for name, layer in self.layers.items()}
        self.clients = {}
        self.knowledge = {}
        self.eval_models = []

    def begin_task(self, task, old_classes, seen_classes):
        self.task = task
        self.eval_models.clear()
        for state in self.clients.values():
            # Keep a fixed previous-task solution for the retroactive objective.
            state["anchor_base"] = state["base"]
            state["anchor_tasks"] = {
                task: {"masks": prior["masks"], "adapters": dict(prior["adapters"])}
                for task, prior in state["tasks"].items()
            }

    def begin_round(self, task, round_in_task, selected):
        self.round_masks = {}
        self.round_clients = 0

    def aggregation_weight(self, client, loader):
        return 1

    def _peers(self, client):
        available = [key for key in self.knowledge if key[0] != client]
        rng = np.random.default_rng(np.random.SeedSequence([self.args.seed, client, self.task]))
        selected = rng.choice(len(available), size=min(len(available), self.kb_size), replace=False)
        return tuple(available[index] for index in selected)

    @torch.no_grad()
    def _seed_client(self, client):
        state = self.clients.setdefault(
            client, {"base": self.initial_base, "tasks": {}, "anchor_base": {}, "anchor_tasks": {}},
        )
        snapshot = state["tasks"].get(self.task)
        if state["tasks"]:
            recent = snapshot if snapshot is not None else state["tasks"][max(state["tasks"])]
            self.model.load_state_dict(recent["personal"], strict=False)
        for name, layer in self.layers.items():
            # Zero server entries represent omitted sparse broadcasts.
            layer.weight.copy_(torch.where(layer.weight != 0, layer.weight, state["base"][name].to(layer.weight)))
        keys = snapshot["peers"] if snapshot is not None else self._peers(client)
        for name, layer in self.layers.items():
            weight = layer.weight
            if snapshot is not None:
                mask = snapshot["masks"][name].to(weight).clone()
                adapter = _sparse_add(weight.new_zeros(weight.numel()), snapshot["adapters"][name]).reshape_as(weight)
                attention = snapshot["attention"][name].to(weight).clone()
            else:
                mask = weight.new_zeros(weight.shape[0])
                adapter = weight.new_zeros(weight.shape)
                attention = weight.new_zeros(len(keys))
            peers = tuple(
                (self.knowledge[key][name][0].to(weight.device, dtype=torch.long),
                 self.knowledge[key][name][1].to(weight))
                for key in keys
            )
            layer.private = (mask.requires_grad_(), adapter.requires_grad_(), attention.requires_grad_(), peers)
        return state, keys

    def _retroactive_targets(self, state):
        if self.retroactive == 0 or not state["anchor_tasks"]:
            return {}
        targets = {}
        for name, layer in self.layers.items():
            weight = layer.weight
            anchor = state["anchor_base"][name].to(weight)
            targets[name] = [
                (task, _broadcast(prior["masks"][name].to(weight).sigmoid(), weight),
                 _sparse_add(weight.new_zeros(weight.numel()), prior["adapters"][name]).reshape_as(weight), anchor)
                for task, prior in state["anchor_tasks"].items()
            ]
        return targets

    @torch.no_grad()
    def _retroactive_loss_gradient(self, targets):
        if self.retroactive == 0:
            return
        threshold = self.sparsity / self.retroactive
        for name, terms in targets.items():
            weight = self.layers[name].weight
            for _, mask, adapter, anchor in terms:
                required = adapter + (anchor - weight) * mask
                # Minimize the L1-penalized residual over the historical adapter.
                # At that optimum, the residual is the clipped required correction.
                residual = required.clamp(-threshold, threshold)
                weight.grad.addcmul_(residual, mask, value=-self.retroactive)

    @torch.no_grad()
    def _save_and_mask(self, state, keys, targets):
        local = state_copy(self.model)
        state["base"] = {name: local[name] for name in self.layers}
        snapshot = {
            "masks": {}, "adapters": {}, "attention": {}, "peers": keys,
            "personal": {name: local[name] for name in self.private_keys},
        }
        state["tasks"][self.task] = snapshot
        self.round_clients += 1
        for name, layer in self.layers.items():
            mask, adapter, attention, _ = layer.private
            snapshot["masks"][name] = mask.cpu().clone()
            snapshot["adapters"][name] = _pack(adapter, self.adapter_keep)
            snapshot["attention"][name] = attention.cpu().clone()
            for task, old_mask, old_adapter, anchor in targets.get(name, ()):
                if self.retroactive:
                    needed = old_adapter + (anchor - layer.weight) * old_mask
                    compensated = F.softshrink(needed, self.sparsity / self.retroactive)
                    state["tasks"][task]["adapters"][name] = _pack(compensated, self.adapter_keep)
            retained = max(1, math.ceil((1 - self.mask_prune) * mask.numel()))
            indices = mask.detach().abs().topk(retained, sorted=False).indices.cpu()
            include = torch.zeros(mask.shape, dtype=local[name].dtype)
            include[indices] = 1
            if name in self.round_masks:
                self.round_masks[name].add_(include)
            else:
                self.round_masks[name] = include
            local[name] = local[name] * _broadcast(include, local[name])
        return local

    def fit_client(self, client, loader, device):
        state, keys = self._seed_client(client)
        try:
            targets = self._retroactive_targets(state)
            private = [parameter for layer in self.layers.values() for parameter in layer.private[:3]]
            optimizer = optimizer_for(list(self.model.parameters()) + private, self.args)
            self.model.train()
            active_classes = torch.tensor(self.stream.task_classes[self.task], dtype=torch.long, device=device)
            for _ in range(self.args.epochs):
                for images, labels in loader:
                    images, labels = images.to(device), labels.to(device)
                    optimizer.zero_grad()
                    with avoid_singleton_batch_norm(self.model, len(images)):
                        logits = self.model(images).index_select(1, active_classes)
                    local_labels = (labels[:, None] == active_classes).long().argmax(dim=1)
                    loss = F.cross_entropy(logits, local_labels)
                    if self.sparsity:
                        loss = loss + self.sparsity * sum(value.abs().sum() for layer in self.layers.values()
                                                         for value in layer.private[:2])
                    loss.backward()
                    self._retroactive_loss_gradient(targets)
                    optimizer.step()
            return self._save_and_mask(state, keys, targets)
        finally:
            for layer in self.layers.values():
                layer.private = None

    def project_update(self, previous_state, averaged_state):
        projected = dict(previous_state)
        for name, mask in self.round_masks.items():
            contributors = _broadcast(mask.clamp_min(1), averaged_state[name])
            # Match FedWeIT's sparse broadcast: channels with no upload stay
            # zero on the wire so clients keep their own values in _seed_client.
            projected[name] = averaged_state[name] * (self.round_clients / contributors)
        return projected

    def post_round(self):
        self.eval_models.clear()

    def finish_task(self, task):
        for client, state in self.clients.items():
            if task in state["tasks"]:
                # The knowledge base keeps the upload as it was at task completion.
                self.knowledge[client, task] = dict(state["tasks"][task]["adapters"])

    def _effective_weight(self, name, base, snapshot):
        weight = base * _broadcast(snapshot["masks"][name].sigmoid(), base)
        values = _sparse_add(weight.flatten(), snapshot["adapters"][name])
        for coefficient, peer in zip(snapshot["attention"][name], snapshot["peers"]):
            values = _sparse_add(values, self.knowledge[peer][name], coefficient)
        return values.reshape_as(weight)

    @torch.no_grad()
    def _evaluation_models(self):
        for task in range(self.task + 1):
            states = [state for state in self.clients.values() if task in state["tasks"]]
            if not states:
                continue
            merged = {}
            for state in states:
                snapshot = state["tasks"][task]
                for name in self.layers:
                    value = self._effective_weight(name, state["base"][name], snapshot)
                    if name in merged:
                        merged[name].add_(value)
                    else:
                        merged[name] = value
                for name, value in snapshot["personal"].items():
                    if name not in merged:
                        merged[name] = value.clone()
                    elif value.is_floating_point():
                        merged[name].add_(value)
            merged = {name: value / len(states) if value.is_floating_point() else value
                      for name, value in merged.items()}
            model = copy.deepcopy(self.model).eval()
            model.load_state_dict(merged)
            self.eval_models.append((task, model))

    @torch.no_grad()
    def predict(self, inputs):
        if not self.eval_models:
            self._evaluation_models()
        if not self.eval_models:
            return self.model(inputs)
        if self.stream.protocol["scenario"] == "domain-il":
            return sum(model(inputs) for _, model in self.eval_models) / len(self.eval_models)
        logits = inputs.new_full((len(inputs), self.stream.num_classes), torch.finfo(inputs.dtype).min)
        for task, model in self.eval_models:
            classes = list(self.stream.task_classes[task])
            logits[:, classes] = model(inputs)[:, classes]
        return logits

    def checkpoint(self):
        return {
            "clients": {client: {"base": state["base"], "tasks": state["tasks"]}
                        for client, state in self.clients.items()},
            "knowledge": self.knowledge,
            "evaluation": "Per-task mean of composed client models; class-logit assembly or domain-logit averaging",
        }
