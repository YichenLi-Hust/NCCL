"""Decentralized class-incremental learning with on-demand unlearning (ICML 2026)."""

import argparse
import copy
import math
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

from .dcu_diffusion import LatentDiffusion, SyntheticDiffusion
from .models import CLASSIFIERS
from .survey.data import load_survey_data
from .survey_runner import _write_csv, _write_json
from .training import avoid_singleton_batch_norm, seed_everything, state_copy


def _parse(argv):
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument("--baseline", default="DCU", choices=("DCU", "dcu"))
    p.add_argument("--dataset", choices=("synthetic", "cifar10", "cifar100", "tinyimagenet"), default="cifar100")
    p.add_argument("--data_dir", default="./data")
    p.add_argument("--output_dir", default="./results/dcu")
    p.add_argument("--download", action="store_true")
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--num_tasks", type=int)
    p.add_argument("--dcu_task_limit", type=int, help="take the first K tasks from the class partition")
    p.add_argument("--client_num_in_total", type=int, default=5)
    p.add_argument("--alpha", type=float, default=0.5)
    p.add_argument("--model", choices=CLASSIFIERS, default="resnet18")
    p.add_argument("--comm_round", type=int, default=10)
    p.add_argument("--eval_every", type=int, default=1, help="round interval for peer evaluation")
    p.add_argument("--epochs", type=int, default=1, help="local passes over the largest shard per round")
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--lr", type=float, default=0.01)
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--gpu", type=int, default=0)
    p.add_argument("--dcu_diffusion", help="local SD 1.x Diffusers checkpoint directory for RGB data")
    p.add_argument("--dcu_forget_after", help="comma-separated completed-task:class requests, e.g. 2:0,3:4")
    p.add_argument("--dcu_edge_probability", type=float, default=0.6)
    p.add_argument("--dcu_proto_rounds", type=int, default=5)
    p.add_argument("--dcu_proto_steps", type=int, default=5)
    p.add_argument("--dcu_proto_lr", type=float, default=0.03)
    p.add_argument("--dcu_diffusion_steps", type=int, default=20)
    p.add_argument("--dcu_diffusion_batch", type=int, default=4)
    p.add_argument("--dcu_resolution", type=int, default=256, help="pixel resolution for the frozen latent diffusion model")
    p.add_argument("--dcu_samples", type=int, default=100,
                   help="synthetic examples per client for current/forgetting pools; historical pools use twice this")
    p.add_argument("--dcu_beta_cl", type=float, default=10)
    p.add_argument("--dcu_beta_ul", type=float, default=0.2)
    p.add_argument("--dcu_unlearn_steps", type=int, default=50)
    a = p.parse_args(argv)
    if a.smoke:
        a.dataset, a.model, a.num_tasks = "synthetic", "small_cnn", 3
        a.client_num_in_total, a.comm_round, a.epochs, a.batch_size = 3, 2, 1, 8
        a.dcu_proto_rounds, a.dcu_proto_steps, a.dcu_diffusion_steps = 2, 1, 3
        a.dcu_samples, a.dcu_unlearn_steps = 6, 3
        if a.dcu_forget_after is None:
            a.dcu_forget_after = "2:0"
    if not math.isfinite(a.dcu_edge_probability) or not 0 <= a.dcu_edge_probability <= 1:
        p.error("dcu_edge_probability must be in [0, 1]")
    if not 0 <= a.seed < 2 ** 32 or a.num_workers < 0 or a.gpu < -1:
        p.error("invalid seed, num_workers or GPU index")
    if a.gpu > 0 and a.gpu >= torch.cuda.device_count():
        p.error("unavailable GPU index")
    positive = ("client_num_in_total", "comm_round", "epochs", "eval_every", "batch_size", "lr", "alpha", "threads",
                "dcu_samples", "dcu_unlearn_steps", "dcu_proto_rounds", "dcu_proto_steps", "dcu_proto_lr",
                "dcu_diffusion_steps", "dcu_diffusion_batch", "dcu_beta_cl", "dcu_beta_ul", "dcu_resolution")
    if any(not math.isfinite(getattr(a, k)) or getattr(a, k) <= 0 for k in positive):
        p.error("learning, diffusion and sampling settings must be positive and finite")
    if a.dcu_resolution % 64:
        p.error("dcu_resolution must be a positive multiple of 64")
    if a.dataset != "synthetic" and not a.dcu_diffusion:
        p.error("real-image runs require --dcu_diffusion PATH to a frozen local SD 1.x checkpoint")
    return a


def _requests(spec, classes):
    requests, removed = {}, set()
    if spec:
        for item in spec.split(","):
            try:
                stage, label = map(int, item.split(":"))
            except ValueError as exc:
                raise ValueError("dcu_forget_after expects completed-task:class pairs") from exc
            if not 1 <= stage <= len(classes) or not any(label in group for group in classes[:stage]):
                raise ValueError(f"class {label} has not been introduced after stage {stage}")
            if label in removed:
                raise ValueError(f"duplicate unlearning request for class {label}")
            removed.add(label)
            requests.setdefault(stage, []).append(label)
    return requests


def _gossip(count, probability, device):
    edges = torch.triu(torch.rand(count, count, device=device) < probability, 1)
    edges = edges | edges.T
    degree = edges.sum(1) + 1
    weights = edges.float() / torch.maximum(degree[:, None], degree[None, :])
    weights.diagonal().copy_(1 - weights.sum(1))
    return weights


def _cycle(dataset, batch_size, workers):
    if not len(dataset):
        while True:
            yield None
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=workers)
    while True:
        yield from loader


def _lookup(labels, classes):
    # The shared streams present monotonically increasing disjoint class blocks.
    # searchsorted also supports holes left by disposed class prototypes.
    return torch.searchsorted(classes, labels)


class _Decentralized:
    def __init__(self, stream, args, device):
        self.stream, self.args, self.device = stream, args, device
        prototype_model = CLASSIFIERS[args.model](stream.channels, stream.num_classes)
        self.clients = [copy.deepcopy(prototype_model).to(device) for _ in range(args.client_num_in_total)]
        self.prototypes = [{} for _ in self.clients]
        self.mean = torch.tensor(stream.mean, device=device)[None, :, None, None]
        self.std = torch.tensor(stream.std, device=device)[None, :, None, None]
        self.diffusion = (LatentDiffusion(args.dcu_diffusion, stream, device, args.dcu_diffusion_steps, args.dcu_resolution)
                          if args.dcu_diffusion else SyntheticDiffusion(stream, device, args.dcu_diffusion_steps))
        self.seen, self.removed = [], set()
        self.phase_metrics = []

    def extract(self, task, classes):
        a = self.args
        tokens = torch.randn(len(classes), self.diffusion.dim, device=self.device) * 0.02
        tokens = tokens.unsqueeze(0).repeat(len(self.clients), 1, 1)
        loaders = [_cycle(data, a.dcu_diffusion_batch, a.num_workers) for data in self.stream.train[task]]
        for _ in range(a.dcu_proto_rounds):
            for i, data in enumerate(loaders):
                token = tokens[i].detach().clone().requires_grad_()
                optimizer = torch.optim.Adam([token], lr=a.dcu_proto_lr)
                for _ in range(a.dcu_proto_steps):
                    batch = next(data)
                    if batch is None:
                        break
                    inputs, labels = (value.to(self.device) for value in batch)
                    pixels = ((inputs * self.std + self.mean) * 2 - 1).clamp(-1, 1)
                    loss = self.diffusion.loss(pixels, token[_lookup(labels, classes)])
                    optimizer.zero_grad(set_to_none=True)
                    loss.backward()
                    optimizer.step()
                tokens[i] = token.detach()
            weights = _gossip(len(self.clients), a.dcu_edge_probability, self.device)
            tokens = torch.einsum("ij,jcd->icd", weights, tokens)
        for client, store in enumerate(self.prototypes):
            store.update({label: value.detach().clone() for label, value in zip(classes.tolist(), tokens[client])})

    @torch.no_grad()
    def _pool(self, client, classes, count):
        labels = classes[torch.randperm(len(classes), device=self.device)]
        labels = labels.repeat(math.ceil(count / len(classes)))[:count]
        prototypes = torch.stack([self.prototypes[client][label] for label in classes.tolist()])
        images = []
        for batch in labels.split(self.args.dcu_diffusion_batch):
            pixels = (1 + self.diffusion.generate(prototypes[_lookup(batch, classes)])) / 2
            images.append(((pixels - self.mean) / self.std).cpu())
        return torch.cat(images), labels.cpu()

    def _sample(self, pool):
        images, labels = pool
        index = torch.randint(len(labels), (self.args.batch_size,))
        return images[index].to(self.device), labels[index].to(self.device)

    def prepare_task(self, task):
        self.current = torch.tensor(sorted(self.stream.task_classes[task]), device=self.device)
        self.old = torch.tensor(sorted(set(self.seen) - self.removed), dtype=torch.long, device=self.device)
        self.extract(task, self.current)
        self.seen.extend(self.current.tolist())
        self.teachers = [copy.deepcopy(client).eval().requires_grad_(False) for client in self.clients] if len(self.old) else []
        self.current_pools = [self._pool(i, self.current, self.args.dcu_samples) for i in range(len(self.clients))]
        self.old_pools = [self._pool(i, self.old, 2 * self.args.dcu_samples) for i in range(len(self.teachers))]
        self.loaders = [_cycle(data, self.args.batch_size, self.args.num_workers) for data in self.stream.train[task]]
        max_count = max(len(data) for data in self.stream.train[task])
        self.local_steps = self.args.epochs * math.ceil(max_count / self.args.batch_size)

    def _gradients(self, i):
        model = self.clients[i].train()
        model.zero_grad(set_to_none=True)
        inputs, labels = self._sample(self.current_pools[i])
        real = next(self.loaders[i])
        if real is not None:
            inputs = torch.cat((inputs, real[0].to(self.device)))
            labels = torch.cat((labels, real[1].to(self.device)))
        with avoid_singleton_batch_norm(model, len(labels)):
            scores = model(inputs)[:, self.current]
        loss = self.args.dcu_beta_cl * F.cross_entropy(scores, _lookup(labels, self.current))
        if self.teachers:
            images, labels = self._sample(self.old_pools[i])
            labels = _lookup(labels, self.old)
            with torch.no_grad():
                teacher = self.teachers[i](images)[:, self.old].softmax(1)
            with avoid_singleton_batch_norm(model, len(images)):
                student = model(images)[:, self.old]
            confidence = teacher.gather(1, labels[:, None]).flatten()
            loss = loss + F.kl_div(student.log_softmax(1), teacher, reduction="batchmean")
            loss = loss + (confidence * F.cross_entropy(student, labels, reduction="none")).mean()
        loss.backward()

    def train_round(self):
        weights = _gossip(len(self.clients), self.args.dcu_edge_probability, self.device)
        for _ in range(self.local_steps):
            for i in range(len(self.clients)):
                self._gradients(i)
            # D-PSGD. Each peer mixes only its neighbors' pre-step parameters,
            # then subtracts its own gradient evaluated before communication.
            with torch.no_grad():
                for group in zip(*(model.parameters() for model in self.clients)):
                    current = torch.stack([p.flatten() for p in group])
                    mixed = weights @ current
                    for p, row in zip(group, mixed):
                        p.copy_(row.view_as(p)).add_(p.grad, alpha=-self.args.lr)

    def forget(self, label):
        active = torch.tensor(sorted(set(self.seen) - self.removed), device=self.device)
        seen = torch.tensor(sorted(self.seen), device=self.device)
        for i, model in enumerate(self.clients):
            pool = self._pool(i, active, self.args.dcu_samples)
            head = copy.deepcopy(model.fc).train()
            optimizer = torch.optim.SGD(head.parameters(), lr=self.args.lr)
            model.eval()
            for _ in range(self.args.dcu_unlearn_steps):
                images, _ = self._sample(pool)
                with torch.no_grad():
                    features = model.forward_features(images)
                target = _lookup(torch.full((len(images),), label, dtype=torch.long, device=self.device), seen)
                loss = F.cross_entropy(head(features)[:, seen], target)
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
            # The paper subtracts the fitted head, not just its change. Future
            # rows emulate a dynamically expanded head and must be untouched.
            with torch.no_grad():
                for param, auxiliary in zip(model.fc.parameters(), head.parameters()):
                    param[seen] = param[seen] - self.args.dcu_beta_ul * auxiliary[seen]
            del self.prototypes[i][label]
        self.removed.add(label)

    @torch.no_grad()
    def evaluate(self, task, round_in_task, phase, target=None):
        seen = torch.tensor(sorted(self.seen), device=self.device)
        removed = torch.tensor(sorted(self.removed), dtype=torch.long, device=self.device)
        total = retained = target_count = hits = retained_hits = target_hits = 0
        request_hits = request_count = 0
        loss = 0.0
        for model in self.clients:
            model.eval()
        for test in self.stream.test[:task + 1]:
            for inputs, labels in DataLoader(test, batch_size=self.args.batch_size, num_workers=self.args.num_workers):
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                keep = ~torch.isin(labels, removed)
                forgotten = ~keep
                for model in self.clients:
                    scores = model(inputs)[:, seen]
                    correct = seen[scores.argmax(1)] == labels
                    total += len(labels)
                    hits += int(correct.sum())
                    retained += int(keep.sum())
                    retained_hits += int((correct & keep).sum())
                    target_count += int(forgotten.sum())
                    target_hits += int((correct & forgotten).sum())
                    if target is not None:
                        request_count += int((labels == target).sum())
                        request_hits += int((correct & (labels == target)).sum())
                    loss += float(F.cross_entropy(scores, _lookup(labels, seen), reduction="sum"))
        row = {"task": task + 1, "round_in_task": round_in_task, "phase": phase,
               "request_class": "" if target is None else target, "clients": len(self.clients),
               "test_accuracy": hits / total, "test_loss": loss / total, "test_count": total,
               "retained_accuracy": retained_hits / retained if retained else "",
               "forgotten_accuracy": target_hits / target_count if target_count else "",
               "requested_class_accuracy": request_hits / request_count if request_count else ""}
        if not math.isfinite(row["test_loss"]):
            raise FloatingPointError("Non-finite DCU evaluation loss")
        self.phase_metrics.append(row)


def run(argv=None):
    args = _parse(argv)
    seed_everything(args.seed)
    torch.set_num_threads(args.threads)
    device = torch.device(f"cuda:{args.gpu}" if args.gpu >= 0 and torch.cuda.is_available() else "cpu")
    stream = load_survey_data(args)
    args.num_tasks = stream.num_tasks
    if args.dcu_task_limit is not None:
        limit = args.dcu_task_limit
        if not 1 <= limit <= stream.num_tasks:
            raise ValueError("dcu_task_limit must be within the dataset's class partition")
        stream = replace(stream, train=stream.train[:limit], test=stream.test[:limit],
                         task_classes=stream.task_classes[:limit], task_names=stream.task_names[:limit])
        for key in ("task_names", "task_classes", "train_client_sample_counts", "test_sample_counts"):
            stream.protocol[key] = stream.protocol[key][:limit]
    requests = _requests(args.dcu_forget_after, stream.task_classes)
    network = _Decentralized(stream, args, device)
    for task in range(stream.num_tasks):
        network.prepare_task(task)
        for round_in_task in range(1, args.comm_round + 1):
            network.train_round()
            if round_in_task % args.eval_every == 0 or round_in_task == args.comm_round:
                network.evaluate(task, round_in_task, "learn")
        # Drop cached replay and previous teachers before handling requests.
        network.current_pools, network.old_pools, network.teachers = [], [], []
        for label in requests.get(task + 1, ()):
            network.forget(label)
            network.evaluate(task, args.comm_round, "forget", label)

    stream.protocol["dcu"] = {
        "topology": "Erdos-Renyi, self-loops, Metropolis weights, all clients; private BN running statistics",
        "denoiser": "local SD 1.x, one learned conditioning token per class" if args.dcu_diffusion else "analytic synthetic Gaussian fixture",
        "aggregation": "neighbor parameter mixing then local SGD, no central classifier",
        "metrics": "uniform mean across peer classifiers; evaluation includes removed class logits",
        "requests": requests,
        "remaining_classes_per_peer": [sorted(prototypes) for prototypes in network.prototypes],
    }
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "metrics.csv", network.phase_metrics[0], network.phase_metrics)
    _write_json(output / "protocol.json", stream.protocol)
    torch.save({"client_states": [state_copy(model) for model in network.clients],
                "prototypes": [{key: value.cpu() for key, value in p.items()} for p in network.prototypes],
                "removed_classes": sorted(network.removed), "args": vars(args)}, output / "model.pt")
    return SimpleNamespace(args=args, stream=stream, history=network.phase_metrics)
