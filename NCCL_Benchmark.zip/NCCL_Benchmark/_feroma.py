"""Run one fold of the FEROMA author release in its prepared Python environment."""

import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def stop_workers(workers):
    for child in workers:
        if child.poll() is None:
            child.terminate()
    for child in workers:
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()


def train_fold(root, fold, count, timeout):
    workdir = root / "feroma"
    workers = []
    started = time.monotonic()

    def handle_termination(signum, frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, handle_termination)
    try:
        server = subprocess.Popen([sys.executable, "server.py", "--fold", str(fold)], cwd=workdir)
        workers.append(server)
        time.sleep(2)  # Match the server startup interval in the release.
        if server.poll() is not None:
            raise SystemExit("FEROMA server exited before clients connected")
        for client in range(count):
            command = [sys.executable, "client.py", "--id", str(client), "--fold", str(fold)]
            workers.append(subprocess.Popen(command, cwd=workdir))
        while True:
            codes = [child.poll() for child in workers]
            for index, code in enumerate(codes):
                if code not in (None, 0):
                    role = "server" if index == 0 else f"client {index - 1}"
                    raise SystemExit(f"FEROMA {role} exited with status {code}")
            if all(code == 0 for code in codes):
                return
            if timeout and time.monotonic() - started >= timeout:
                raise SystemExit("FEROMA exceeded --timeout")
            time.sleep(0.2)
    finally:
        stop_workers(workers)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fold", type=int, default=0, help="fold index in the author's experiment")
    parser.add_argument("--prepare-data", action="store_true",
                        help="generate fold data when data/cur_datasets has no existing shards")
    parser.add_argument("--scaling", type=int, default=0, help="input to the upstream data generator")
    parser.add_argument("--epoch-num", type=int, default=10, help="input to the upstream data generator")
    parser.add_argument("--timeout", type=float, default=0, help="optional training timeout in seconds")
    args = parser.parse_args()
    root = Path.cwd()
    for entry in ("public/config.py", "feroma/server.py", "feroma/client.py"):
        if not (root / entry).is_file():
            parser.error(f"missing {root / entry}")
    sys.path.insert(0, os.fspath(root))
    from public import config  # Imported from the explicitly selected author checkout.

    if str(config.strategy).lower() != "feroma":
        parser.error("set strategy = 'feroma' in public/config.py")
    if not 0 <= args.fold < int(config.k_folds) or args.timeout < 0 or int(config.n_clients) < 1:
        parser.error("check fold range, client count and timeout")
    data = root / "data" / "cur_datasets"
    has_shards = any(path.is_file() and not path.name.startswith(".") for path in data.rglob("*"))
    if args.prepare_data:
        if has_shards:
            parser.error("existing fold data found; use it or generate a different fold in a fresh checkout")
        generator = "chexpert_data_gen.py" if config.dataset_name == "CheXpert" else "generate_datasets.py"
        command = [sys.executable, f"public/{generator}", "--fold", str(args.fold),
                   "--scaling", str(args.scaling), "--epoch_num", str(args.epoch_num)]
        if config.dataset_name == "CheXpert":
            command.extend(("--n_clients", str(config.n_clients)))
        subprocess.run(command, cwd=root, check=True)
    elif not has_shards:
        parser.error("stage fold data in data/cur_datasets or add --prepare-data in the prepared environment")
    print(f"FEROMA fold {args.fold} on {config.dataset_name} with {config.n_clients} clients", flush=True)
    train_fold(root, args.fold, int(config.n_clients), args.timeout)


if __name__ == "__main__":
    main()
